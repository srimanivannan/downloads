package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;

import java.util.Collections;

/**
 * Single-PII implementation for C2P. This mirrors the existing getPreferredChannelForC2p behavior.
 *
 * Future: if you introduce a separate "single identity pii" flow, add another resolver,
 * keep this one for legacy-compatible mode.
 */
public final class SinglePiiC2PResolver implements C2PModeResolver {

    @Override
    public boolean supports(boolean multiPiiEnabled) {
        return !multiPiiEnabled;
    }

    @Override
    public ResolutionOutcome resolve(ChannelContext ctx, IdentityOps ops, ISDVerificationChannels out) {
        Consumer consumer = ctx.consumer();

        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;

        if (IdentityType.EMAIL.equals(ctx.identityTypeFromScopeData())) {
            isAllMobileMatched = ctx.consumers().stream().allMatch(c ->
                    consumer.getHashedCountryCodeWithMobile().equals(c.getHashedCountryCodeWithMobile()));
            isAllEmailMatched = true;
        } else if (IdentityType.SMS.equals(ctx.identityTypeFromScopeData())) {
            isAllEmailMatched = ctx.consumers().stream().allMatch(c ->
                    consumer.getHashedEmail().equals(c.getHashedEmail()));
            isAllMobileMatched = true;
        }

        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            return new ResolutionOutcome(AuthenticationChannel.SMS.name(), "C2P_NewUser");
        }

        if (isAllEmailMatched && isAllMobileMatched) {
            return new ResolutionOutcome(AuthenticationChannel.SMS.name(), "C2P_ReturningUser_AllMatched");
        }

        if (isAllEmailMatched) {
            out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
            return new ResolutionOutcome(AuthenticationChannel.EMAIL.name(), "C2P_ReturningUser_EmailMatched");
        }

        if (isAllMobileMatched) {
            out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
            return new ResolutionOutcome(AuthenticationChannel.SMS.name(), "C2P_ReturningUser_MobileMatched");
        }

        return new ResolutionOutcome(null, null);
    }
}
