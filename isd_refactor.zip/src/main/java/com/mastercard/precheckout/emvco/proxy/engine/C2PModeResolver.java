package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;

/**
 * Pluggable resolver for different C2P identity modes.
 * Today: MULTI_PII and legacy SINGLE identity.
 * Tomorrow: can add more modes without touching orchestrator.
 */
public interface C2PModeResolver {

    C2PMode supports();

    C2PResolution resolve(ChannelContext ctx, IdentityOps ops, ISDVerificationChannels out);
}
