package com.mastercard.precheckout.emvco.proxy.engine;

/**
 * Output from the new engine (preferred channel + rule name).
 * The ISDVerificationChannels object is mutated by resolvers to preserve existing API.
 */
public record C2PResolution(String preferredChannel, String channelRule) {
}
