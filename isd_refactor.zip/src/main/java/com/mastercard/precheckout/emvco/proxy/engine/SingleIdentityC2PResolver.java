package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;

import java.util.Collections;

/**
 * Single-identity C2P resolver equivalent to legacy getPreferredChannelForC2p.
 * No hash/mask population beyond restrictedChannelList.
 */
public final class SingleIdentityC2PResolver implements C2PModeResolver {

    @Override
    public C2PMode supports() {
        return C2PMode.SINGLE_IDENTITY;
    }

    @Override
    public C2PResolution resolve(ChannelContext ctx, IdentityOps ops, ISDVerificationChannels out) {

        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;

        if (ctx.identityTypeFromScopeData() == IdentityType.EMAIL) {
            isAllMobileMatched = ctx.consumers().stream()
                    .allMatch(c -> ctx.consumer().getHashedCountryCodeWithMobile().equals(c.getHashedCountryCodeWithMobile()));
            isAllEmailMatched = true;
        }

        if (ctx.identityTypeFromScopeData() == IdentityType.SMS) {
            isAllEmailMatched = ctx.consumers().stream()
                    .allMatch(c -> ctx.consumer().getHashedEmail().equals(c.getHashedEmail()));
            isAllMobileMatched = true;
        }

        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(ctx.consumer().getStatus())) {
            return new C2PResolution(AuthenticationChannel.SMS.name(), "C2P_NewUser");
        }

        C2PDecisionTable decision = C2PDecisionTable.resolve(isAllEmailMatched, isAllMobileMatched);
        if (decision == null) {
            return new C2PResolution(null, null);
        }

        switch (decision) {
            case EMAIL_MATCHED -> out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
            case MOBILE_MATCHED -> out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
            default -> { /* no restrictions */ }
        }

        return new C2PResolution(decision.preferredChannel().name(), decision.channelRule());
    }
}
