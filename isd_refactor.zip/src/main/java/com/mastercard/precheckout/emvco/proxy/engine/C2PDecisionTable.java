package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;

import java.util.Arrays;

/**
 * Decision table for returning C2P users.
 */
public enum C2PDecisionTable {

    ALL_MATCHED(true, true, AuthenticationChannel.SMS, "C2P_ReturningUser_AllMatched"),
    EMAIL_MATCHED(true, false, AuthenticationChannel.EMAIL, "C2P_ReturningUser_EmailMatched"),
    MOBILE_MATCHED(false, true, AuthenticationChannel.SMS, "C2P_ReturningUser_MobileMatched");

    private final boolean emailMatched;
    private final boolean mobileMatched;
    private final AuthenticationChannel preferredChannel;
    private final String channelRule;

    C2PDecisionTable(boolean emailMatched, boolean mobileMatched, AuthenticationChannel preferredChannel, String channelRule) {
        this.emailMatched = emailMatched;
        this.mobileMatched = mobileMatched;
        this.preferredChannel = preferredChannel;
        this.channelRule = channelRule;
    }

    public static C2PDecisionTable resolve(boolean emailMatched, boolean mobileMatched) {
        return Arrays.stream(values())
                .filter(r -> r.emailMatched == emailMatched && r.mobileMatched == mobileMatched)
                .findFirst()
                .orElse(null);
    }

    public AuthenticationChannel preferredChannel() {
        return preferredChannel;
    }

    public String channelRule() {
        return channelRule;
    }
}
