package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;

import java.util.Optional;

/**
 * IdentityType.SMS strategy for Multi-PII C2P.
 * Matches legacy behavior:
 * - allMobileMatched = true
 * - allEmailMatched = validatedEmailHash.isPresent()
 * - matchedPreferredHash = lookupPhoneOtpValue(...)
 * - switchingHash = lookupPhoneOtpValue(...)
 */
public final class SmsResolutionStrategy implements IdentityResolutionStrategy {

    @Override
    public IdentityType supports() {
        return IdentityType.SMS;
    }

    @Override
    public Resolution resolve(ChannelContext ctx, IdentityOps ops) {
        Consumer consumer = ctx.consumer();

        Optional<String> preferredEmailHash = ops.getPreferredEmailHash(consumer);
        Optional<String> validatedEmailHash = ops.getValidatedEmailHash(ctx.consumers(), preferredEmailHash);

        boolean allEmailMatched = validatedEmailHash.isPresent();
        boolean allMobileMatched = true;

        Optional<String> lookup = ops.lookupPhoneOtpValue(
                consumer,
                ctx.requestedIdentityValueFromScopeData(),
                ctx.identityValueFromScopeData()
        );

        return new Resolution(allEmailMatched, allMobileMatched, lookup, lookup);
    }
}
