package com.mastercard.precheckout.emvco.proxy;

import com.mastercard.alberta.logging.CommonLogFormatter;
import com.mastercard.alberta.logging.CommonLogger;
import com.mastercard.alberta.logging.CommonLoggerFactory;
import com.mastercard.precheckout.emvco.config.AuthenticationConfig;
import com.mastercard.precheckout.emvco.config.FeatureConfig;
import com.mastercard.precheckout.emvco.config.OtpAuthConfig;
import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.constants.DataConstants;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.AuthenticationMethod;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.Mobile;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityValidationChannel;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityVerificationRequest;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;
import com.mastercard.precheckout.generated.emvco.model.IdentityValidationChannel;
import com.mastercard.precheckout.generated.emvco.model.IdentityVerificationRequest;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

import com.mastercard.precheckout.emvco.proxy.engine.C2PChannelEngine;
import com.mastercard.precheckout.emvco.proxy.engine.C2PMode;
import com.mastercard.precheckout.emvco.proxy.engine.C2PResolution;
import com.mastercard.precheckout.emvco.proxy.engine.ChannelContext;
import com.mastercard.precheckout.emvco.proxy.engine.EmailResolutionStrategy;
import com.mastercard.precheckout.emvco.proxy.engine.IdentityOps;
import com.mastercard.precheckout.emvco.proxy.engine.IdentityResolutionStrategy;
import com.mastercard.precheckout.emvco.proxy.engine.MultiPiiC2PResolver;
import com.mastercard.precheckout.emvco.proxy.engine.SingleIdentityC2PResolver;
import com.mastercard.precheckout.emvco.proxy.engine.SmsResolutionStrategy;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import static java.util.Optional.ofNullable;

/**
 * This class is used to determine preferred channel based on the ISD implementation given
 * <a href="https://confluence.mastercard.int/x/QGX8NQ">here</a>
 */
@Component
public class ISDVerificationChannelRule implements IdentityOps {

    private static final CommonLogger LOGGER = CommonLoggerFactory.getLogger(ISDVerificationChannelRule.class);

    private static final String AUTH_CHANNEL = "AuthChannel";
    private static final String EMAIL_TYPE = "EMAIL";
    private static final String MOBILE_PHONE_NUMBER_TYPE = "MOBILE_PHONE_NUMBER";
    public static final String LOGGER_MESSAGE = "Verification channel determined based on the new rules";
    public static final String METHOD_NAME = "ISDVerificationChannelRule.getPreferredChannel";

    private final AuthenticationConfig authenticationConfig;

    private final FeatureConfig featureConfig;

    public ISDVerificationChannelRule(AuthenticationConfig authenticationConfig, FeatureConfig featureConfig) {
        this.authenticationConfig = authenticationConfig;
        this.featureConfig = featureConfig;
    }

    /**
     * Method to decide the preferred channel based on rules.
     *
     * @param identityTypeFromScopeData identityType from ScopeData
     * @param clientId clientId
     * @param consumers list of consumers
     * @param consumer default consumer
     *
     * @return String preferred channel
     */
    public <T> ISDVerificationChannels getPreferredChannel(
            T identityVerificationRequest,
            String authChannelFromScopeData,
            String identityTypeFromScopeData,
            String identityValueFromScopeData,
            String requestedIdentityValueFromScopeData,
            String clientId,
            List<Consumer> consumers,
            Consumer consumer
    ) {

        // Keep original NPE behavior if consumer/authConfig/featureConfig/otp are null
        OtpAuthConfig otpAuthConfig = authenticationConfig.getOtp();
        boolean isSMSChannelRestricted = otpAuthConfig.isRestrictedFromSMS(consumer.getMobileCountryCode());

        // Rule 1: OTP channel present in scope data (and not suppressed)
        Optional<ISDVerificationChannels> scopeResult = handleScopeAuthChannel(
                authChannelFromScopeData, clientId, otpAuthConfig, consumer, isSMSChannelRestricted);
        if (scopeResult.isPresent()) {
            return scopeResult.get();
        }

        // Rule 2: SMS restricted -> default EMAIL (optionally set hashedValidationChannelValue when multi-PII)
        Optional<ISDVerificationChannels> smsRestrictedResult = handleSmsRestricted(
                identityTypeFromScopeData, consumer, isSMSChannelRestricted);
        if (smsRestrictedResult.isPresent()) {
            return smsRestrictedResult.get();
        }

        // Rule 3: Request contains auth channel
        String requestAuthChannel = isRequestHasAuthChannel(identityVerificationRequest);
        Optional<ISDVerificationChannels> requestResult = handleRequestAuthChannel(
                requestAuthChannel,
                identityTypeFromScopeData,
                requestedIdentityValueFromScopeData,
                consumers,
                consumer,
                isSMSChannelRestricted
        );
        if (requestResult.isPresent()) {
            return requestResult.get();
        }

        // Client type: C2P (not suppressed)
        if (!otpAuthConfig.isOtpSuppressedClientId(clientId)) {
            return handleC2P(identityTypeFromScopeData, identityValueFromScopeData, requestedIdentityValueFromScopeData,
                    consumers, consumer, LOGGER_MESSAGE, isSMSChannelRestricted);
        }

        // AMS (suppressed client)
        return handleAMS(otpAuthConfig, consumer, isSMSChannelRestricted);
    }

    private Optional<ISDVerificationChannels> handleScopeAuthChannel(
            String authChannelFromScopeData,
            String clientId,
            OtpAuthConfig otpAuthConfig,
            Consumer consumer,
            boolean isSMSChannelRestricted
    ) {
        if (StringUtils.isBlank(authChannelFromScopeData) || otpAuthConfig.isOtpSuppressedClientId(clientId)) {
            return Optional.empty();
        }

        ISDVerificationChannels isd = new ISDVerificationChannels();
        String authChannel = null;

        // If scope says EMAIL_OTP => prefer EMAIL, restrict SMS
        if (AuthenticationMethod.EMAIL_OTP.getValue().equalsIgnoreCase(authChannelFromScopeData)) {
            authChannel = AuthenticationChannel.EMAIL.toString();
            isd.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
        }

        // If scope says SMS_OTP AND not restricted => prefer SMS, restrict EMAIL
        if (AuthenticationMethod.SMS_OTP.getValue().equalsIgnoreCase(authChannelFromScopeData) && !isSMSChannelRestricted) {
            authChannel = AuthenticationChannel.SMS.toString();
            isd.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
        }

        String channelRule = "MBL_OTPChannelInScopeData";
        logPreferredChanel(consumer, authChannel, channelRule, METHOD_NAME, LOGGER_MESSAGE, isSMSChannelRestricted);
        isd.setPreferredChannel(authChannel);
        return Optional.of(isd);
    }

    private Optional<ISDVerificationChannels> handleSmsRestricted(
            String identityTypeFromScopeData,
            Consumer consumer,
            boolean isSMSChannelRestricted
    ) {
        if (!isSMSChannelRestricted) {
            return Optional.empty();
        }

        ISDVerificationChannels isd = new ISDVerificationChannels();
        String authChannel = AuthenticationChannel.EMAIL.toString();
        String channelRule = "DefaultEmailChannel_SMSRestrictedCountries";

        logPreferredChanel(consumer, authChannel, channelRule, METHOD_NAME, LOGGER_MESSAGE, true);
        isd.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
        isd.setPreferredChannel(authChannel);

        if (featureConfig.isEnableC2PMultiPii()) {
            // Preserving original behavior (even though it looks odd): sets identityTypeFromScopeData
            isd.setHashedValidationChannelValue(identityTypeFromScopeData);
        }
        return Optional.of(isd);
    }

    private Optional<ISDVerificationChannels> handleRequestAuthChannel(
            String requestAuthChannel,
            String identityTypeFromScopeData,
            String requestedIdentityValueFromScopeData,
            List<Consumer> consumers,
            Consumer consumer,
            boolean isSMSChannelRestricted
    ) {
        if (StringUtils.isBlank(requestAuthChannel)) {
            return Optional.empty();
        }

        // Multi-PII OFF => simple behavior
        if (!featureConfig.isEnableC2PMultiPii()) {
            ISDVerificationChannels isd = new ISDVerificationChannels();
            logPreferredChanel(consumer, requestAuthChannel, null, METHOD_NAME, LOGGER_MESSAGE, isSMSChannelRestricted);
            isd.setPreferredChannel(requestAuthChannel);
            return Optional.of(isd);
        }

        // Multi-PII ON => compute hashes/masks and preferred/restricted as per original logic
        ISDVerificationChannels isd = resolveRequestAuthChannelMultiPii(
                requestAuthChannel,
                identityTypeFromScopeData,
                requestedIdentityValueFromScopeData,
                consumers,
                consumer
        );

        logPreferredChanel(consumer, requestAuthChannel, null, METHOD_NAME, LOGGER_MESSAGE, isSMSChannelRestricted);
        return Optional.of(isd);
    }

    private ISDVerificationChannels resolveRequestAuthChannelMultiPii(
            String authChannel,
            String identityTypeFromScopeData,
            String requestedIdentityValueFromScopeData,
            List<Consumer> consumers,
            Consumer consumer
    ) {
        ISDVerificationChannels isdChannels = new ISDVerificationChannels();

        boolean isEmailAuth = AuthenticationChannel.EMAIL.name().equals(authChannel);
        boolean isSmsAuth = AuthenticationChannel.SMS.name().equals(authChannel);
        boolean isEmailIdentity = IdentityType.EMAIL.name().equals(identityTypeFromScopeData);
        boolean isSmsIdentity = IdentityType.SMS.name().equals(identityTypeFromScopeData);

        Optional<String> preferredEmailHash = getPreferredEmailHash(consumer);
        Optional<String> preferredMobileHash = getPreferredMobileHash(consumer);

        Optional<String> validatedHashedValue = computeValidatedHashedValue(
                isEmailAuth, isSmsAuth, isSmsIdentity, consumers, preferredEmailHash, preferredMobileHash
        );

        if (validatedHashedValue.isPresent()) {
            isdChannels.setPreferredChannel(authChannel);
            populateForValidatedPresent(isdChannels, consumer, isEmailAuth, isEmailIdentity,
                    requestedIdentityValueFromScopeData, preferredEmailHash, preferredMobileHash);
            return isdChannels;
        }

        populateForValidatedAbsent(
                isdChannels,
                consumer,
                isSmsAuth,
                isEmailIdentity,
                identityTypeFromScopeData,
                requestedIdentityValueFromScopeData
        );

        return isdChannels;
    }

    private Optional<String> computeValidatedHashedValue(
            boolean isEmailAuth,
            boolean isSmsAuth,
            boolean isSmsIdentity,
            List<Consumer> consumers,
            Optional<String> preferredEmailHash,
            Optional<String> preferredMobileHash
    ) {
        if (!isEmailAuth && !isSmsAuth) {
            return Optional.empty();
        }
        // Preserving original mapping:
        // If identityTypeFromScopeData is SMS => validate email hash across consumers, else validate mobile hash
        return isSmsIdentity
                ? getValidatedEmailHash(consumers, preferredEmailHash)
                : getValidatedMobileHash(consumers, preferredMobileHash);
    }

    private void populateForValidatedPresent(
            ISDVerificationChannels isd,
            Consumer consumer,
            boolean isEmailAuth,
            boolean isEmailIdentity,
            String requestedIdentityValueFromScopeData,
            Optional<String> preferredEmailHash,
            Optional<String> preferredMobileHash
    ) {
        Optional<String> maskedValue;

        if (isEmailAuth) {
            if (isEmailIdentity) {
                String emailHash = findEmailHash(consumer, requestedIdentityValueFromScopeData).orElse(null);
                isd.setHashedValidationChannelValue(emailHash);
                maskedValue = getEmailAndMaskedEmail(consumer, Optional.ofNullable(emailHash)).getRight();
            } else {
                String mobileHash = findMobileHash(consumer, requestedIdentityValueFromScopeData).orElse(null);

                // non-preferred masked mobile
                setNonPreferredMaskedMobileIfAny(isd, consumer, mobileHash);

                // preferred email as hashed validation channel value
                isd.setHashedValidationChannelValue(preferredEmailHash.orElse(null));
                maskedValue = getEmailAndMaskedEmail(consumer, preferredEmailHash).getRight();
            }
        } else {
            if (isEmailIdentity) {
                String emailHash = findEmailHash(consumer, requestedIdentityValueFromScopeData).orElse(null);

                // preferred mobile as hashed validation channel value
                isd.setHashedValidationChannelValue(preferredMobileHash.orElse(null));
                maskedValue = getMobileAndMaskedPhoneNumber(consumer, preferredMobileHash).getRight();

                // non-preferred masked email
                setNonPreferredMaskedEmailIfAny(isd, consumer, emailHash);
            } else {
                String mobileHash = findMobileHash(consumer, requestedIdentityValueFromScopeData).orElse(null);
                isd.setHashedValidationChannelValue(mobileHash);
                maskedValue = getMobileAndMaskedPhoneNumber(consumer, Optional.ofNullable(mobileHash)).getRight();
            }
        }

        isd.setMaskedValidationChannelValue(maskedValue.orElse(null));
    }

    private void populateForValidatedAbsent(
            ISDVerificationChannels isd,
            Consumer consumer,
            boolean isSmsAuth,
            boolean isEmailIdentity,
            String identityTypeFromScopeData,
            String requestedIdentityValueFromScopeData
    ) {
        // hashedIdentityValue + maskedValue depend only on whether identity is email
        String hashedIdentityValue = isEmailIdentity
                ? findEmailHash(consumer, requestedIdentityValueFromScopeData).orElse(null)
                : findMobileHash(consumer, requestedIdentityValueFromScopeData).orElse(null);

        isd.setHashedValidationChannelValue(hashedIdentityValue);

        Optional<String> maskedValue = isEmailIdentity
                ? getEmailAndMaskedEmail(consumer, Optional.ofNullable(hashedIdentityValue)).getRight()
                : getMobileAndMaskedPhoneNumber(consumer, Optional.ofNullable(hashedIdentityValue)).getRight();

        isd.setMaskedValidationChannelValue(maskedValue.orElse(null));

        // Preferred + restricted:
        // Special case preserved from original: email identity + SMS auth => force EMAIL and restrict SMS
        if (isEmailIdentity && isSmsAuth) {
            isd.setPreferredChannel(AuthenticationChannel.EMAIL.name());
            isd.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
            return;
        }

        // Default behavior preserved: preferredChannel = identityTypeFromScopeData
        isd.setPreferredChannel(identityTypeFromScopeData);

        // Restrict opposite; if identityTypeFromScopeData is unknown, preserve original behavior:
        // original code would restrict EMAIL (since isEmailIdentity==false), so keep same.
        isd.setRestrictedChannelList(Collections.singleton(
                isEmailIdentity ? AuthenticationChannel.SMS : AuthenticationChannel.EMAIL
        ));
    }

    private void setNonPreferredMaskedMobileIfAny(ISDVerificationChannels isd, Consumer consumer, String mobileHash) {
        if (mobileHash == null) {
            return;
        }

        consumer.getIdentities().stream()
                .filter(i -> MOBILE_PHONE_NUMBER_TYPE.equals(i.getType()))
                .filter(i -> Objects.equals(i.getMobile().getHashedCountryCodeWithPhoneNumber(), mobileHash))
                .filter(i -> !i.isPreferred())
                .findFirst()
                .map(i -> i.getMobile().getMaskedPhoneNumber())
                .ifPresent(isd::setNonPreferredMaskedValidationChannelValue);
    }

    private void setNonPreferredMaskedEmailIfAny(ISDVerificationChannels isd, Consumer consumer, String emailHash) {
        if (emailHash == null) {
            return;
        }

        consumer.getIdentities().stream()
                .filter(i -> EMAIL_TYPE.equals(i.getType()))
                .filter(i -> Objects.equals(i.getHashedEmail(), emailHash))
                .filter(i -> !i.isPreferred())
                .findFirst()
                .map(Identity::getMaskedEmail)
                .ifPresent(isd::setNonPreferredMaskedValidationChannelValue);
    }

    private ISDVerificationChannels handleC2P(
            String identityTypeFromScopeData,
            String identityValueFromScopeData,
            String requestedIdentityValueFromScopeData,
            List<Consumer> consumers,
            Consumer consumer,
            String loggerMessage,
            boolean isSMSChannelRestricted
    ) {
        ISDVerificationChannels isd = new ISDVerificationChannels();
        // Feature-flag based rollout:
        // - OFF => execute legacy code paths (no behavior changes)
        // - ON  => execute new Strategy + Decision Table engine
        if (!featureConfig.isEnableNewIsdChannelRuleEngine()) {
            String preferred;
            if (featureConfig.isEnableC2PMultiPii()) {
                preferred = getPreferredPriorityChannelForC2P(
                        consumer,
                        identityTypeFromScopeData,
                        identityValueFromScopeData,
                        requestedIdentityValueFromScopeData,
                        consumers,
                        loggerMessage,
                        isSMSChannelRestricted,
                        isd
                );
            } else {
                preferred = getPreferredChannelForC2p(
                        consumer,
                        identityTypeFromScopeData,
                        consumers,
                        loggerMessage,
                        isSMSChannelRestricted,
                        isd
                );
            }
            isd.setPreferredChannel(preferred);
            return isd;
        }

        IdentityType type = null;
        try {
            if (StringUtils.isNotBlank(identityTypeFromScopeData)) {
                type = IdentityType.valueOf(identityTypeFromScopeData);
            }
        } catch (IllegalArgumentException ignored) {
            // preserve legacy behavior: treat as unknown
        }

        ChannelContext ctx = new ChannelContext(
                consumer,
                consumers,
                type,
                identityValueFromScopeData,
                requestedIdentityValueFromScopeData
        );

        C2PChannelEngine engine = new C2PChannelEngine(List.of(
                new MultiPiiC2PResolver(List.of(new SmsResolutionStrategy(), new EmailResolutionStrategy())),
                new SingleIdentityC2PResolver()
        ));

        C2PMode mode = featureConfig.isEnableC2PMultiPii() ? C2PMode.MULTI_PII : C2PMode.SINGLE_IDENTITY;
        C2PResolution resolution = engine.resolve(mode, ctx, this, isd);

        String preferred = resolution.preferredChannel();
        isd.setPreferredChannel(preferred);

        // Log here (new engine does not log internally)
        String methodName = (mode == C2PMode.MULTI_PII)
                ? "getPreferredPriorityChannelForC2P_refactored"
                : "getPreferredChannelForC2p_refactored";
        logPreferredChanel(consumer, preferred, resolution.channelRule(), methodName, loggerMessage, isSMSChannelRestricted);
        return isd;
    }

    private ISDVerificationChannels handleAMS(
            OtpAuthConfig otpAuthConfig,
            Consumer consumer,
            boolean isSMSChannelRestricted
    ) {
        ISDVerificationChannels isd = new ISDVerificationChannels();
        String channelRule;
        String authChannel;

        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            channelRule = "AMS_NewUser";
            authChannel = otpAuthConfig.getDefaultChannel(); // Step 4
        } else {
            channelRule = "AMS_ReturningUser";
            authChannel = otpAuthConfig.getSuppressedClientChannel(); // Step 5
        }

        logPreferredChanel(consumer, authChannel, channelRule, METHOD_NAME, LOGGER_MESSAGE, isSMSChannelRestricted);
        isd.setPreferredChannel(authChannel);
        return isd;
    }

    private String getPreferredChannelForC2p(Consumer consumer, String identityTypeFromScopeData,
                                             List<Consumer> consumers,
                                             String loggerMessage, boolean isSMSChannelRestricted,
                                             ISDVerificationChannels isdVerificationChannels) {

        String authChannel = null;
        String channelRule = null;
        final String methodName = "getPreferredChannelForC2p";
        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;

        if (IdentityType.EMAIL.name().equals(identityTypeFromScopeData)) {
            //determine whether isAllMobileMatched
            isAllMobileMatched = consumers.stream().allMatch(consumerObject ->
                    consumer.getHashedCountryCodeWithMobile().equals(consumerObject.getHashedCountryCodeWithMobile()));
            isAllEmailMatched = true;
        }
        if (IdentityType.SMS.name().equals(identityTypeFromScopeData)) {
            //determine whether isAllEmailMatched
            isAllEmailMatched = consumers.stream().allMatch(consumerObject ->
                    consumer.getHashedEmail().equals(consumerObject.getHashedEmail()));
            isAllMobileMatched = true;
        }

        //new user
        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            channelRule = "C2P_NewUser";
            authChannel = AuthenticationChannel.SMS.name(); //Step 1
        } else { //returning user
            if (isAllEmailMatched && isAllMobileMatched) {
                channelRule = "C2P_ReturningUser_AllMatched";
                authChannel = AuthenticationChannel.SMS.name(); //3.2 as default and EMAIl as backup
            } else if (isAllEmailMatched) {
                channelRule = "C2P_ReturningUser_EmailMatched";
                authChannel = AuthenticationChannel.EMAIL.name(); //3.3

                isdVerificationChannels.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
            } else if (isAllMobileMatched) {
                channelRule = "C2P_ReturningUser_MobileMatched";
                authChannel = AuthenticationChannel.SMS.name(); //3.4

                isdVerificationChannels.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
            }
        }
        logPreferredChanel(consumer, authChannel, channelRule, methodName, loggerMessage, isSMSChannelRestricted);
        return authChannel;
    }

    private String getPreferredPriorityChannelForC2P(Consumer consumer, String identityTypeFromScopeData, String identityValueFromScopeData,
                                                     String requestedIdentityValueFromScopeData, List<Consumer> consumers,
                                                     String loggerMessage, boolean isSMSChannelRestricted,
                                                     ISDVerificationChannels isdVerificationChannels) {

        String methodName = "getPreferredPriorityChannelForC2P";
        String authChannel = null;
        String channelRule = null;
        Optional<String> matchedPreferredValue = Optional.empty();
        Optional<String> maskedValue;
        Optional<String> email;
        Optional<Mobile> mobile;
        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;
        if (IdentityType.EMAIL.name().equals(identityTypeFromScopeData) || IdentityType.SMS.name().equals(identityTypeFromScopeData)) {
            boolean isSmsType = IdentityType.SMS.name().equals(identityTypeFromScopeData);
            if (isSmsType) {
                Optional<String> preferredEmailHash = getPreferredEmailHash(consumer);
                Optional<String> validatedEmailHash = getValidatedEmailHash(consumers, preferredEmailHash);
                isAllEmailMatched = validatedEmailHash.isPresent();
                isAllMobileMatched = true;
                matchedPreferredValue = lookupPhoneOtpValue(
                        consumer,
                        requestedIdentityValueFromScopeData,
                        identityValueFromScopeData
                );
            } else {
                Optional<String> preferredMobileHash = getPreferredMobileHash(consumer);
                Optional<String> validatedMobileHash = getValidatedMobileHash(consumers, preferredMobileHash);
                isAllEmailMatched = true;
                isAllMobileMatched = validatedMobileHash.isPresent();
                if (!isAllMobileMatched) {
                    matchedPreferredValue = lookupEmailOtpValue(
                            consumer,
                            requestedIdentityValueFromScopeData,
                            identityValueFromScopeData
                    );
                } else {
                    matchedPreferredValue = validatedMobileHash.or(() -> Optional.ofNullable(consumer.getHashedCountryCodeWithMobile()));
                }
            }
        }

        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            channelRule = "C2P_NewUser";
            authChannel = AuthenticationChannel.SMS.name();
            logPreferredChanel(consumer, authChannel, channelRule, methodName, loggerMessage, isSMSChannelRestricted);
            return authChannel;
        }

        if (isAllEmailMatched && isAllMobileMatched) {
            channelRule = "C2P_ReturningUser_AllMatched";
            authChannel = AuthenticationChannel.SMS.name();
            Pair<Optional<Mobile>, Optional<String>> mobileAndMaskedPhoneNumber = getMobileAndMaskedPhoneNumber(consumer, matchedPreferredValue);
            mobile = mobileAndMaskedPhoneNumber.getLeft();
            maskedValue = mobileAndMaskedPhoneNumber.getRight();
            isdVerificationChannels.setHashedValidationChannelValue(matchedPreferredValue.orElse(null));
            isdVerificationChannels.setMaskedValidationChannelValue(maskedValue.orElse(null));
            isdVerificationChannels.setMobile(mobile.orElse(null));
        } else if (isAllEmailMatched) {
            channelRule = "C2P_ReturningUser_EmailMatched";
            authChannel = AuthenticationChannel.EMAIL.name();
            Pair<Optional<String>, Optional<String>> emailAndMaskedEmail = getEmailAndMaskedEmail(consumer, matchedPreferredValue);
            email = emailAndMaskedEmail.getLeft();
            maskedValue = emailAndMaskedEmail.getRight();
            isdVerificationChannels.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
            isdVerificationChannels.setHashedValidationChannelValue(matchedPreferredValue.orElse(null));
            isdVerificationChannels.setMaskedValidationChannelValue(maskedValue.orElse(null));
            isdVerificationChannels.setEmail(email.orElse(null));
        } else if (isAllMobileMatched) {
            channelRule = "C2P_ReturningUser_MobileMatched";
            authChannel = AuthenticationChannel.SMS.name();
            Pair<Optional<Mobile>, Optional<String>> mobileAndMaskedPhoneNumber = getMobileAndMaskedPhoneNumber(consumer, matchedPreferredValue);
            mobile = mobileAndMaskedPhoneNumber.getLeft();
            maskedValue = mobileAndMaskedPhoneNumber.getRight();
            isdVerificationChannels.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
            isdVerificationChannels.setHashedValidationChannelValue(matchedPreferredValue.orElse(null));
            isdVerificationChannels.setMaskedValidationChannelValue(maskedValue.orElse(null));
            isdVerificationChannels.setMobile(mobile.orElse(null));
        }
        logPreferredChanel(consumer, authChannel, channelRule, methodName, loggerMessage, isSMSChannelRestricted);
        return authChannel;
    }

    @Override
    public Optional<String> lookupEmailOtpValue(Consumer consumer, String requestedEmail, String fallbackHash) {
        return Optional.of(
                consumer.getIdentities().stream()
                        .filter(identity -> EMAIL_TYPE.equals(identity.getType()))
                        .filter(identity -> requestedEmail != null && requestedEmail.equalsIgnoreCase(identity.getEmail()))
                        .map(Identity::getHashedEmail)
                        .findFirst()
                        .orElse(fallbackHash)
        );
    }

    private void logPreferredChanel(Consumer consumer, String authChannel, String channelRule, String methodName,
                                    String loggerMessage, boolean isSMSChannelRestricted) {
        LOGGER.info(new CommonLogFormatter.Builder()
                .withMessage(loggerMessage)
                .withMethodName(methodName)
                .withMethodParamsKeyValPair(AUTH_CHANNEL, authChannel)
                .withMethodParamsKeyValPair(DataConstants.CHANNEL_RULE, channelRule)
                .withMethodParamsKeyValPair(DataConstants.CONSUMER_ID, consumer.getConsumerId())
                .withMethodParamsKeyValPair(DataConstants.CONSUMER_VERIFICATION_CHANNEL, consumer.getVerificationChannel())
                .withMethodParamsKeyValPair(DataConstants.IS_SMS_CHANNEL_RESTRICTED, String.valueOf(isSMSChannelRestricted))
                .withMethodParamsKeyValPair(DataConstants.MOBILE_COUNTRY_CODE, consumer.getMobileCountryCode()));
    }

    private <T> String isRequestHasAuthChannel(T identityVerificationRequest) {
        String authChannel = null;
        if (identityVerificationRequest instanceof IdentityVerificationRequest identityRequest && ofNullable(identityRequest.getRequestedValidationChannel())
                .map(IdentityValidationChannel::getIdentityType).isPresent()) {
            authChannel = identityRequest.getRequestedValidationChannel().getIdentityType().name();
        } else if (identityVerificationRequest instanceof InternalIdentityVerificationRequest internalIdentityRequest
                && ofNullable(internalIdentityRequest.getInternalIdentityValidationChannel())
                .map(InternalIdentityValidationChannel::getIdentityType).isPresent()) {
            authChannel = internalIdentityRequest.getInternalIdentityValidationChannel().getIdentityType().name();
        }
        return authChannel;
    }

    @Override
    public Optional<String> getValidatedMobileHash(List<Consumer> consumers, Optional<String> preferredMobileHash) {
        return preferredMobileHash.filter(hash -> consumers.stream()
                .allMatch(c -> Stream.concat(
                        Optional.ofNullable(c.getIdentities())
                                .orElse(Collections.emptyList())
                                .stream()
                                .filter(id -> MOBILE_PHONE_NUMBER_TYPE.equals(id.getType()))
                                .map(id -> id.getMobile().getHashedCountryCodeWithPhoneNumber()),
                        Stream.ofNullable(c.getHashedCountryCodeWithMobile())
                ).filter(Objects::nonNull).anyMatch(hash::equals)));
    }

    @Override
    public Optional<String> getPreferredMobileHash(Consumer consumer) {
        return Optional.ofNullable(consumer.getIdentities())
                .orElse(Collections.emptyList())
                .stream()
                .filter(identity -> MOBILE_PHONE_NUMBER_TYPE.equals(identity.getType()) && identity.isPreferred())
                .map(id -> id.getMobile().getHashedCountryCodeWithPhoneNumber())
                .findFirst()
                .or(() -> Optional.ofNullable(consumer.getHashedCountryCodeWithMobile()));
    }

    @Override
    public Optional<String> getPreferredEmailHash(Consumer consumer) {
        return Optional.ofNullable(consumer.getIdentities())
                .orElse(Collections.emptyList())
                .stream()
                .filter(identity -> EMAIL_TYPE.equals(identity.getType()) && identity.isPreferred())
                .map(Identity::getHashedEmail)
                .findFirst()
                .or(() -> Optional.ofNullable(consumer.getHashedEmail()));
    }

    @Override
    public Optional<String> getValidatedEmailHash(List<Consumer> consumers, Optional<String> preferredEmailHash) {
        return preferredEmailHash.filter(hash -> consumers.stream()
                .allMatch(c -> Stream.concat(
                        Optional.ofNullable(c.getIdentities())
                                .orElse(Collections.emptyList())
                                .stream()
                                .filter(id -> EMAIL_TYPE.equals(id.getType()))
                                .map(Identity::getHashedEmail),
                        Stream.ofNullable(c.getHashedEmail())
                ).filter(Objects::nonNull).anyMatch(hash::equals)));
    }

    @Override
    public Pair<Optional<Mobile>, Optional<String>> getMobileAndMaskedPhoneNumber(Consumer consumer, Optional<String> matchedPreferredValue) {
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(id -> MOBILE_PHONE_NUMBER_TYPE.equals(id.getType()))
                .filter(id -> matchedPreferredValue.isPresent() && matchedPreferredValue.get().equals(id.getMobile().getHashedCountryCodeWithPhoneNumber()))
                .findFirst()
                .map(id -> Pair.of(Optional.of(id.getMobile()),
                        Optional.of("+" + id.getMobile().getCountryCode() + id.getMobile().getMaskedPhoneNumber())))
                .orElse(Pair.of(Optional.empty(), Optional.empty()));
    }

    @Override
    public Pair<Optional<String>, Optional<String>> getEmailAndMaskedEmail(Consumer consumer, Optional<String> matchedPreferredValue) {
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(id -> EMAIL_TYPE.equals(id.getType()))
                .filter(id -> matchedPreferredValue.isPresent() && matchedPreferredValue.get().equals(id.getHashedEmail()))
                .findFirst()
                .map(id -> Pair.of(Optional.of(id.getEmail()), Optional.of(id.getMaskedEmail())))
                .orElse(Pair.of(Optional.empty(), Optional.empty()));
    }

    public Optional<String> findEmailHash(Consumer consumer, String email) {
        return consumer.getIdentities().stream()
                .filter(i -> EMAIL_TYPE.equals(i.getType()))
                .filter(i -> email.equalsIgnoreCase(i.getEmail()))
                .map(Identity::getHashedEmail)
                .findFirst();
    }

    private Optional<String> findMobileHash(Consumer consumer, String value) {
        return consumer.getIdentities().stream()
                .filter(i -> MOBILE_PHONE_NUMBER_TYPE.equals(i.getType()))
                .filter(i -> {
                    Mobile mobile = i.getMobile();
                    return value.equals(mobile.getCountryCode() + mobile.getPhoneNumber());
                })
                .map(i -> i.getMobile().getHashedCountryCodeWithPhoneNumber())
                .findFirst();
    }

    @Override
    public Optional<String> lookupPhoneOtpValue(Consumer consumer, String requestedIdentityValueFromScopeData, String identityValueFromScopeData
    ) {
        return Optional.of(
                consumer.getIdentities().stream()
                        .filter(identity -> MOBILE_PHONE_NUMBER_TYPE.equals(identity.getType()))
                        .filter(identity -> {
                            if (StringUtils.isEmpty(requestedIdentityValueFromScopeData)) {
                                return false;
                            }
                            String countryCode = identity.getMobile().getCountryCode();
                            String identityPhone = identity.getMobile().getPhoneNumber();
                            String localScopePhone = requestedIdentityValueFromScopeData.startsWith(countryCode)
                                    ? requestedIdentityValueFromScopeData.substring(countryCode.length())
                                    : requestedIdentityValueFromScopeData;
                            return localScopePhone.equals(identityPhone);
                        })
                        .map(identity ->
                                identity.getMobile().getHashedCountryCodeWithPhoneNumber()
                        )
                        .findFirst()
                        .orElse(identityValueFromScopeData)
        );
    }

}