package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;

import java.util.List;

/**
 * Future-ready placeholder for SINGLE_PII.
 *
 * Today, SINGLE_PII behavior matches legacy getPreferredChannelForC2p (no multi-PII enrichments).
 */
public final class SinglePiiC2PModeResolver implements C2PModeResolver {

    @Override
    public C2PMode mode() {
        return C2PMode.SINGLE_PII;
    }

    @Override
    public String resolve(ChannelContext ctx, IdentityOps ops, ISDVerificationChannels isd) {
        Consumer consumer = ctx.consumer();
        List<Consumer> consumers = ctx.consumers();
        String identityType = ctx.identityTypeFromScopeData() == null ? null : ctx.identityTypeFromScopeData().name();

        boolean allEmailMatched = false;
        boolean allMobileMatched = false;

        if (IdentityType.EMAIL.name().equals(identityType)) {
            allMobileMatched = consumers.stream().allMatch(c ->
                    consumer.getHashedCountryCodeWithMobile().equals(c.getHashedCountryCodeWithMobile()));
            allEmailMatched = true;
        }

        if (IdentityType.SMS.name().equals(identityType)) {
            allEmailMatched = consumers.stream().allMatch(c ->
                    consumer.getHashedEmail().equals(c.getHashedEmail()));
            allMobileMatched = true;
        }

        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            return AuthenticationChannel.SMS.name();
        }

        C2PDecisionTable decision = C2PDecisionTable.resolve(allEmailMatched, allMobileMatched);
        if (decision == null) {
            return null;
        }

        // restricted channels behavior matches legacy
        if (decision == C2PDecisionTable.EMAIL_MATCHED) {
            isd.setRestrictedChannelList(java.util.Collections.singleton(AuthenticationChannel.SMS));
        } else if (decision == C2PDecisionTable.MOBILE_MATCHED) {
            isd.setRestrictedChannelList(java.util.Collections.singleton(AuthenticationChannel.EMAIL));
        }

        return decision.preferredChannel().name();
    }
}
