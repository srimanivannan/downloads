package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.generated.emvco.model.IdentityType;

import java.util.Optional;

public interface IdentityResolutionStrategy {

    IdentityType supports();

    Resolution resolve(ChannelContext ctx, IdentityOps ops);

    record Resolution(
            boolean allEmailMatched,
            boolean allMobileMatched,
            Optional<String> matchedPreferredHash,
            Optional<String> switchingHash
    ) {}
}
