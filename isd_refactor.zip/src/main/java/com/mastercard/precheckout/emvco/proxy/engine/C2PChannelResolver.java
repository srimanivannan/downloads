package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.Mobile;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * New engine for C2P channel resolution.
 *
 * - MULTI_PII mode: equivalent to legacy getPreferredPriorityChannelForC2P
 * - SINGLE_IDENTITY_PII mode: equivalent to legacy getPreferredChannelForC2p
 */
public final class C2PChannelResolver {

    private final Map<String, IdentityResolutionStrategy> strategiesByIdentityType;

    public C2PChannelResolver(List<IdentityResolutionStrategy> strategies) {
        this.strategiesByIdentityType = strategies.stream()
                .collect(Collectors.toMap(s -> s.supports().name(), Function.identity()));
    }

    public String resolve(
            C2PMode mode,
            ChannelContext ctx,
            IdentityOps ops,
            ISDVerificationChannels out
    ) {
        return switch (mode) {
            case MULTI_PII -> resolveMultiPii(ctx, ops, out);
            case SINGLE_IDENTITY_PII -> resolveSinglePii(ctx, out);
        };
    }

    private String resolveSinglePii(ChannelContext ctx, ISDVerificationChannels out) {
        Consumer consumer = ctx.consumer();
        String identityType = ctx.identityTypeFromScopeData() == null ? null : ctx.identityTypeFromScopeData().name();

        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;

        if (IdentityType.EMAIL.name().equals(identityType)) {
            isAllMobileMatched = ctx.consumers().stream().allMatch(c ->
                    eqNullable(consumer.getHashedCountryCodeWithMobile(), c.getHashedCountryCodeWithMobile()));
            isAllEmailMatched = true;
        } else if (IdentityType.SMS.name().equals(identityType)) {
            isAllEmailMatched = ctx.consumers().stream().allMatch(c ->
                    eqNullable(consumer.getHashedEmail(), c.getHashedEmail()));
            isAllMobileMatched = true;
        }

        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            return AuthenticationChannel.SMS.name();
        }

        // returning user
        if (isAllEmailMatched && isAllMobileMatched) {
            return AuthenticationChannel.SMS.name();
        }
        if (isAllEmailMatched) {
            out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
            return AuthenticationChannel.EMAIL.name();
        }
        if (isAllMobileMatched) {
            out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
            return AuthenticationChannel.SMS.name();
        }
        return null;
    }

    private String resolveMultiPii(ChannelContext ctx, IdentityOps ops, ISDVerificationChannels out) {
        Consumer consumer = ctx.consumer();

        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            return AuthenticationChannel.SMS.name();
        }

        String identityType = ctx.identityTypeFromScopeData() == null ? null : ctx.identityTypeFromScopeData().name();
        IdentityResolutionStrategy strategy = strategiesByIdentityType.get(identityType);
        if (strategy == null) {
            return null;
        }

        IdentityResolutionStrategy.Resolution resolution = strategy.resolve(ctx, ops);
        C2PDecisionTable decision = C2PDecisionTable.resolve(resolution.allEmailMatched(), resolution.allMobileMatched());
        if (decision == null) {
            return null;
        }

        Optional<String> matched = resolution.matchedPreferredHash();

        switch (decision) {
            case ALL_MATCHED -> {
                Pair<Optional<Mobile>, Optional<String>> mobileAndMasked = ops.getMobileAndMaskedPhoneNumber(consumer, matched);
                out.setHashedValidationChannelValue(matched.orElse(null));
                out.setMaskedValidationChannelValue(mobileAndMasked.getRight().orElse(null));
                out.setMobile(mobileAndMasked.getLeft().orElse(null));
                return decision.preferredChannel().name();
            }
            case EMAIL_MATCHED -> {
                Pair<Optional<String>, Optional<String>> emailAndMasked = ops.getEmailAndMaskedEmail(consumer, matched);
                out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
                out.setHashedValidationChannelValue(ctx.identityValueFromScopeData());
                out.setMaskedValidationChannelValue(emailAndMasked.getRight().orElse(null));
                out.setEmail(emailAndMasked.getLeft().orElse(null));
                return decision.preferredChannel().name();
            }
            case MOBILE_MATCHED -> {
                Pair<Optional<Mobile>, Optional<String>> mobileAndMasked = ops.getMobileAndMaskedPhoneNumber(consumer, matched);
                out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
                out.setHashedValidationChannelValue(ctx.identityValueFromScopeData());
                out.setMaskedValidationChannelValue(mobileAndMasked.getRight().orElse(null));
                out.setMobile(mobileAndMasked.getLeft().orElse(null));
                return decision.preferredChannel().name();
            }
        }
        return null;
    }

    private static boolean eqNullable(String a, String b) {
        if (a == null) return b == null;
        return a.equals(b);
    }
}
