package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;

import java.util.Optional;

/**
 * IdentityType.EMAIL strategy for Multi-PII C2P.
 * Matches current legacy behavior:
 * - allEmailMatched = true
 * - allMobileMatched = validatedMobileHash.isPresent()
 * - switchingHash = lookupEmailOtpValue(...)
 * - matchedPreferredHash = if allMobileMatched => validatedMobileHash or consumer fallback
 *                         else lookupEmailOtpValue(...)
 */
public final class EmailResolutionStrategy implements IdentityResolutionStrategy {

    @Override
    public IdentityType supports() {
        return IdentityType.EMAIL;
    }

    @Override
    public Resolution resolve(ChannelContext ctx, IdentityOps ops) {
        Consumer consumer = ctx.consumer();

        Optional<String> preferredMobileHash = ops.getPreferredMobileHash(consumer);
        Optional<String> validatedMobileHash = ops.getValidatedMobileHash(ctx.consumers(), preferredMobileHash);

        boolean allEmailMatched = true;
        boolean allMobileMatched = validatedMobileHash.isPresent();

        Optional<String> switchingHash = ops.lookupEmailOtpValue(
                consumer,
                ctx.requestedIdentityValueFromScopeData(),
                ctx.identityValueFromScopeData()
        );

        Optional<String> matchedPreferred = allMobileMatched
                ? validatedMobileHash.or(() -> Optional.ofNullable(consumer.getHashedCountryCodeWithMobile()))
                : switchingHash;

        return new Resolution(allEmailMatched, allMobileMatched, matchedPreferred, switchingHash);
    }
}
