package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;

import java.util.List;

/**
 * Immutable request-scoped context for C2P channel resolution.
 */
public record ChannelContext(
        Consumer consumer,
        List<Consumer> consumers,
        IdentityType identityTypeFromScopeData,
        String identityValueFromScopeData,
        String requestedIdentityValueFromScopeData
) {
}
