package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.Mobile;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Multi-PII C2P resolver replacing getPreferredPriorityChannelForC2P.
 * Uses IdentityResolutionStrategy + decision table instead of nested branching.
 */
public final class MultiPiiC2PResolver implements C2PModeResolver {

    private final Map<String, IdentityResolutionStrategy> byIdentityType;

    public MultiPiiC2PResolver(List<IdentityResolutionStrategy> strategies) {
        this.byIdentityType = strategies.stream()
                .collect(Collectors.toMap(s -> s.supports().name(), Function.identity()));
    }

    @Override
    public C2PMode supports() {
        return C2PMode.MULTI_PII;
    }

    @Override
    public C2PResolution resolve(ChannelContext ctx, IdentityOps ops, ISDVerificationChannels out) {

        // New user -> always SMS
        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(ctx.consumer().getStatus())) {
            return new C2PResolution(AuthenticationChannel.SMS.name(), "C2P_NewUser");
        }

        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;
        Optional<String> matchedPreferred = Optional.empty();
        // NOTE: the latest legacy implementation does not set hashedSwitchingChannelValue.
        // We keep the concept available via strategies for future extensions,
        // but we intentionally do not populate it today to avoid behavior changes.
        @SuppressWarnings("unused")
        Optional<String> switchingHash = Optional.empty();

        if (ctx.identityTypeFromScopeData() != null) {
            IdentityResolutionStrategy strategy = byIdentityType.get(ctx.identityTypeFromScopeData().name());
            if (strategy != null) {
                IdentityResolutionStrategy.Resolution res = strategy.resolve(ctx, ops);
                isAllEmailMatched = res.allEmailMatched();
                isAllMobileMatched = res.allMobileMatched();
                matchedPreferred = res.matchedPreferredHash();
                switchingHash = res.switchingHash();
            }
        }

        C2PDecisionTable decision = C2PDecisionTable.resolve(isAllEmailMatched, isAllMobileMatched);
        if (decision == null) {
            // Preserve legacy behavior: return null channel when no match
            return new C2PResolution(null, null);
        }

        String authChannel = decision.preferredChannel().name();
        String channelRule = decision.channelRule();

        switch (decision) {
            case ALL_MATCHED -> {
                Pair<Optional<Mobile>, Optional<String>> mobileAndMasked =
                        ops.getMobileAndMaskedPhoneNumber(ctx.consumer(), matchedPreferred);
                out.setHashedValidationChannelValue(matchedPreferred.orElse(null));
                out.setMaskedValidationChannelValue(mobileAndMasked.getRight().orElse(null));
                out.setMobile(mobileAndMasked.getLeft().orElse(null));
            }
            case EMAIL_MATCHED -> {
                var emailAndMasked = ops.getEmailAndMaskedEmail(ctx.consumer(), matchedPreferred);
                out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
                out.setHashedValidationChannelValue(matchedPreferred.orElse(null));
                out.setMaskedValidationChannelValue(emailAndMasked.getRight().orElse(null));
                out.setEmail(emailAndMasked.getLeft().orElse(null));
            }
            case MOBILE_MATCHED -> {
                var mobileAndMasked = ops.getMobileAndMaskedPhoneNumber(ctx.consumer(), matchedPreferred);
                out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
                out.setHashedValidationChannelValue(matchedPreferred.orElse(null));
                out.setMaskedValidationChannelValue(mobileAndMasked.getRight().orElse(null));
                out.setMobile(mobileAndMasked.getLeft().orElse(null));
            }
        }

        return new C2PResolution(authChannel, channelRule);
    }
}
