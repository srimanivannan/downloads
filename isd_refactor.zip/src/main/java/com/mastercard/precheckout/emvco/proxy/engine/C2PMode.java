package com.mastercard.precheckout.emvco.proxy.engine;

public enum C2PMode {
    SINGLE_IDENTITY,
    MULTI_PII
}
