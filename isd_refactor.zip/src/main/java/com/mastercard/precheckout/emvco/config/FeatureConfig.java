package com.mastercard.precheckout.emvco.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import com.mastercard.alberta.common.client.service.dff.DynamicFeatureFlagService;

@Getter
@Setter
@Configuration
@RefreshScope
@ConfigurationProperties(prefix = "feature-flags")
public class FeatureConfig {

    @Autowired
    private DynamicFeatureFlagService dynamicFeatureFlagService;

    @Value("${bulk-provisioning: false}")
    private boolean bulkProvisioning;

    @Value("${consent-verification: false}")
    private boolean consentVerification;

    @Value("${header-mdes-recommendation: false}")
    private boolean headerMdesRecommendation;

    @Value("${embedded-checkout: false}")
    private boolean embeddedCheckout;

    @Value("${consumer-mobile-lookup: false}")
    private boolean consumerMobileLookup;

    @Value("${oob-auth-session: false}")
    private boolean oobAuthSession;

    @Value("${rate-limiter-enabled: false}")
    private boolean rateLimiterEnabled;

    @Value("${app-instance-unbind: false}")
    private boolean appInstanceUnbind;

    @Value("${enable-static-token: false}")
    private boolean enableStaticToken;

    @Value("${third-party-wallet-enabled: false}")
    private boolean thirdPartyWalletEnabled;

    @Value("${enable-payment-authentication: false}")
    private boolean enablePaymentAuthentication;

    @Value("${mc-recognition-token-enabled: false}")
    private boolean mcRecognitionTokenEnabled;

    @Value("${enable-blc-card-metadata-update: false}")
    private boolean enableBlcCardMetadataUpdate;

    @Value("${checkout-payload-indicator: false}")
    private boolean checkoutPayloadIndicator;

    @Value("${issuer-segregated-directory: false}")
    private boolean issuerSegregatedDirectory;

    @Value("${enable-fido-enrollment: false}")
    private boolean enableFidoEnrollment;

    @Value("${enhance-bulk-card-response: false}")
    private boolean enhanceBulkCardResponse;

    @Value("${disallow-add-card-profile-management: false}")
    private boolean disallowAddCardProfileManagement;

    @Value("${enable-guest-checkout: false}")
    private boolean enableGuestCheckout;

    @Value("${enable-cvc-step-up: false}")
    private boolean enableCvcStepUp;

    @Value("${enable-manual-pan-entry: false}")
    private boolean enableManualPanEntry;

    @Value("${traceId-rateLimiter-enabled: true}")
    private boolean traceIdRateLimiterEnabled;

    @Value("${enable-issuer-authentication: false}")
    private boolean enableIssuerAuthentication;

    @Value("${enable-redis-template-code: true}")
    private boolean enableRedisTemplateCode;

    @Value("${enable-fpan-filter: false}")
    private boolean enableFpanFilter;

    @Value("${enable-auto-enroll-company-validation: false}")
    private boolean enableAutoEnrollCompanyValidation;

    @Value("${enable-enc-retention-period: false}")
    private boolean enableRetentionPeriod;

    @Value("${enable-pfl-passkey: false}")
    private boolean enablePflPasskey;

    @Value("${is-installments-enabled: false}")
    private boolean enableInstallmentEligibility;

    @Value("${enable-open-banking: false}")
    private boolean enableOpenBanking;

    @Value("${enable-pfl-lookup: false}")
    private boolean enablePflLookup;

    @Value("${enable-push-notification-or-rba:false}")
    private boolean enablePushNotificationOrRba;

    @Value("${enable-issuer-authentication-restricted-2fa:false}")
    private boolean enableIssuerauthenticationRestricted2fa;

    @Value("${enable-ilp-flow: false}")
    private boolean enableILPFlow;

    @Value("${enable-b2b-endpoints:false}")
    private boolean enableB2bEndpoints;

    @Value("${enable-isd-allowed-programs:false}")
    private boolean enableILPBackup;

    @Value("${database-cache-enabled:false}")
    private boolean databaseCacheEnabled;

    @Value("${enable-missing-token-event:false}")
    private boolean enableMissingTokenEvent;

    @Value("${E98576.AAC.20250818.PreCheckout.C2P.multiPiiEnabled:false}")
    private boolean enableC2PMultiPii;

    /**
     * New ISD channel rule engine (Strategy + Decision Table) kill-switch.
     * Default OFF for safe rollout.
     */
    @Value("${E98576.AAC.20260118.PreCheckout.ISD.NewChannelRuleEngine:false}")
    private boolean enableNewIsdChannelRuleEngine;
    
    @Value("${E82710.ADL.20251107.C2P.Checkout.AssuranceData.3DS.Loopback:false}")
    private boolean enableAssuranceDataLoopback;

    @Value("${suppress-repeating-nudetect-calls:true}")
    private boolean suppressRepeatingNuDetectCalls;

    @Value("${enable-mcid-token-generation-for-b2c:false}")
    private boolean enableMcidTokenGenerationForB2C;


    //Use this instead of lombok plugin generated methods
    public boolean isEnablePaymentAuth() {
        return enablePaymentAuthentication;
    }

    public void setEnablePaymentAuth(boolean enablePaymentAuthentication) {
        this.enablePaymentAuthentication = enablePaymentAuthentication;
    }

    public boolean isIssuerSegregatedDirectory() {
        return dynamicFeatureFlagService.isFeatureEnabled("issuer-segregated-directory", issuerSegregatedDirectory);
    }

    public boolean isEnhanceBulkCardResponse() {
        return dynamicFeatureFlagService.isFeatureEnabled("enhance-bulk-card-response", enhanceBulkCardResponse);
    }

    public boolean isMcRecognitionTokenEnabled() {
        return dynamicFeatureFlagService.isFeatureEnabled("mc-recognition-token-enabled", mcRecognitionTokenEnabled);
    }

    public boolean isConsentVerification() {
        return dynamicFeatureFlagService.isFeatureEnabled("consent-verification", consentVerification);
    }

    public boolean isDisallowingAddCardProfileManagement() {
        return dynamicFeatureFlagService.isFeatureEnabled("disallow-add-card-profile-management", disallowAddCardProfileManagement);
    }

    public boolean isEnableGuestCheckout() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-guest-checkout", enableGuestCheckout);
    }

    public boolean isEnableCvcStepUp() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-cvc-step-up", enableCvcStepUp);
    }

    public boolean isRateLimiterEnabled() {
        return dynamicFeatureFlagService.isFeatureEnabled("rate-limiter-enabled", rateLimiterEnabled);
    }

    public boolean isEnableManualPanEntry() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-manual-pan-entry", enableManualPanEntry);
    }

    public boolean isTraceIdRateLimiterEnabled() {
        return dynamicFeatureFlagService.isFeatureEnabled("traceId-rateLimiter-enabled", traceIdRateLimiterEnabled);
    }

    public boolean isEnableNewIsdChannelRuleEngine() {
        return dynamicFeatureFlagService.isFeatureEnabled(
                "E98576.AAC.20260118.PreCheckout.ISD.NewChannelRuleEngine",
                enableNewIsdChannelRuleEngine
        );
    }

    public boolean isEnableIssuerAuthentication() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-issuer-authentication", enableIssuerAuthentication);
    }

    public boolean isEnableFpanFilter() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-fpan-filter", enableFpanFilter);
    }

    public boolean isOobAuthSession() {
        return dynamicFeatureFlagService.isFeatureEnabled("oob-auth-session", oobAuthSession);
    }

    public boolean isEnableAutoEnrollCompanyValidation() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-auto-enroll-company-validation", enableAutoEnrollCompanyValidation);
    }

    public boolean isRetentionPeriod() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-enc-retention-period", enableRetentionPeriod);
    }

    public boolean isEnablePflPasskey() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-pfl-passkey", enablePflPasskey);
    }

    public boolean isEnableInstallmentEligibility() {
        return dynamicFeatureFlagService.isFeatureEnabled("is-installments-enabled", enableInstallmentEligibility);
    }

    public boolean isEnableOpenBanking() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-open-banking", enableOpenBanking);
    }

    public boolean isEnablePflLookup() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-pfl-lookup", enablePflLookup);
    }

    public boolean isEnablePushNotificationOrRba() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-push-notification-or-rba", enablePushNotificationOrRba);
    }

    public boolean isEnableIssuerauthenticationRestricted2fa() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-issuer-authentication-restricted-2fa", enableIssuerauthenticationRestricted2fa);
    }

    public boolean isEnableCombinedISDCall() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-ilp-flow", enableILPFlow);
    }

    public boolean isEnableB2bEndpoints() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-b2b-endpoints", enableB2bEndpoints);
    }

    public boolean isEnableILPBackup() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-isd-allowed-programs", enableILPBackup);
    }

    public boolean isDatabaseCacheEnabled() {
        return dynamicFeatureFlagService.isFeatureEnabled("database-cache-enabled", databaseCacheEnabled);
    }

    public boolean isEnableMissingTokenEvent() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-missing-token-event", enableMissingTokenEvent);
    }

    public boolean isEnableC2PMultiPii() {
        return dynamicFeatureFlagService.isFeatureEnabled("E98576.AAC.20250818.PreCheckout.C2P.multiPiiEnabled", enableC2PMultiPii);
    }
    
    public boolean isEnableAssuranceDataLoopback() {
        return dynamicFeatureFlagService.isFeatureEnabled("E82710.ADL.20251107.C2P.Checkout.AssuranceData.3DS.Loopback", enableAssuranceDataLoopback);
    }
    
    public boolean shouldSuppressRepeatingNudetectCalls() {
        return dynamicFeatureFlagService.isFeatureEnabled("suppress-repeating-nudetect-calls", suppressRepeatingNuDetectCalls);
    }

    public boolean isEnableMcidTokenGenerationForB2C() {
        return dynamicFeatureFlagService.isFeatureEnabled("enable-mcid-token-generation-for-b2c", enableMcidTokenGenerationForB2C);
    }
    
}