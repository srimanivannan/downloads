package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.Mobile;
import org.apache.commons.lang3.tuple.Pair;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Strategy + decision-table based implementation for Multi-PII C2P (matches legacy getPreferredPriorityChannelForC2P).
 */
public final class MultiPiiC2PModeResolver implements C2PModeResolver {

    private final Map<String, IdentityResolutionStrategy> strategiesByIdentity;

    public MultiPiiC2PModeResolver(List<IdentityResolutionStrategy> strategies) {
        this.strategiesByIdentity = strategies.stream()
                .collect(Collectors.toMap(s -> s.supports().name(), Function.identity()));
    }

    @Override
    public C2PMode mode() {
        return C2PMode.MULTI_PII;
    }

    @Override
    public String resolve(ChannelContext ctx, IdentityOps ops, ISDVerificationChannels isd) {
        Consumer consumer = ctx.consumer();

        // New user always SMS (matches legacy)
        if (ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())) {
            return AuthenticationChannel.SMS.name();
        }

        IdentityResolutionStrategy strategy = ctx.identityTypeFromScopeData() == null
                ? null
                : strategiesByIdentity.get(ctx.identityTypeFromScopeData().name());

        if (strategy == null) {
            // Preserve legacy default: authChannel remains null
            return null;
        }

        IdentityResolutionStrategy.Resolution resolution = strategy.resolve(ctx, ops);
        boolean allEmailMatched = resolution.allEmailMatched();
        boolean allMobileMatched = resolution.allMobileMatched();
        Optional<String> matchedPreferred = resolution.matchedPreferredHash();
        Optional<String> switchingHash = resolution.switchingHash();

        C2PDecisionTable decision = C2PDecisionTable.resolve(allEmailMatched, allMobileMatched);
        if (decision == null) {
            return null;
        }

        String authChannel = decision.preferredChannel().name();

        if (decision == C2PDecisionTable.ALL_MATCHED) {
            Pair<Optional<Mobile>, Optional<String>> mobileAndMasked = ops.getMobileAndMaskedPhoneNumber(consumer, matchedPreferred);
            isd.setHashedValidationChannelValue(matchedPreferred.orElse(null));
            isd.setHashedSwitchingChannelValue(switchingHash.orElse(null));
            isd.setMaskedValidationChannelValue(mobileAndMasked.getRight().orElse(null));
            isd.setMobile(mobileAndMasked.getLeft().orElse(null));
            return authChannel;
        }

        if (decision == C2PDecisionTable.EMAIL_MATCHED) {
            var emailAndMasked = ops.getEmailAndMaskedEmail(consumer, matchedPreferred);
            isd.setRestrictedChannelList(java.util.Collections.singleton(AuthenticationChannel.SMS));
            isd.setHashedValidationChannelValue(ctx.identityValueFromScopeData());
            isd.setMaskedValidationChannelValue(emailAndMasked.getRight().orElse(null));
            isd.setEmail(emailAndMasked.getLeft().orElse(null));
            return authChannel;
        }

        // MOBILE_MATCHED
        Pair<Optional<Mobile>, Optional<String>> mobileAndMasked = ops.getMobileAndMaskedPhoneNumber(consumer, matchedPreferred);
        isd.setRestrictedChannelList(java.util.Collections.singleton(AuthenticationChannel.EMAIL));
        isd.setHashedValidationChannelValue(ctx.identityValueFromScopeData());
        isd.setMaskedValidationChannelValue(mobileAndMasked.getRight().orElse(null));
        isd.setMobile(mobileAndMasked.getLeft().orElse(null));
        return authChannel;
    }
}
