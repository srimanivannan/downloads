package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Mobile;
import org.apache.commons.lang3.tuple.Pair;

import java.util.List;
import java.util.Optional;

/**
 * Small adapter interface so the new engine can reuse the existing
 * helper methods in ISDVerificationChannelRule without coupling.
 */
public interface IdentityOps {

    Optional<String> getPreferredEmailHash(Consumer consumer);

    Optional<String> getPreferredMobileHash(Consumer consumer);

    Optional<String> getValidatedEmailHash(List<Consumer> consumers, Optional<String> preferredEmailHash);

    Optional<String> getValidatedMobileHash(List<Consumer> consumers, Optional<String> preferredMobileHash);

    Optional<String> lookupPhoneOtpValue(Consumer consumer, String requestedIdentityValueFromScopeData, String identityValueFromScopeData);

    Optional<String> lookupEmailOtpValue(Consumer consumer, String requestedEmail, String fallbackHash);

    Pair<Optional<Mobile>, Optional<String>> getMobileAndMaskedPhoneNumber(Consumer consumer, Optional<String> matchedPreferredValue);

    Pair<Optional<String>, Optional<String>> getEmailAndMaskedEmail(Consumer consumer, Optional<String> matchedPreferredValue);
}
