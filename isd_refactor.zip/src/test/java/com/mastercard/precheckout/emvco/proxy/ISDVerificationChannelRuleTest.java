package com.mastercard.precheckout.emvco.proxy;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.mastercard.precheckout.emvco.config.FeatureConfig;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.Mobile;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityType;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityValidationChannel;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityVerificationRequest;
import com.mastercard.precheckout.generated.emvco.model.IdentityLookupRequest;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.system.OutputCaptureRule;

import com.mastercard.precheckout.emvco.config.AuthenticationConfig;
import com.mastercard.precheckout.emvco.config.OtpAuthConfig;
import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.AuthenticationMethod;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.VerificationChannel;
import com.mastercard.precheckout.emvco.util.TestHelpers;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;
import com.mastercard.precheckout.generated.emvco.model.IdentityValidationChannel;
import com.mastercard.precheckout.generated.emvco.model.IdentityValidationChannelType;
import com.mastercard.precheckout.generated.emvco.model.IdentityVerificationRequest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ISDVerificationChannelRuleTest {

    private static final String CLIENT_ID = "111111";

    private static final String SUPPRESSED_CLIENT_ID = "e0c3be1a-fcb2-11ea-adc1-0242ac120002";

    @Rule
    public OutputCaptureRule outputCapture = new OutputCaptureRule();

    @InjectMocks
    private ISDVerificationChannelRule verificationChannelRules;

    @Mock
    private AuthenticationConfig authenticationConfig;

    @Mock
    private FeatureConfig featureConfig;

    @Mock
    private OtpAuthConfig otpAuthConfig;

    private Consumer consumer;
    private Consumer multiPiiConsumer;
    private List<Consumer> multiPiiConsumerList;

    private TestHelpers testHelpers;

    /**
     *  Setup Method.
     */
    @Before
    public void setUp() {
        testHelpers = new TestHelpers();

        //OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setDefaultChannel(IdentityValidationChannelType.SMS.name());
        otpAuthConfig.setSuppressedClientChannel(AuthenticationChannel.EMAIL.name());
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));

        consumer = testHelpers.mockConsumer();
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);

        multiPiiConsumer = new Consumer();
        multiPiiConsumer.setConsumerId("c1");
        multiPiiConsumer.setMobileCountryCode("91");
        multiPiiConsumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        multiPiiConsumer.setHashedEmail("hashedEmail");
        multiPiiConsumer.setHashedCountryCodeWithMobile("hashedMobile");

        Identity emailIdentity = new Identity();
        emailIdentity.setType("EMAIL");
        emailIdentity.setEmail("test@mc.com");
        emailIdentity.setHashedEmail("hashedEmail");
        emailIdentity.setMaskedEmail("t***@mc.com");
        emailIdentity.setPreferred(true);

        Mobile mobile = new Mobile();
        mobile.setCountryCode("91");
        mobile.setPhoneNumber("1234567890");
        mobile.setHashedCountryCodeWithPhoneNumber("hashedMobile");
        mobile.setMaskedPhoneNumber("****7890");

        Identity mobileIdentity = new Identity();
        mobileIdentity.setType("MOBILE_PHONE_NUMBER");
        mobileIdentity.setMobile(mobile);
        mobileIdentity.setPreferred(true);

        multiPiiConsumer.setIdentities(Arrays.asList(emailIdentity, mobileIdentity));
        multiPiiConsumerList = Collections.singletonList(multiPiiConsumer);
    }

    @Test
    public void testAuthChannelFromScopeData_EmailOtp() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), "EMAIL_OTP", "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.EMAIL.toString(), result.getPreferredChannel());
        assertTrue(result.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
    }

    @Test
    public void testAuthChannelFromScopeData_SmsOtp_NotRestricted() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), "SMS_OTP", "SMS", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.toString(), result.getPreferredChannel());
        assertTrue(result.getRestrictedChannelList().contains(AuthenticationChannel.EMAIL));
    }

    @Test
    public void testAuthChannelFromScopeData_SmsOtp_Restricted() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(true);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), "SMS_OTP", "SMS", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        Assertions.assertNull(result.getPreferredChannel());
    }

    @Test
    public void testSmsChannelRestricted_MultiPiiDisabled() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(true);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "SMS", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.EMAIL.toString(), result.getPreferredChannel());
    }

    @Test
    public void testSmsChannelRestricted_MultiPiiEnabled() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(true);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "SMS", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.EMAIL.toString(), result.getPreferredChannel());
        assertEquals("SMS", result.getHashedValidationChannelValue());
    }

    @Test
    public void testRequestHasAuthChannel_NoMultiPii() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);

        IdentityVerificationRequest req = new IdentityVerificationRequest();
        IdentityValidationChannel channel = new IdentityValidationChannel();
        channel.setIdentityType(IdentityValidationChannelType.EMAIL);
        req.setRequestedValidationChannel(channel);

        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                req, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals("EMAIL", result.getPreferredChannel());
    }

    @Test
    public void testRequestHasAuthChannel_MultiPii_Email() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        IdentityVerificationRequest req = new IdentityVerificationRequest();
        IdentityValidationChannel channel = new IdentityValidationChannel();
        channel.setIdentityType(IdentityValidationChannelType.EMAIL);
        req.setRequestedValidationChannel(channel);

        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                req, null, "EMAIL", "val", "test@mc.com", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals("EMAIL", result.getPreferredChannel());
        assertEquals("hashedEmail", result.getHashedValidationChannelValue());
        assertEquals("t***@mc.com", result.getMaskedValidationChannelValue());
    }

    @Test
    public void testRequestHasAuthChannel_MultiPii_Sms() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        IdentityVerificationRequest req = new IdentityVerificationRequest();
        IdentityValidationChannel channel = new IdentityValidationChannel();
        channel.setIdentityType(IdentityValidationChannelType.SMS);
        req.setRequestedValidationChannel(channel);

        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                req, null, "SMS", "val", "911234567890", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals("SMS", result.getPreferredChannel());
    }

    @Test
    public void testC2PClient_NoMultiPii() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);

        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testC2PClient_MultiPii() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testAMSClient_Pending() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getDefaultChannel()).thenReturn(AuthenticationChannel.SMS.name());
        consumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());

        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testAMSClient_Returning() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getSuppressedClientChannel()).thenReturn(AuthenticationChannel.EMAIL.name());
        multiPiiConsumer.setStatus("ACTIVE");

        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.EMAIL.name(), result.getPreferredChannel());
    }

    @Test
    public void testAMSClient_Returning_NullSuppressedChannel() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getSuppressedClientChannel()).thenReturn(null);
        multiPiiConsumer.setStatus("ACTIVE");
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertNull(result.getPreferredChannel());
    }

    @Test
    public void testAMSClient_Pending_NullDefaultChannel() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getDefaultChannel()).thenReturn(null);
        multiPiiConsumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertNull(result.getPreferredChannel());
    }

    @Test
    public void testC2P_ReturningUser_NeitherAllMatched() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        multiPiiConsumer.setStatus("ACTIVE");
        // Make sure email and mobile don't match
        Consumer other = new Consumer();
        other.setHashedEmail("otherEmail");
        other.setHashedCountryCodeWithMobile("otherMobile");
        List<Consumer> consumers = Arrays.asList(multiPiiConsumer, other);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", consumers, multiPiiConsumer);
        assertEquals(AuthenticationChannel.EMAIL.name(), result.getPreferredChannel());
    }

    @Test
    public void testRequestWithInternalIdentityVerificationRequest() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        InternalIdentityVerificationRequest req = InternalIdentityVerificationRequest.builder().build();
        InternalIdentityValidationChannel channel = InternalIdentityValidationChannel.builder().build();
        channel.setIdentityType(InternalIdentityType.EMAIL);
        req.setInternalIdentityValidationChannel(channel);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                req, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals("EMAIL", result.getPreferredChannel());
    }

    @Test
    public void testNullIdentitiesInConsumer() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        multiPiiConsumer.setIdentities(null);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testEmptyConsumersList() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        List<Consumer> emptyList = Collections.emptyList();
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", emptyList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullIdentityTypeFromScopeData() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, null, "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullRequestedIdentityValueFromScopeData() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", null, "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullIdentityValueFromScopeData() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", null, "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullClientId() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", null, multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullMobileCountryCode() {
        //when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        multiPiiConsumer.setMobileCountryCode(null);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullStatusOnConsumer() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        multiPiiConsumer.setStatus(null);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullAuthChannelFromScopeData() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullConsumer() {
        assertThrows(NullPointerException.class, () -> {
            verificationChannelRules.getPreferredChannel(
                    new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, null);
        });
    }

    @Test
    public void testNullFeatureConfigAndAuthenticationConfig() {
        ISDVerificationChannelRule rule = new ISDVerificationChannelRule(null, null);
        assertThrows(NullPointerException.class, () -> {
            rule.getPreferredChannel(
                    new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        });
    }

    @Test
    public void testUnknownIdentityTypeFromScopeData() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "UNKNOWN_TYPE", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullIdentityVerificationRequest() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                null, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullOtpAuthConfig() {
        when(authenticationConfig.getOtp()).thenReturn(null);
        assertThrows(NullPointerException.class, () -> {
            verificationChannelRules.getPreferredChannel(
                    new IdentityVerificationRequest(), null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        });
    }

    @Test
    public void testSuppressedClientNullStatus() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        multiPiiConsumer.setStatus(null);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", SUPPRESSED_CLIENT_ID, multiPiiConsumerList, multiPiiConsumer);
        assertNull(result.getPreferredChannel());
    }

    @Test
    public void testSuppressedClientUnknownStatus() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        multiPiiConsumer.setStatus("UNKNOWN_STATUS");
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", SUPPRESSED_CLIENT_ID, multiPiiConsumerList, multiPiiConsumer);
        assertNull(result.getPreferredChannel());
    }

    @Test
    public void testSuppressedClientEmptyIdentities() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        multiPiiConsumer.setIdentities(new ArrayList<>());
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, "EMAIL", "val", "val", SUPPRESSED_CLIENT_ID, multiPiiConsumerList, multiPiiConsumer);
        assertNull(result.getPreferredChannel());
    }

    @Test
    public void testSuppressedClientNullAuthChannelFromScopeData() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                new IdentityVerificationRequest(), null, null, "val", "val", SUPPRESSED_CLIENT_ID, multiPiiConsumerList, multiPiiConsumer);
        assertNull(result.getPreferredChannel());
    }

    @Test
    public void testInternalIdentityVerificationRequestNullChannel() {
        InternalIdentityVerificationRequest req = InternalIdentityVerificationRequest.builder().build();
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                req, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testUnknownIdentityTypeFromScopeData1() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                null, null, "UNKNOWN_TYPE", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testInternalIdentityVerificationRequestNullChannel1() {
        InternalIdentityVerificationRequest req = InternalIdentityVerificationRequest.builder().build();
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        ISDVerificationChannels result = verificationChannelRules.getPreferredChannel(
                req, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullConsumer1() {
        assertThrows(NullPointerException.class, () -> {
            verificationChannelRules.getPreferredChannel(
                    null, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, null);
        });
    }

    @Test
    public void testNullFeatureConfigAndAuthenticationConfig1() {
        ISDVerificationChannelRule rule = new ISDVerificationChannelRule(authenticationConfig, featureConfig);
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        ISDVerificationChannels result = rule.getPreferredChannel(
                null, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
        assertEquals(AuthenticationChannel.SMS.name(), result.getPreferredChannel());
    }

    @Test
    public void testNullOtpAuthConfig1() {
        ISDVerificationChannelRule rule = new ISDVerificationChannelRule(authenticationConfig, featureConfig);
        when(authenticationConfig.getOtp()).thenReturn(null); // Simulate null OtpAuthConfig
        // Expect NPE or handle gracefully in implementation
        try {
            rule.getPreferredChannel(
                    null, null, "EMAIL", "val", "val", "client", multiPiiConsumerList, multiPiiConsumer);
            fail("Expected NullPointerException");
        } catch (NullPointerException exception) {
            Assertions.assertNotNull(exception);
        }
    }

    @Test
    public void testGetPreferredChannel_NullAllParams() {
        ISDVerificationChannelRule rule = new ISDVerificationChannelRule(authenticationConfig, featureConfig);
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        assertThrows(NullPointerException.class, () -> {
            rule.getPreferredChannel(null, null, null, null, null, null, null, null);
        });
    }

    @Test
    public void positive_authChannelFromScopeData_withEmailOtp() {
        List<Consumer> consumers = Collections.singletonList(consumer);
        IdentityLookupRequest identityLookupRequest = com.mastercard.precheckout.util.TestHelpers
                .getIdentityLookUpRequest(IdentityType.EMAIL, "test-email@123.com");
        String identityValue =
                identityLookupRequest
                        .getConsumerIdentity()
                        .getIdentityValue();
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            AuthenticationMethod.EMAIL_OTP.getValue(), IdentityType.EMAIL.name(), identityValue, consumer.getHashedEmail(), CLIENT_ID, consumers,
            consumer);
        assertEquals(AuthenticationChannel.EMAIL.getValue(), isdVerificationChannels.getPreferredChannel());
    }

    @Test
    public void positive_authChannelFromScopeData_withEmailOtp_Internal() {
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(InternalIdentityVerificationRequest.builder().build(),
                AuthenticationMethod.EMAIL_OTP.getValue(), IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(), CLIENT_ID, consumers,
                consumer);
        assertEquals(AuthenticationChannel.EMAIL.getValue(), isdVerificationChannels.getPreferredChannel());
    }

    @Test
    public void positive_authChannelFromScopeData_withSmsOtp() {
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            AuthenticationMethod.SMS_OTP.getValue(), IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(), CLIENT_ID, consumers,
            consumer);
        assertEquals(AuthenticationChannel.SMS.getValue(), isdVerificationChannels.getPreferredChannel());
    }

    @Test
    public void positive_authChannelFromScopeData_withSmsOtpForSmsRestrictedCountry() {
        List<String> smsRestrictedCountryCodes = Arrays.asList(consumer.getMobileCountryCode());
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSmsRestrictedCountryCodes(smsRestrictedCountryCodes);
        otpAuthConfig.setSuppressedClientIds(Arrays.asList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            AuthenticationMethod.SMS_OTP.getValue(), IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(), CLIENT_ID, consumers,
            consumer);
        assertNull(isdVerificationChannels.getPreferredChannel());
    }

    @Test
    public void positive_getAuthChannel_AMS_NewUser() {
        consumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getDefaultChannel()).thenReturn(AuthenticationChannel.SMS.name());
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(),
            SUPPRESSED_CLIENT_ID, consumers, consumer);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"SMS\",\"channelRule\":\"AMS_NewUser\"");
    }

    @Test
    public void positive_getAuthChannel_AMS_ReturningUser() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getSuppressedClientChannel()).thenReturn(AuthenticationChannel.EMAIL.name());
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(),
            SUPPRESSED_CLIENT_ID, consumers, consumer);
        assertEquals(AuthenticationChannel.EMAIL.name(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"EMAIL\",\"channelRule\":\"AMS_ReturningUser\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2PNewUser() {
        consumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(),
            CLIENT_ID, consumers, consumer);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_NewUser\"");
    }

    @Test
    public void positive_getAuthChannel_withMobileLookup_C2PNewUser() {
        consumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.SMS.name(), "14017132125", consumer.getHashedCountryCodeWithMobile(),
            CLIENT_ID, consumers, consumer);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_NewUser\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2PNewUser_multiPiiEnabled() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        mockedConsumer1.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(),
                CLIENT_ID, consumers, mockedConsumer1);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_NewUser\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_ReturningUser_VerificationChannel() {
        consumer.setVerificationChannel(VerificationChannel.SMS.name());
        List<Consumer> consumers = Collections.singletonList(consumer);
        IdentityVerificationRequest identityVerificationRequest = new IdentityVerificationRequest();
        IdentityValidationChannel identityValidationChannel = new IdentityValidationChannel();
        identityValidationChannel.setIdentityType(IdentityValidationChannelType.SMS);
        identityVerificationRequest.setRequestedValidationChannel(identityValidationChannel);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(identityVerificationRequest,
            null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), "test-email@123.com",
            CLIENT_ID, consumers, consumer);
        assertEquals(consumer.getVerificationChannel(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"SMS\"");
    }

    @Test
    public void positive_getAuthChannelB2B_withEmailLookup_C2P_ReturningUser_VerificationChannel() {
        consumer.setVerificationChannel(VerificationChannel.SMS.name());
        List<Consumer> consumers = Collections.singletonList(consumer);
        InternalIdentityVerificationRequest identityVerificationRequest = InternalIdentityVerificationRequest.builder().build();
        InternalIdentityValidationChannel identityValidationChannel = InternalIdentityValidationChannel.builder().build();
        identityValidationChannel.setIdentityType(InternalIdentityType.SMS);
        identityVerificationRequest.setInternalIdentityValidationChannel(identityValidationChannel);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(identityVerificationRequest,
                null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), "test-email@123.com",
                CLIENT_ID, consumers, consumer);
        assertEquals(consumer.getVerificationChannel(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\"");
    }

    @Test
    public void positive_getAuthChannel_withSMSLookup_C2P_ReturningUser_SMSRestrictedCountries() {
        consumer.setVerificationChannel(null);
        List<String> smsRestrictedCountryCodes = Collections.singletonList(consumer.getMobileCountryCode());
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSmsRestrictedCountryCodes(smsRestrictedCountryCodes);
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.SMS.name(), consumer.getHashedCountryCodeWithMobile(), "14017132125",
            CLIENT_ID, consumers, consumer);
        assertEquals(AuthenticationChannel.EMAIL.name(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"EMAIL\",\"channelRule\":\"DefaultEmailChannel_SMSRestrictedCountries\"");
    }

    @Test
    public void positive_getAuthChannel_withSMSLookup_C2P_ReturningUser_SMSRestrictedCountries_multiPiiEnabled() {
        consumer.setVerificationChannel(null);
        List<String> smsRestrictedCountryCodes = Collections.singletonList(consumer.getMobileCountryCode());
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSmsRestrictedCountryCodes(smsRestrictedCountryCodes);
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.SMS.name(), consumer.getHashedCountryCodeWithMobile(), "14017132125",
                CLIENT_ID, consumers, consumer);
        assertEquals(AuthenticationChannel.EMAIL.name(), isdVerificationChannels.getPreferredChannel());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"EMAIL\",\"channelRule\":\"DefaultEmailChannel_SMSRestrictedCountries\"");
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        assertNull(isdVerificationChannels.getHashedSwitchingChannelValue());
    }

    @Test
    public void negative_getAuthChannel_withSMSLookup_C2P_ReturningUser_multiPiiEnabled_invalidIdentityType() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL_ADDRESS.name(), "test-email@123.com", mockedConsumer1.getHashedCountryCodeWithMobile(),
                CLIENT_ID, consumers, mockedConsumer1);
        assertNull(isdVerificationChannels.getPreferredChannel());
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_multiPiiEnabled_IdentitiesNull_expectBau() {
        consumer.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(),
                CLIENT_ID, consumers, consumer);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNull(isdVerificationChannels.getRestrictedChannelList());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_AllMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_multiPiiEnabled_IdentitiesEmpty_expectBau() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        mockedConsumer1.setIdentities(new ArrayList<>());
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), "test-email@123.com",
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNull(isdVerificationChannels.getRestrictedChannelList());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_AllMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_ReturningUser_AllMatched() {
        consumer.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        List<Consumer> consumers = Collections.singletonList(consumer);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), "test-email@123.com",
            CLIENT_ID, consumers, consumer);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNull(isdVerificationChannels.getRestrictedChannelList());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_AllMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_ReturningUser_AllMatched_multiPiiEnabled() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), "test-email@123.com",
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNull(isdVerificationChannels.getRestrictedChannelList());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_AllMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_ReturningUser_AllMatched_multiPiiEnabled_consumerHashedMobileNull() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        mockedConsumer1.setHashedCountryCodeWithMobile(null);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL.name(), "test-email@123.com", consumer.getHashedEmail(),
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_AllMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_ReturningUser_EmailMatched_multiPiiEnabled_preferredMobileFalse() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", false, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        mockedConsumer1.setHashedCountryCodeWithMobile(null);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        // Check with Team
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), consumer.getHashedEmail(),
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.EMAIL.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"EMAIL\",\"channelRule\":\"C2P_ReturningUser_EmailMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withMobileLookup_C2P_ReturningUser_AllMatched_multiPiiEnabled_consumerHashedMobileNull() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        mockedConsumer1.setHashedCountryCodeWithMobile(null);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.SMS.name(), consumer.getHashedEmail(), "test-email@123.com",
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_AllMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withMobileLookup_C2P_ReturningUser_AllMatched_multiPiiEnabled_consumerHashedEmailNull() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", false, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        mockedConsumer1.setHashedCountryCodeWithMobile(null);
        mockedConsumer1.setHashedEmail(null);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.SMS.name(), consumer.getHashedEmail(), "test-email@123.com",
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_AllMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withMobileLookup_C2P_ReturningUser_AllMatched_multiPiiEnabled_preferredEmailFalse() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", false, false);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        List<Consumer> consumers = Collections.singletonList(mockedConsumer1);
        mockedConsumer1.setHashedCountryCodeWithMobile(null);
        mockedConsumer1.setHashedEmail(null);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.SMS.name(), consumer.getHashedEmail(), "test-email@123.com",
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_MobileMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_ReturningUser_EmailMatched() {
        consumer.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        Consumer consumerObject = testHelpers.mockConsumer();
        consumerObject.setHashedCountryCodeWithMobile("12345");
        List<Consumer> consumers = Collections.singletonList(consumerObject);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), "test-email@123.com",
            CLIENT_ID, consumers, consumer);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.EMAIL.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getRestrictedChannelList());
        assertTrue(isdVerificationChannels.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"EMAIL\",\"channelRule\":\"C2P_ReturningUser_EmailMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withEmailLookup_C2P_ReturningUser_EmailMatched_multiPiiEnabled() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        Consumer consumerObject = testHelpers.mockConsumer();
        consumerObject.setHashedCountryCodeWithMobile("12345");
        List<Consumer> consumers = Collections.singletonList(consumerObject);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.EMAIL.name(), consumer.getHashedEmail(), "test-email@123.com",
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.EMAIL.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getRestrictedChannelList());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        assertTrue(isdVerificationChannels.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"EMAIL\",\"channelRule\":\"C2P_ReturningUser_EmailMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withPhoneLookup_C2P_ReturningUser_MobileMatched() {
        consumer.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        Consumer consumerObject = testHelpers.mockConsumer();
        consumerObject.setHashedEmail("hashedEmail");
        List<Consumer> consumers = Collections.singletonList(consumerObject);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
            null, IdentityType.SMS.name(), consumer.getHashedCountryCodeWithMobile(), "14017132125",
            CLIENT_ID, consumers, consumer);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getRestrictedChannelList());
        assertTrue(isdVerificationChannels.getRestrictedChannelList().contains(AuthenticationChannel.EMAIL));
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
            "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_MobileMatched\"");
    }

    @Test
    public void positive_getAuthChannel_withPhoneLookup_C2P_ReturningUser_MobileMatched_multiPiiEnabled() {
        Consumer mockedConsumer1 = testHelpers.mockedConsumerWithIdentities(UUID.randomUUID().toString(), "1",
                "identityLookupTest@mc.com",
                "5561233444", "2022-10-26T21:17:28.835Z", true, true);
        mockedConsumer1.setProgramId("GOOGLE");
        mockedConsumer1.setVerificationChannel(null);
        OtpAuthConfig otpAuthConfig = new OtpAuthConfig();
        otpAuthConfig.setSuppressedClientIds(Collections.singletonList(SUPPRESSED_CLIENT_ID));
        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        Consumer consumerObject = testHelpers.mockConsumer();
        consumerObject.setHashedEmail("hashedEmail");
        List<Consumer> consumers = Collections.singletonList(consumerObject);
        ISDVerificationChannels isdVerificationChannels = verificationChannelRules.getPreferredChannel(new IdentityVerificationRequest(),
                null, IdentityType.SMS.name(), consumer.getHashedCountryCodeWithMobile(), "14017132125",
                CLIENT_ID, consumers, mockedConsumer1);
        assertNotNull(isdVerificationChannels);
        assertEquals(AuthenticationChannel.SMS.name(), isdVerificationChannels.getPreferredChannel());
        assertNotNull(isdVerificationChannels.getRestrictedChannelList());
        assertNotNull(isdVerificationChannels.getHashedValidationChannelValue());
        assertTrue(isdVerificationChannels.getRestrictedChannelList().contains(AuthenticationChannel.EMAIL));
        com.mastercard.precheckout.util.TestHelpers.assertLog(300, outputCapture,
                "\"AuthChannel\":\"SMS\",\"channelRule\":\"C2P_ReturningUser_MobileMatched\"");
    }

    @Test
    public void testGetMobileAndMaskedPhoneNumber_matchPreferredValueIsEmpty() throws Exception {
        final ISDVerificationChannelRule rule = new ISDVerificationChannelRule(null, null);
        Consumer consumer = new Consumer();
        Mobile mobile = new Mobile();
        mobile.setPhoneNumber("1234567890");
        mobile.setCountryCode("91");
        mobile.setMaskedPhoneNumber("****7890");
        mobile.setHashedCountryCodeWithPhoneNumber("hash1");
        Identity identity = new Identity();
        identity.setType("MOBILE_PHONE_NUMBER");
        identity.setMobile(mobile);
        consumer.setIdentities(Collections.singletonList(identity));
        Optional<String> hash = Optional.empty();

        Method method = ISDVerificationChannelRule.class.getDeclaredMethod("getMobileAndMaskedPhoneNumber", Consumer.class, Optional.class);
        method.setAccessible(true);
        @SuppressWarnings("unchecked")
        Pair<Optional<Mobile>, Optional<String>> result = (Pair<Optional<Mobile>, Optional<String>>) method.invoke(rule, consumer, hash);

        assertFalse(result.getLeft().isPresent());
        assertFalse(result.getRight().isPresent());
    }

    @Test
    public void testGetEmailAndMaskedEmail_matchPreferredValueIsEmpty() throws Exception {
        final ISDVerificationChannelRule rule = new ISDVerificationChannelRule(null, null);
        Consumer consumer = new Consumer();
        // Email identity
        Identity emailIdentity = new Identity();
        emailIdentity.setType("EMAIL");
        emailIdentity.setEmail("test@mc.com");
        emailIdentity.setMaskedEmail("t***@mc.com");
        emailIdentity.setHashedEmail("emailHash1");
        consumer.setIdentities(Collections.singletonList(emailIdentity));
        Optional<String> matchedPreferredValue = Optional.empty();

        Method method = ISDVerificationChannelRule.class.getDeclaredMethod("getEmailAndMaskedEmail", Consumer.class, Optional.class);
        method.setAccessible(true);
        @SuppressWarnings("unchecked")
        Pair<Optional<String>, Optional<String>> result = (Pair<Optional<String>, Optional<String>>) method.invoke(rule, consumer, matchedPreferredValue);

        assertFalse(result.getLeft().isPresent());
        assertFalse(result.getRight().isPresent());
    }
}