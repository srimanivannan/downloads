package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.config.AuthenticationConfig;
import com.mastercard.precheckout.emvco.config.FeatureConfig;
import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.Mobile;
import com.mastercard.precheckout.emvco.proxy.ISDVerificationChannelRule;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

public class C2PChannelEngineTest {

    @Test
    public void multiPii_newUser_alwaysSms() {
        Consumer c = buildConsumerPending();

        ChannelContext ctx = new ChannelContext(
                c,
                Collections.singletonList(c),
                IdentityType.EMAIL,
                "hash",
                "test@mc.com"
        );

        ISDVerificationChannels out = new ISDVerificationChannels();
        ISDVerificationChannelRule ops = new ISDVerificationChannelRule(mock(AuthenticationConfig.class), mock(FeatureConfig.class));

        C2PChannelEngine engine = new C2PChannelEngine(Arrays.asList(
                new MultiPiiC2PResolver(Arrays.asList(new SmsResolutionStrategy(), new EmailResolutionStrategy())),
                new SingleIdentityC2PResolver()
        ));

        C2PResolution res = engine.resolve(C2PMode.MULTI_PII, ctx, ops, out);

        assertEquals(AuthenticationChannel.SMS.name(), res.preferredChannel());
        assertEquals("C2P_NewUser", res.channelRule());
    }

    @Test
    public void multiPii_returningUser_allMatched_setsMobileAndMasked() {
        Consumer c = buildConsumerReturning();

        ChannelContext ctx = new ChannelContext(
                c,
                Collections.singletonList(c),
                IdentityType.SMS,
                "hashedMobile",
                "911234567890"
        );

        ISDVerificationChannels out = new ISDVerificationChannels();
        ISDVerificationChannelRule ops = new ISDVerificationChannelRule(mock(AuthenticationConfig.class), mock(FeatureConfig.class));

        MultiPiiC2PResolver resolver = new MultiPiiC2PResolver(Arrays.asList(new SmsResolutionStrategy(), new EmailResolutionStrategy()));
        C2PResolution res = resolver.resolve(ctx, ops, out);

        assertEquals(AuthenticationChannel.SMS.name(), res.preferredChannel());
        assertEquals("C2P_ReturningUser_AllMatched", res.channelRule());

        assertEquals("hashedMobile", out.getHashedValidationChannelValue());
        assertNotNull(out.getMobile());
        assertEquals("+91****7890", out.getMaskedValidationChannelValue());
    }

    @Test
    public void singleIdentity_returningUser_emailMatched_restrictSms() {
        Consumer c = buildConsumerReturning();
        Consumer other = buildConsumerReturning();
        other.setHashedCountryCodeWithMobile("differentMobile");

        ChannelContext ctx = new ChannelContext(
                c,
                Arrays.asList(c, other),
                IdentityType.EMAIL,
                "hashedEmail",
                "test@mc.com"
        );

        ISDVerificationChannels out = new ISDVerificationChannels();
        SingleIdentityC2PResolver resolver = new SingleIdentityC2PResolver();

        C2PResolution res = resolver.resolve(ctx, null, out);

        assertEquals(AuthenticationChannel.EMAIL.name(), res.preferredChannel());
        assertEquals("C2P_ReturningUser_EmailMatched", res.channelRule());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
    }

    private static Consumer buildConsumerPending() {
        Consumer c = baseConsumer();
        c.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        return c;
    }

    private static Consumer buildConsumerReturning() {
        Consumer c = baseConsumer();
        c.setStatus("ACTIVE");
        return c;
    }

    private static Consumer baseConsumer() {
        Consumer consumer = new Consumer();
        consumer.setConsumerId("c1");
        consumer.setMobileCountryCode("91");
        consumer.setHashedEmail("hashedEmail");
        consumer.setHashedCountryCodeWithMobile("hashedMobile");

        Identity emailIdentity = new Identity();
        emailIdentity.setType("EMAIL");
        emailIdentity.setEmail("test@mc.com");
        emailIdentity.setHashedEmail("hashedEmail");
        emailIdentity.setMaskedEmail("t***@mc.com");
        emailIdentity.setPreferred(true);

        Mobile mobile = new Mobile();
        mobile.setCountryCode("91");
        mobile.setPhoneNumber("1234567890");
        mobile.setHashedCountryCodeWithPhoneNumber("hashedMobile");
        mobile.setMaskedPhoneNumber("****7890");

        Identity mobileIdentity = new Identity();
        mobileIdentity.setType("MOBILE_PHONE_NUMBER");
        mobileIdentity.setMobile(mobile);
        mobileIdentity.setPreferred(true);

        consumer.setIdentities(Arrays.asList(emailIdentity, mobileIdentity));
        return consumer;
    }
}
