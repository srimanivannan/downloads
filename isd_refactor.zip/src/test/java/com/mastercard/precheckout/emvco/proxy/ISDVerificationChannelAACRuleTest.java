package com.mastercard.precheckout.emvco.proxy;

import com.mastercard.precheckout.emvco.config.AuthenticationConfig;
import com.mastercard.precheckout.emvco.config.FeatureConfig;
import com.mastercard.precheckout.emvco.config.OtpAuthConfig;
import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.Mobile;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityType;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityValidationChannel;
import com.mastercard.precheckout.emvco.domain.common.InternalIdentityVerificationRequest;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;
import com.mastercard.precheckout.generated.emvco.model.IdentityValidationChannel;
import com.mastercard.precheckout.generated.emvco.model.IdentityValidationChannelType;
import com.mastercard.precheckout.generated.emvco.model.IdentityVerificationRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ISDVerificationChannelAACRuleTest {

    @InjectMocks
    private ISDVerificationChannelRule rule;

    @Mock
    private AuthenticationConfig authenticationConfig;

    @Mock
    private FeatureConfig featureConfig;

    @Mock
    private OtpAuthConfig otpAuthConfig;

    private Consumer baseConsumer;

    @Before
    public void setUp() {
        baseConsumer = consumerWithIdentities(
                "c1",
                "ACTIVE",
                "91",
                "E_PREF_HASH",
                "M_PREF_HASH",
                Arrays.asList(
                        email("pref@mc.com", "E_PREF_HASH", "p***@mc.com", true),
                        mobile("91", "9999999999", "M_PREF_HASH", "****9999", true),
                        // one non-preferred for nonPreferred branches
                        email("nonpref@mc.com", "E_NONPREF_HASH", "n***@mc.com", false),
                        mobile("91", "1234567890", "M_NONPREF_HASH", "****7890", false)
                )
        );

        when(authenticationConfig.getOtp()).thenReturn(otpAuthConfig);
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(any())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
    }

    // -----------------------
    // Rule 1: Scope authChannel
    // -----------------------

    @Test
    public void scopeAuthChannel_emailOtp_setsEmail_and_restrictsSms() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                "EMAIL_OTP",
                IdentityType.EMAIL.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
    }

    @Test
    public void scopeAuthChannel_smsOtp_notRestricted_setsSms_and_restrictsEmail() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                "SMS_OTP",
                IdentityType.SMS.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("SMS", out.getPreferredChannel());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.EMAIL));
    }

    @Test
    public void scopeAuthChannel_smsOtp_restricted_returnsNullPreferred() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(true);

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                "SMS_OTP",
                IdentityType.SMS.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertNull(out.getPreferredChannel());
    }

    @Test
    public void scopeAuthChannel_present_but_suppressedClient_ignored_and_fallsThrough() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getSuppressedClientChannel()).thenReturn("EMAIL");

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                "EMAIL_OTP",
                IdentityType.EMAIL.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        // suppressed -> AMS returning user => EMAIL
        assertEquals("EMAIL", out.getPreferredChannel());
    }

    // -----------------------
    // Rule 2: SMS restricted
    // -----------------------

    @Test
    public void smsRestricted_defaultEmail_restrictSms_multiPiiOff() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(true);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                null,
                IdentityType.SMS.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
        assertNull(out.getHashedValidationChannelValue());
    }

    @Test
    public void smsRestricted_defaultEmail_setsHashedValidation_when_multiPiiOn() {
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(true);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                null,
                IdentityType.SMS.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
        assertEquals("SMS", out.getHashedValidationChannelValue()); // preserved original behavior
    }

    // -----------------------
    // Rule 3: Request has auth channel (MultiPII OFF)
    // -----------------------

    @Test
    public void requestHasAuthChannel_multiPiiOff_returnsRequestedChannel() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);

        IdentityVerificationRequest req = new IdentityVerificationRequest();
        IdentityValidationChannel channel = new IdentityValidationChannel();
        channel.setIdentityType(IdentityValidationChannelType.EMAIL);
        req.setRequestedValidationChannel(channel);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req,
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
    }

    @Test
    public void requestInternalHasAuthChannel_multiPiiOff_returnsRequestedChannel() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);

        InternalIdentityVerificationRequest req = InternalIdentityVerificationRequest.builder().build();
        InternalIdentityValidationChannel chan = InternalIdentityValidationChannel.builder().build();
        chan.setIdentityType(InternalIdentityType.SMS);
        req.setInternalIdentityValidationChannel(chan);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req,
                null,
                IdentityType.SMS.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("SMS", out.getPreferredChannel());
    }

    // -----------------------
    // Rule 3: Request has auth channel (MultiPII ON) - cover missing branches
    // -----------------------

    @Test
    public void multiPii_requestAuthEmail_identityEmail_validatedPresent_setsHashAndMask() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        // consumers list validates MOBILE hash (because identityTypeFromScopeData != SMS)
        Consumer other = consumerWithIdentities(
                "c2", "ACTIVE", "91", null, "M_PREF_HASH",
                Collections.singletonList(mobile("91", "1111111111", "M_PREF_HASH", "****1111", true))
        );

        IdentityVerificationRequest req = requestWithAuthChannel(IdentityValidationChannelType.EMAIL);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req,
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "pref@mc.com",
                "client",
                Arrays.asList(baseConsumer, other),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
        assertEquals("E_PREF_HASH", out.getHashedValidationChannelValue());
        assertEquals("p***@mc.com", out.getMaskedValidationChannelValue());
    }

    @Test
    public void multiPii_requestAuthEmail_identitySms_validatedPresent_setsNonPreferredMobileMasked() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        // identityTypeFromScopeData = SMS => validatedEmailHash must be present
        Consumer other = consumerWithIdentities(
                "c2", "ACTIVE", "91", "E_PREF_HASH", null,
                Collections.singletonList(email("x@mc.com", "E_PREF_HASH", "x***@mc.com", true))
        );

        IdentityVerificationRequest req = requestWithAuthChannel(IdentityValidationChannelType.EMAIL);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req,
                null,
                IdentityType.SMS.name(),
                "ignored",
                "911234567890", // finds non-preferred mobile in baseConsumer
                "client",
                Arrays.asList(baseConsumer, other),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
        assertEquals("E_PREF_HASH", out.getHashedValidationChannelValue());
        assertEquals("p***@mc.com", out.getMaskedValidationChannelValue());
        assertEquals("****7890", out.getNonPreferredMaskedValidationChannelValue());
    }

    @Test
    public void multiPii_requestAuthSms_identityEmail_validatedPresent_setsNonPreferredEmailMasked() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        // identityTypeFromScopeData = EMAIL => validatedMobileHash must be present
        Consumer other = consumerWithIdentities(
                "c2", "ACTIVE", "91", null, "M_PREF_HASH",
                Collections.singletonList(mobile("91", "1111111111", "M_PREF_HASH", "****1111", true))
        );

        IdentityVerificationRequest req = requestWithAuthChannel(IdentityValidationChannelType.SMS);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req,
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "nonpref@mc.com", // matches non-preferred email in baseConsumer
                "client",
                Arrays.asList(baseConsumer, other),
                baseConsumer
        );

        assertEquals("SMS", out.getPreferredChannel());
        assertEquals("M_PREF_HASH", out.getHashedValidationChannelValue());
        assertNotNull(out.getMaskedValidationChannelValue()); // comes from preferred mobile mask
        assertEquals("n***@mc.com", out.getNonPreferredMaskedValidationChannelValue());
    }

    @Test
    public void multiPii_validatedAbsent_emailIdentity_and_smsAuth_forcesEmailPreferred_and_restrictsSms() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);

        // Make validatedMobileHash empty (no consumer has M_PREF_HASH)
        Consumer other = consumerWithIdentities(
                "c2", "ACTIVE", "91", null, "OTHER_M_HASH",
                Collections.singletonList(mobile("91", "1111111111", "OTHER_M_HASH", "****1111", true))
        );

        IdentityVerificationRequest req = requestWithAuthChannel(IdentityValidationChannelType.SMS);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req,
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "pref@mc.com",
                "client",
                Arrays.asList(baseConsumer, other),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
        assertNotNull(out.getHashedValidationChannelValue());
    }

    // -----------------------
    // C2P (not suppressed) paths
    // -----------------------

    @Test
    public void c2p_multiPiiOff_newUser_prefersSms() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);
        baseConsumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("SMS", out.getPreferredChannel());
    }

    @Test
    public void c2p_multiPiiOn_newUser_prefersSms() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        baseConsumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("SMS", out.getPreferredChannel());
    }

    // -----------------------
    // AMS (suppressed client) paths
    // -----------------------

    @Test
    public void ams_pendingUser_usesDefaultChannel() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getDefaultChannel()).thenReturn("SMS");
        baseConsumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "ignored",
                "suppressed",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("SMS", out.getPreferredChannel());
    }

    @Test
    public void ams_returningUser_usesSuppressedClientChannel() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otpAuthConfig.getSuppressedClientChannel()).thenReturn("EMAIL");
        baseConsumer.setStatus("ACTIVE");

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                null,
                IdentityType.EMAIL.name(),
                "ignored",
                "ignored",
                "suppressed",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
    }

    @Test
    public void requestHasNoAuthChannel_fallsToC2P_whenNotSuppressed() {
        when(otpAuthConfig.isOtpSuppressedClientId(anyString())).thenReturn(false);
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(false);

        ISDVerificationChannels out = rule.getPreferredChannel(
                new IdentityVerificationRequest(),
                null,
                "UNKNOWN_TYPE",
                "ignored",
                "ignored",
                "client",
                Collections.singletonList(baseConsumer),
                baseConsumer
        );

        assertNull(out.getPreferredChannel());
    }

    @Test
    public void multiPii_validatedAbsent_emailIdentity_smsAuth_forcesEmail_and_restrictsSms() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);

        // Make validated hash absent by ensuring no consumer validates preferred mobile hash
        Consumer other = consumerWithIdentities(
                "c2", "ACTIVE", "91",
                null, "OTHER_M_HASH",
                Collections.singletonList(mobile("91", "1111111111", "OTHER_M_HASH", "****1111", true))
        );

        IdentityVerificationRequest req = requestWithAuthChannel(IdentityValidationChannelType.SMS);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req, null,
                IdentityType.EMAIL.name(),
                "ignored",
                "pref@mc.com",
                "client",
                Arrays.asList(baseConsumer, other),
                baseConsumer
        );

        assertEquals("EMAIL", out.getPreferredChannel());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
    }

    @Test
    public void multiPii_validatedAbsent_emailIdentity_emailAuth_prefersIdentityType_and_restrictsSms() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);

        Consumer other = consumerWithIdentities(
                "c2", "ACTIVE", "91",
                "OTHER_E_HASH", null,
                Collections.singletonList(email("x@mc.com", "OTHER_E_HASH", "x***@mc.com", true))
        );

        IdentityVerificationRequest req = requestWithAuthChannel(IdentityValidationChannelType.EMAIL);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req, null,
                IdentityType.EMAIL.name(),
                "ignored",
                "pref@mc.com",
                "client",
                Arrays.asList(baseConsumer, other),
                baseConsumer
        );

        assertEquals(IdentityType.EMAIL.name(), out.getPreferredChannel());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.SMS));
    }

    @Test
    public void multiPii_validatedAbsent_smsIdentity_emailAuth_prefersIdentityType_and_restrictsEmail() {
        when(featureConfig.isEnableC2PMultiPii()).thenReturn(true);
        when(otpAuthConfig.isRestrictedFromSMS(anyString())).thenReturn(false);

        // baseConsumer preferredEmailHash = "E_PREF_HASH" (from your setup)

        // Create a consumer that DOES NOT contain E_PREF_HASH anywhere (neither identities nor getHashedEmail)
        Consumer other = consumerWithIdentities(
                "c2", "ACTIVE", "91",
                "OTHER_TOP_HASH",  // top-level hashedEmail != E_PREF_HASH
                "OTHER_M_HASH",
                Collections.singletonList(email("x@mc.com", "OTHER_ID_HASH", "x***@mc.com", true)) // identity hashedEmail != E_PREF_HASH
        );

        IdentityVerificationRequest req = requestWithAuthChannel(IdentityValidationChannelType.EMAIL);

        ISDVerificationChannels out = rule.getPreferredChannel(
                req,
                null,
                IdentityType.SMS.name(),     // SMS identity
                "ignored",
                "911234567890",              // requested mobile value (used later only)
                "client",
                Arrays.asList(baseConsumer, other),
                baseConsumer
        );

        // validatedAbsent => preferredChannel = identityTypeFromScopeData ("SMS")
        assertEquals("SMS", out.getPreferredChannel());
        assertTrue(out.getRestrictedChannelList().contains(AuthenticationChannel.EMAIL));
    }


    // -----------------------
    // Helpers
    // -----------------------

    private static IdentityVerificationRequest requestWithAuthChannel(IdentityValidationChannelType type) {
        IdentityVerificationRequest req = new IdentityVerificationRequest();
        IdentityValidationChannel ch = new IdentityValidationChannel();
        ch.setIdentityType(type);
        req.setRequestedValidationChannel(ch);
        return req;
    }

    private static Identity email(String email, String hashed, String masked, boolean preferred) {
        Identity identity = new Identity();
        identity.setType("EMAIL");
        identity.setEmail(email);
        identity.setHashedEmail(hashed);
        identity.setMaskedEmail(masked);
        identity.setPreferred(preferred);
        return identity;
    }

    private static Identity mobile(String cc, String phone, String hashed, String masked, boolean preferred) {
        Mobile mobile = new Mobile();
        mobile.setCountryCode(cc);
        mobile.setPhoneNumber(phone);
        mobile.setHashedCountryCodeWithPhoneNumber(hashed);
        mobile.setMaskedPhoneNumber(masked);

        Identity identity = new Identity();
        identity.setType("MOBILE_PHONE_NUMBER");
        identity.setMobile(mobile);
        identity.setPreferred(preferred);
        return identity;
    }

    private static Consumer consumerWithIdentities(String consumerId, String status, String mobileCC,
                                                   String hashedEmailTop, String hashedMobileTop,
                                                   List<Identity> identities) {
        Consumer consumer = new Consumer();
        consumer.setConsumerId(consumerId);
        consumer.setStatus(status);
        consumer.setMobileCountryCode(mobileCC);
        consumer.setHashedEmail(hashedEmailTop);
        consumer.setHashedCountryCodeWithMobile(hashedMobileTop);
        consumer.setIdentities(identities);
        return consumer;
    }
}
