from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = ["## Purpose", "## When to use", "## Inputs required", "## Prompt", "## Expected output"]

failed = False
for path in sorted((ROOT / "prompts").rglob("*.md")):
    text = path.read_text(encoding="utf-8")
    missing = [item for item in required if item not in text]
    if missing:
        failed = True
        print(f"FAIL: {path.relative_to(ROOT)} missing {missing}")

if failed:
    sys.exit(1)
print("All prompt files passed basic validation.")
