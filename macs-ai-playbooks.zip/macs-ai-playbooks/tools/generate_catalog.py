from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

for section in ["playbooks", "prompts"]:
    print(f"\n## {section.title()}\n")
    for path in sorted((ROOT / section).rglob("*.md")):
        print(f"- {path.relative_to(ROOT)}")
