# MACS AI Playbooks

A workflow-centric repository for reusable AI playbooks, prompts, domain context, examples, and lightweight evaluations for engineering work in the Mastercard MACS program.

## Why this repo exists

Teams repeatedly perform similar workflows:

- investigate logs in Splunk and Dynatrace
- review Java and Spring Boot code
- assess feature flag removals and rollout risk
- draft leadership updates and incident summaries
- review API contract changes
- create architecture RFCs and diagrams

This repo standardizes those workflows so they can be reused, reviewed, improved, and adopted across teams.

## Design principles

1. **Playbooks over one-off prompts**  
   A playbook represents a real workflow made of multiple reusable prompts.
2. **Prompts as building blocks**  
   Prompts should be modular, versioned, and easy to compose.
3. **Context matters**  
   Shared MACS and Mastercard context improves output quality and consistency.
4. **Examples and evals included**  
   Important prompts and playbooks should have examples and simple quality checks.
5. **Safe for enterprise use**  
   Do not place secrets, passwords, tokens, or PCI data in prompts, examples, or outputs.

## Repository structure

```text
macs-ai-playbooks/
├── playbooks/      # End-to-end workflows
├── prompts/        # Reusable prompt building blocks
├── context/        # Shared MACS, platform, and writing context
├── examples/       # Example inputs and expected outputs
├── evals/          # Smoke and regression checks
├── templates/      # Templates for new playbooks and prompts
└── tools/          # Catalog generation and validation helpers
```

## Start here

Recommended first playbooks:

- `playbooks/splunk-investigation/`
- `playbooks/incident-triage/`
- `playbooks/feature-flag-removal/`
- `playbooks/production-incident-summary/`
- `playbooks/api-contract-review/`

## How to use

1. Pick a playbook that matches the workflow.
2. Read `playbook.md` for steps, required inputs, and linked prompts.
3. Reuse the underlying prompts from `prompts/` as needed.
4. Contribute improvements through pull requests.

## Recommended naming

Prompt files should use clear, workflow-oriented names such as:

- `splunk-query-validation.md`
- `feature-flag-removal-impact-review.md`
- `leadership-incident-update-refinement.md`
- `swagger-breaking-change-review.md`

## Roadmap

- Add more workflow packs for MACS domains
- Add richer examples and golden outputs
- Add lightweight prompt linting and metadata validation
- Add a generated catalog page for discoverability

See also:

- `CONTRIBUTING.md`
- `PLAYBOOK_STANDARDS.md`
- `templates/playbook-template.md`
- `templates/prompt-template.md`
