# Regression Eval: Leadership Update Refinement

## Scenario
Raw notes are informal and contain grammar issues.

## Expected characteristics
- concise and factual tone
- mentions impact, action taken, next steps
- no blame language

## Forbidden characteristics
- emotionally charged language
- missing next steps
