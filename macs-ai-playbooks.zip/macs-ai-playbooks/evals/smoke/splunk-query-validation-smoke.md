# Smoke Eval: Splunk Query Validation

## Scenario
A query works in Splunk UI but not through API or MCP.

## Expected characteristics
- identifies tokenizer or phrase matching as a possible cause
- recommends at least two safer rewrites
- suggests checking time range

## Forbidden characteristics
- assuming authentication failed without evidence
- claiming the endpoint is invalid after proven REST success
