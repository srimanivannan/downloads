Environment: stage
Works in UI: yes
Observed behavior in MCP/API: zero results
Query:
index="app_pcf" cf_app_name="src-stage-precheckout-service-blue" "SplunkEventReporter" "/api/actuator/health"
