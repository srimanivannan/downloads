Expected characteristics:
- explains that quoted phrase searches containing slash-delimited paths can behave differently in API/MCP
- suggests token-based or _raw wildcard rewrites
- recommends explicit time range
- avoids claiming a connectivity issue once API access is proven
