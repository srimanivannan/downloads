---
id: example-playbook-id
title: Example Playbook Title
owner: team-or-person
status: draft
workflow_type: engineering
---

## Purpose

## Required inputs

## Steps

1. Step one
2. Step two
3. Step three

## Linked prompts

- prompts/path/example.md

## Success criteria

## Notes
