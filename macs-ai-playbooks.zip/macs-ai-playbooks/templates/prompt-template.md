---
id: example-prompt-id
title: Example Prompt Title
owner: team-or-person
status: draft
tags: [tag1, tag2]
---

## Purpose

## When to use

## Inputs required

## Optional inputs

## Prompt

## Expected output

## Limitations
