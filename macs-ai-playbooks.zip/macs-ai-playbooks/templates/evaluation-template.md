# Evaluation Template

## Scenario

## Input

## Expected characteristics

## Forbidden characteristics

## Reviewer notes
