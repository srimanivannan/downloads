# Contributing

## What can be added

You can contribute:

- new playbooks
- new prompts
- improved MACS context
- examples and expected outputs
- eval cases
- helper scripts

## Contribution rules

1. Prefer workflow-centric additions.
2. Keep one prompt per file.
3. Include metadata at the top of each prompt and playbook.
4. Include at least one example for important prompts.
5. Avoid Mastercard secrets, passwords, tokens, private URLs that should not be shared, and any PCI data.
6. Use professional, concise language.

## Pull request checklist

- [ ] File names are clear and descriptive
- [ ] Metadata is present and complete
- [ ] Purpose and usage are documented
- [ ] Inputs and expected output are defined
- [ ] Examples added for important workflows
- [ ] No secrets or sensitive data included
- [ ] Links between playbooks and prompts are correct

## Review expectations

Reviewers should check for:

- clarity
- reuse potential
- MACS relevance
- safe handling of data
- structured output shape
- maintainability
