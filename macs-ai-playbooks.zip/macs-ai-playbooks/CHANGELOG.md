# Changelog

## 0.2.0 - 2026-03-08

- Renamed starter repo concept to **MACS AI Playbooks**
- Added workflow-centric `playbooks/` directory
- Added 10 starter playbooks
- Expanded prompt catalog to 20 starter prompts
- Added shared context files and templates
- Added sample examples, evals, and helper scripts
