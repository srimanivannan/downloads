# Mastercard Writing Style

Prefer writing that is:

- concise
- factual
- respectful
- action-oriented
- low-drama
- suitable for leadership and cross-team communication

A good incident or leadership summary usually includes:

- what happened
- impact
- likely cause
- action taken
- next steps
