# MACS Domain Context

MACS refers to Mastercard Authentication & Checkout Solutions.

Common domains and services often referenced in workflows:

- PreCheckout
- PI-Core
- Authentication / Auth
- AMS
- Push Provisioning
- Intent Service
- Checkout
- Tokenization-related orchestration

Common concerns:

- rollout safety
- backward compatibility
- consumer impact
- latency and timeout behavior
- downstream dependency failures
- observability gaps
- API contract stability
- production readiness

Common engineering stack:

- Java
- Spring Boot
- Kafka
- Redis
- Oracle / SQL
- PCF / Cloud Foundry
- Splunk
- Dynatrace
- REST and gRPC
