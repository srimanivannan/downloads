# Observability Context

When analyzing issues, prefer a structured approach:

1. confirm impact and affected environment
2. identify request path, trace id, correlation id, or transaction id
3. inspect logs and traces
4. validate recent deployment or config changes
5. identify probable root cause and confidence level
6. recommend next steps

Typical data sources:

- Splunk logs
- Dynatrace traces
- PCF app logs
- application metrics
- Kafka consumer lag or event timing
