# Java and Spring Context

Assume modern Java and Spring Boot patterns unless the workflow explicitly says otherwise.

Review focus areas:

- null handling
- exception handling
- concurrency safety
- CompletableFuture usage
- Spring config correctness
- performance and memory implications
- API compatibility
- testability
