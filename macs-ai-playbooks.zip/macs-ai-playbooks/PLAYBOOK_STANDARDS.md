# Playbook and Prompt Standards

## Core principles

- Optimize for repeatable engineering workflows.
- Keep prompts modular and composable.
- Keep playbooks step-based and outcome-oriented.
- Document assumptions and limitations.
- Prefer structured outputs when possible.

## Prompt file standard

Each prompt should include:

- `id`
- `title`
- `owner`
- `status`
- `tags`
- `purpose`
- `when_to_use`
- `inputs_required`
- `optional_inputs`
- `prompt`
- `expected_output`
- `limitations`

## Playbook file standard

Each playbook should include:

- `id`
- `title`
- `owner`
- `status`
- `workflow_type`
- `purpose`
- `required_inputs`
- `steps`
- `linked_prompts`
- `success_criteria`
- `notes`

## Writing guidance

- Be explicit about context.
- Define what “good output” looks like.
- Avoid vague language like “analyze this” without scope.
- Prefer concise step instructions.
- Separate diagnosis, recommendation, and summary.

## Security guidance

Do not store:

- passwords
- tokens
- secrets
- keys
- private credentials
- PAN, CVV, or PCI-sensitive payloads

Use placeholders instead.
