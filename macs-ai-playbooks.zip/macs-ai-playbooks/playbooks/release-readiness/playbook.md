---
id: release-readiness
title: Release Readiness Playbook
owner: macs-platform
status: active
workflow_type: delivery
---

## Purpose
Assess whether a release is ready from risk, validation, and communication perspectives.

## Required inputs
- release summary
- environments
- known risks

## Steps
1. Review the scope of change
2. Generate rollout risk review
3. Generate final release notes
4. Capture validation checkpoints and rollback triggers

## Linked prompts
- prompts/delivery/rollout/rollout-risk-review.md
- prompts/delivery/release-notes/release-note-draft.md
- prompts/engineering/testing/test-scenario-generation.md

## Success criteria
- scope, risks, validation, and communications are aligned

## Notes
Especially useful for config, contract, and feature-flag-heavy releases.
