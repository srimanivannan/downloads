---
id: incident-triage
title: Incident Triage Playbook
owner: macs-platform
status: active
workflow_type: operations
---

## Purpose
Rapidly assess a production or stage incident and create a structured response.

## Required inputs
- issue summary
- impacted service
- environment
- observed errors

## Steps
1. Gather the timeline and impact
2. Review logs with the Splunk playbook
3. Review traces with `prompts/operations/dynatrace/dynatrace-trace-root-cause-analysis.md` if available
4. Use `prompts/engineering/debugging/http-timeout-root-cause-analysis.md` for timeout patterns
5. Draft a concise summary and leadership update

## Linked prompts
- prompts/operations/dynatrace/dynatrace-trace-root-cause-analysis.md
- prompts/engineering/debugging/http-timeout-root-cause-analysis.md
- prompts/communication/incident-updates/incident-summary-draft.md
- prompts/communication/leadership-updates/leadership-incident-update-refinement.md

## Success criteria
- impact is clear
- probable cause is documented
- action and next steps are aligned

## Notes
Be explicit about confidence level and evidence gaps.
