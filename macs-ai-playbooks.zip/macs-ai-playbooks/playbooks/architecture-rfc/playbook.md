---
id: architecture-rfc
title: Architecture RFC Playbook
owner: macs-platform
status: active
workflow_type: architecture
---

## Purpose
Create a review-ready architecture RFC with design, risks, and rollout thinking.

## Required inputs
- problem statement
- proposal summary
- goals and constraints

## Steps
1. Draft the RFC with `prompts/architecture/rfc/architecture-rfc-draft.md`
2. If diagrams are needed, use `prompts/architecture/diagrams/plantuml-sequence-generator.md`
3. Add rollout and risk sections if applicable

## Linked prompts
- prompts/architecture/rfc/architecture-rfc-draft.md
- prompts/architecture/diagrams/plantuml-sequence-generator.md
- prompts/delivery/rollout/rollout-risk-review.md

## Success criteria
- RFC is structured, reviewable, and actionable

## Notes
Expect at least one iteration with domain experts.
