---
id: production-incident-summary
title: Production Incident Summary Playbook
owner: macs-platform
status: active
workflow_type: communication
---

## Purpose
Turn rough technical findings into a concise production incident summary and leadership note.

## Required inputs
- raw incident notes
- impact summary
- probable cause
- mitigation taken

## Steps
1. Draft the structured incident summary
2. Refine the leadership-facing note
3. Ensure action items and next steps are explicit

## Linked prompts
- prompts/communication/incident-updates/incident-summary-draft.md
- prompts/communication/leadership-updates/leadership-incident-update-refinement.md

## Success criteria
- summary is factual and concise
- leadership note is polished

## Notes
Avoid blame language and overstatement.
