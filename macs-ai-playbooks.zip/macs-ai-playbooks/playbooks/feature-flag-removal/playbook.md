---
id: feature-flag-removal
title: Feature Flag Removal Playbook
owner: macs-platform
status: active
workflow_type: engineering
---

## Purpose
Review the impact of removing a feature flag and validate intended final behavior.

## Required inputs
- old code
- new code
- desired final flag behavior

## Steps
1. Compare old and new behavior
2. Use `prompts/engineering/debugging/feature-flag-removal-impact-review.md`
3. Generate regression scenarios with `prompts/engineering/testing/test-scenario-generation.md`
4. Draft rollout risk review if needed

## Linked prompts
- prompts/engineering/debugging/feature-flag-removal-impact-review.md
- prompts/engineering/testing/test-scenario-generation.md
- prompts/delivery/rollout/rollout-risk-review.md

## Success criteria
- behavior equivalence is clear
- changed scenarios are identified
- test coverage is recommended

## Notes
Always state whether the final behavior should be equivalent to flag ON or flag OFF.
