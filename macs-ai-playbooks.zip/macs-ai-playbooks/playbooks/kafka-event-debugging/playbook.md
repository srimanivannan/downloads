---
id: kafka-event-debugging
title: Kafka Event Debugging Playbook
owner: macs-platform
status: active
workflow_type: operations
---

## Purpose
Debug missing, delayed, duplicated, or failed Kafka-driven business flows.

## Required inputs
- event metadata
- expected business outcome
- observed logs

## Steps
1. Review event path and expected processing
2. Use `prompts/operations/kafka/kafka-event-processing-diagnosis.md`
3. Check downstream effects and logs
4. Draft concise findings and next checks

## Linked prompts
- prompts/operations/kafka/kafka-event-processing-diagnosis.md
- prompts/communication/incident-updates/incident-summary-draft.md

## Success criteria
- failure point hypotheses are clear
- validation plan is actionable

## Notes
Separate transport issues from business logic issues.
