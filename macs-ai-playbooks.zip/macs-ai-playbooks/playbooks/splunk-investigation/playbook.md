---
id: splunk-investigation
title: Splunk Investigation Playbook
owner: macs-platform
status: active
workflow_type: observability
---

## Purpose
Investigate issues using Splunk logs and produce a usable diagnosis.

## Required inputs
- environment
- raw query or investigation goal
- known service or app name
- time range

## Steps
1. Validate the query with `prompts/operations/splunk/splunk-query-validation.md`
2. If zero results appear, use `prompts/operations/splunk/splunk-no-results-diagnosis.md`
3. Gather key events and timestamps
4. Summarize likely root cause with `prompts/operations/splunk/splunk-log-root-cause-summary.md`
5. Draft an incident summary if needed

## Linked prompts
- prompts/operations/splunk/splunk-query-validation.md
- prompts/operations/splunk/splunk-no-results-diagnosis.md
- prompts/operations/splunk/splunk-log-root-cause-summary.md
- prompts/communication/incident-updates/incident-summary-draft.md

## Success criteria
- query is usable
- events are identified
- probable cause and next steps are documented

## Notes
Prefer explicit time ranges and service identifiers.
