---
id: pcf-rollout-validation
title: PCF Rollout Validation Playbook
owner: macs-platform
status: active
workflow_type: delivery
---

## Purpose
Prepare and validate PCF deployments with risk awareness and rollback readiness.

## Required inputs
- deployment summary
- environment
- health check expectations

## Steps
1. Review deployment config and logs
2. Use `prompts/operations/pcf/pcf-deployment-diagnosis.md`
3. Use `prompts/delivery/rollout/rollout-risk-review.md`
4. Draft concise release notes if needed

## Linked prompts
- prompts/operations/pcf/pcf-deployment-diagnosis.md
- prompts/delivery/rollout/rollout-risk-review.md
- prompts/delivery/release-notes/release-note-draft.md

## Success criteria
- deployment risks and validation checks are clear

## Notes
Include route mapping, health checks, and rollback conditions.
