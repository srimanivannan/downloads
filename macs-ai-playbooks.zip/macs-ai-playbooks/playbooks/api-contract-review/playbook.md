---
id: api-contract-review
title: API Contract Review Playbook
owner: macs-platform
status: active
workflow_type: architecture
---

## Purpose
Review API contract changes for breaking changes, rollout concerns, and test needs.

## Required inputs
- old contract summary
- new contract summary

## Steps
1. Use `prompts/engineering/refactoring/openapi-breaking-change-review.md`
2. Generate test scenarios
3. Draft release notes or rollout notes if needed

## Linked prompts
- prompts/engineering/refactoring/openapi-breaking-change-review.md
- prompts/engineering/testing/test-scenario-generation.md
- prompts/delivery/release-notes/release-note-draft.md

## Success criteria
- breaking changes are identified
- migration risks are documented
- tests are recommended

## Notes
Best results come from comparing old and new specs side by side.
