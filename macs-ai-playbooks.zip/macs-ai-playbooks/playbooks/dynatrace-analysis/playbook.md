---
id: dynatrace-analysis
title: Dynatrace Analysis Playbook
owner: macs-platform
status: active
workflow_type: observability
---

## Purpose
Use Dynatrace traces to identify bottlenecks, failures, and next validation steps.

## Required inputs
- trace summary
- service name
- environment

## Steps
1. Capture the slowest segment and downstream dependency
2. Use `prompts/operations/dynatrace/dynatrace-trace-root-cause-analysis.md`
3. Cross-check with logs if needed
4. Draft the likely root cause and next checks

## Linked prompts
- prompts/operations/dynatrace/dynatrace-trace-root-cause-analysis.md
- prompts/communication/incident-updates/incident-summary-draft.md

## Success criteria
- bottleneck identified
- likely cause and next checks documented

## Notes
Separate evidence from inference.
