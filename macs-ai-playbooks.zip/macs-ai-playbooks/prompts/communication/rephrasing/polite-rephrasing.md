---
id: polite-rephrasing
title: Polite Rephrasing
owner: macs-platform
status: active
tags: [rephrase, communication]
---

## Purpose
Rewrite short internal messages in a more polished and respectful tone.

## When to use
For meeting notes, asks, reminders, status updates, and partner communication.

## Inputs required
- original message
- desired tone

## Prompt
Rephrase this message in a {{tone}} and professional tone while preserving the original meaning.

## Expected output
- rewritten message

## Limitations
Should not change the factual meaning.
