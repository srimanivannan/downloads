---
id: leadership-incident-update-refinement
title: Leadership Incident Update Refinement
owner: macs-platform
status: active
tags: [leadership, communication, incident]
---

## Purpose
Turn rough incident notes into a concise leadership-ready update.

## When to use
When sharing issue status, rollback rationale, impact, and next steps.

## Inputs required
- raw note

## Prompt
Rewrite this incident update for leadership. Keep it concise, factual, calm, and action-oriented. Include issue summary, impact, action taken, and next steps.

## Expected output
- polished leadership-ready update

## Limitations
Requires underlying facts to be accurate.
