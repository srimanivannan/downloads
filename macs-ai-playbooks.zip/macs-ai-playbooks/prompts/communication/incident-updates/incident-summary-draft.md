---
id: incident-summary-draft
title: Incident Summary Draft
owner: macs-platform
status: active
tags: [incident, summary, communication]
---

## Purpose
Draft a structured incident summary from raw notes.

## When to use
When creating a concise summary after analysis or mitigation.

## Inputs required
- what happened
- impact
- probable cause
- action taken

## Prompt
Draft a clear incident summary with sections for what happened, impact, likely cause, mitigation, and next steps.

## Expected output
- structured incident summary

## Limitations
Not a substitute for a formal RCA.
