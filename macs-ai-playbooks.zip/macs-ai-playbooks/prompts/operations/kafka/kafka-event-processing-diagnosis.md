---
id: kafka-event-processing-diagnosis
title: Kafka Event Processing Diagnosis
owner: macs-platform
status: active
tags: [kafka, events, consumer, debugging]
---

## Purpose
Identify where an event processing workflow likely failed or slowed down.

## When to use
When events are delayed, duplicated, not consumed, or not producing expected side effects.

## Inputs required
- event metadata
- logs or observations

## Optional inputs
- consumer group info
- offset behavior

## Prompt
Analyze this Kafka processing issue. Determine whether the likely problem is production, publishing, consumer lag, deserialization, business logic failure, or downstream dependency.

## Expected output
- ranked failure hypotheses
- evidence needed
- next checks

## Limitations
Cannot replace actual offset or topic inspection.
