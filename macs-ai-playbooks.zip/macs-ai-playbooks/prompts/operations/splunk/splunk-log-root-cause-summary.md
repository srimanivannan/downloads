---
id: splunk-log-root-cause-summary
title: Splunk Log Root Cause Summary
owner: macs-platform
status: active
tags: [splunk, logs, summary]
---

## Purpose
Summarize a set of Splunk log findings into a probable root cause statement.

## When to use
After collecting relevant events, errors, and timestamps.

## Inputs required
- key events
- timestamps
- environment

## Prompt
Summarize the supplied log findings into a probable root cause statement, confidence level, and next checks. Distinguish evidence from inference.

## Expected output
- evidence summary
- root cause hypothesis
- confidence level
- next checks

## Limitations
Should not overstate certainty.
