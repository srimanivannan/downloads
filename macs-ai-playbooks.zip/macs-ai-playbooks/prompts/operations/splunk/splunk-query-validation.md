---
id: splunk-query-validation
title: Splunk Query Validation and Rewrite
owner: macs-platform
status: active
tags: [splunk, logs, observability, validation]
---

## Purpose
Validate a Splunk query, explain likely failure points, and suggest safer rewrites.

## When to use
Use when a query fails, returns zero results, or behaves differently across UI and API.

## Inputs required
- environment
- Splunk query
- observed behavior

## Optional inputs
- time range
- known index names
- whether the query worked in the UI

## Prompt
You are reviewing a Splunk query used in a Mastercard MACS workflow.

Given:
- Environment: {{environment}}
- Query: {{query}}
- Observed behavior: {{observed_behavior}}
- Time range: {{time_range}}
- Works in UI: {{works_in_ui}}

Tasks:
1. Validate the query syntax and likely search semantics.
2. Explain why the query may fail or return zero results.
3. Suggest 3 safer rewrites, especially for API or MCP usage.
4. Recommend the best final query.
5. Mention any likely tokenizer, quoting, field, or time-range issues.

## Expected output
- validation summary
- likely issues
- revised queries
- final recommendation

## Limitations
Does not execute the query; it reviews and rewrites it.
