---
id: splunk-no-results-diagnosis
title: Diagnose Why a Splunk Query Returns No Results
owner: macs-platform
status: active
tags: [splunk, logs, troubleshooting]
---

## Purpose
Diagnose why a query returns zero results and propose likely causes and next tests.

## When to use
When the same query behaves differently between UI, API, or MCP.

## Inputs required
- query
- environment
- returned output or error

## Optional inputs
- time range
- role permissions

## Prompt
Analyze why this Splunk query returned zero results.

Inputs:
- Query: {{query}}
- Environment: {{environment}}
- Returned output: {{returned_output}}
- Time range: {{time_range}}
- Works in UI: {{works_in_ui}}

Please classify the likely reason into one or more of these categories:
- time range
- field mismatch
- tokenizer or quoted phrase behavior
- role access
- index mismatch
- async search retrieval issue

Then suggest the next 5 most useful troubleshooting steps.

## Expected output
- probable causes ranked by likelihood
- targeted next steps
- safer alternative queries

## Limitations
Requires enough context to distinguish between search semantics and data availability.
