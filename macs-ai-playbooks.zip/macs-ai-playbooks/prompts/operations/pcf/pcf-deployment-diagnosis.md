---
id: pcf-deployment-diagnosis
title: PCF Deployment Diagnosis
owner: macs-platform
status: active
tags: [pcf, deployment, troubleshooting]
---

## Purpose
Review deployment symptoms and identify likely platform, config, route, health, or buildpack issues.

## When to use
When an app fails to start, map routes correctly, or pass health checks.

## Inputs required
- manifest or deployment summary
- logs
- environment

## Optional inputs
- route mappings
- health check settings

## Prompt
Review this PCF deployment issue and identify the most likely causes, immediate mitigations, and best next checks.

## Expected output
- issue summary
- probable causes
- immediate mitigation
- next checks

## Limitations
May require platform-specific details not present in the input.
