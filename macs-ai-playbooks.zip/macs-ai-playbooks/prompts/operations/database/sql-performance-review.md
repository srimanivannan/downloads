---
id: sql-performance-review
title: SQL Performance Review
owner: macs-platform
status: active
tags: [sql, oracle, performance, database]
---

## Purpose
Review a query for likely performance bottlenecks and suggest safer optimizations.

## When to use
When a SQL statement is slow or behaving unexpectedly under load.

## Inputs required
- SQL query
- schema or index context

## Optional inputs
- explain plan summary
- row counts

## Prompt
Review this SQL for likely performance problems. Consider joins, filters, cardinality, indexes, sort operations, and hints. Recommend optimizations while being explicit about assumptions.

## Expected output
- risk areas
- optimization ideas
- assumptions

## Limitations
Cannot guarantee performance without real execution plans and data distribution.
