---
id: dynatrace-trace-root-cause-analysis
title: Dynatrace Trace Root Cause Analysis
owner: macs-platform
status: active
tags: [dynatrace, traces, performance, debugging]
---

## Purpose
Analyze a trace or PurePath summary and identify the most likely bottleneck or failure point.

## When to use
Use when a request is slow, failing, or timing out.

## Inputs required
- trace summary
- service name
- environment

## Optional inputs
- deployment timing
- downstream dependencies

## Prompt
You are reviewing a Dynatrace trace for a MACS service.

Given:
- Service: {{service}}
- Environment: {{environment}}
- Trace summary: {{trace_summary}}
- Relevant notes: {{notes}}

Tasks:
1. Identify the slowest or most failure-prone segment.
2. Explain whether the likely issue is application code, downstream dependency, database, cache, or network.
3. State your confidence level.
4. Suggest the next best validation steps.
5. Draft a concise incident note.

## Expected output
- bottleneck summary
- probable root cause
- confidence level
- next validation steps
- short incident note

## Limitations
Depends on the quality of the supplied trace summary.
