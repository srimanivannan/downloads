---
id: plantuml-sequence-generator
title: PlantUML Sequence or Flow Generator
owner: macs-platform
status: active
tags: [plantuml, diagrams, sequence, architecture]
---

## Purpose
Convert a textual flow into a clean PlantUML diagram.

## When to use
When documenting service interactions, delete flows, incident flows, or state transitions.

## Inputs required
- source flow text
- desired diagram type

## Prompt
Convert the supplied workflow into valid PlantUML. Favor readability, clear actor naming, top-down layout when requested, and syntax that renders correctly.

## Expected output
- valid PlantUML source
- short explanation of major sections

## Limitations
Complex flows may need iterative simplification for renderability.
