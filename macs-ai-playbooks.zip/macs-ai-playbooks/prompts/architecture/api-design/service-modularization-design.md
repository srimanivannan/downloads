---
id: service-modularization-design
title: Service Modularization Design Review
owner: macs-platform
status: active
tags: [modularization, architecture, spring]
---

## Purpose
Assess whether a large service should be modularized within a single deployable and propose a structure.

## When to use
When a service has grown large and teams want domain-oriented internal modules.

## Inputs required
- service summary
- current pain points

## Prompt
Propose an internal modularization design for this service. Recommend module boundaries, package structure, API ownership, shared contracts, and migration steps while keeping one deployable.

## Expected output
- proposed module boundaries
- package structure ideas
- migration approach

## Limitations
Architecture decisions still need team alignment and incremental rollout.
