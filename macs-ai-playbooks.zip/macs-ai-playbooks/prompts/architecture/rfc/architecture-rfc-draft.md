---
id: architecture-rfc-draft
title: Architecture RFC Draft
owner: macs-platform
status: active
tags: [rfc, architecture, design]
---

## Purpose
Draft a clear architecture RFC for engineering review.

## When to use
When proposing a design, migration, modularization, or workflow change.

## Inputs required
- problem statement
- proposal summary

## Optional inputs
- constraints
- alternatives
- risks

## Prompt
Draft a practical architecture RFC with sections for context, problem statement, goals, non-goals, proposal, alternatives, risks, rollout plan, and open questions.

## Expected output
- review-ready RFC draft

## Limitations
Requires iteration for domain-specific accuracy.
