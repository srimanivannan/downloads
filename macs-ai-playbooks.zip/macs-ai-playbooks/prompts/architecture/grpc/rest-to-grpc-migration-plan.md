---
id: rest-to-grpc-migration-plan
title: REST to gRPC Migration Plan
owner: macs-platform
status: active
tags: [grpc, migration, api]
---

## Purpose
Draft a migration plan from REST contracts to gRPC services.

## When to use
When teams are exploring internal protocol modernization.

## Inputs required
- current API summary
- migration goals

## Prompt
Create a migration plan from REST to gRPC, covering contract mapping, coexistence strategy, backward compatibility, rollout, observability, and testing.

## Expected output
- phased migration plan
- major risks
- rollout strategy

## Limitations
Needs service-specific details for final execution.
