---
id: release-note-draft
title: Release Note Draft
owner: macs-platform
status: active
tags: [release, notes, communication]
---

## Purpose
Draft internal release notes for technical audiences.

## When to use
When summarizing completed changes for a release or sprint drop.

## Inputs required
- list of changes

## Prompt
Draft concise release notes with sections for highlights, fixes, known risks, validation notes, and follow-up items.

## Expected output
- release note draft

## Limitations
Should be validated against the actual release contents.
