---
id: jira-story-decomposition
title: JIRA Story Decomposition
owner: macs-platform
status: active
tags: [jira, agile, decomposition]
---

## Purpose
Break down a large initiative into workable stories and tasks.

## When to use
When planning a feature, rollout, migration, or investigation.

## Inputs required
- initiative summary
- scope

## Prompt
Decompose this initiative into practical JIRA stories. Include title, goal, dependencies, acceptance criteria, and risks.

## Expected output
- prioritized story breakdown

## Limitations
Needs team-specific capacity and dependency planning afterward.
