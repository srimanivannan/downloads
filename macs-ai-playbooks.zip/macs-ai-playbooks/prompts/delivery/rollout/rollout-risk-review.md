---
id: rollout-risk-review
title: Rollout Risk Review
owner: macs-platform
status: active
tags: [rollout, release, risk]
---

## Purpose
Assess rollout risk and prepare a validation checklist.

## When to use
Before deploying config changes, feature flag updates, or service releases.

## Inputs required
- change summary
- environment

## Prompt
Review this rollout plan. Identify risks, rollback triggers, health checks, stakeholder dependencies, and validation checkpoints.

## Expected output
- rollout risk summary
- validation checklist
- rollback triggers

## Limitations
Requires accurate deployment context.
