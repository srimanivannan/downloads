---
id: feature-flag-removal-impact-review
title: Feature Flag Removal Impact Review
owner: macs-platform
status: active
tags: [feature-flags, review, regression]
---

## Purpose
Check whether removing a feature flag preserves the intended final behavior.

## When to use
When a team wants code to behave as if a feature flag is permanently ON or OFF.

## Inputs required
- old code
- new code
- target flag behavior

## Prompt
Compare the old and new code. Assume the desired end state is that the removed flag behaves as always {{target_behavior}}. Determine whether the new code is equivalent, and identify any scenarios where behavior changed unexpectedly.

## Expected output
- equivalence verdict
- changed scenarios
- bug risks
- recommended tests

## Limitations
Depends on the correctness of the stated desired final flag behavior.
