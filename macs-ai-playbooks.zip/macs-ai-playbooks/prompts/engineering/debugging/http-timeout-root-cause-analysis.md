---
id: http-timeout-root-cause-analysis
title: HTTP Timeout Root Cause Analysis
owner: macs-platform
status: active
tags: [http, timeout, debugging]
---

## Purpose
Diagnose probable reasons for request timeouts and connection issues.

## When to use
When seeing socket timeout, 499, upstream timeout, or downstream slow-call patterns.

## Inputs required
- logs
- timeout config
- timestamps

## Prompt
Analyze this timeout issue. Determine whether it most likely comes from caller timeouts, server processing latency, network issues, connection pool exhaustion, or downstream slowness. Explain the timeline clearly.

## Expected output
- likely timeout source
- timeline explanation
- next validation steps

## Limitations
Requires trustworthy timestamps and relevant config snippets.
