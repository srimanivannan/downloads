---
id: test-scenario-generation
title: Test Scenario Generation
owner: macs-platform
status: active
tags: [testing, qa, scenarios]
---

## Purpose
Generate practical functional, negative, and edge-case test scenarios.

## When to use
When reviewing a new feature, bug fix, or config change.

## Inputs required
- feature summary
- expected behavior

## Prompt
Generate a concise but thorough test matrix for this change. Include happy path, negative path, edge cases, backward compatibility, and rollout validation.

## Expected output
- categorized test scenarios
- rationale for high-risk tests

## Limitations
Not a substitute for domain-specific manual validation.
