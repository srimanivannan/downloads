---
id: spring-config-review
title: Spring Configuration Review
owner: macs-platform
status: active
tags: [spring, configuration, review]
---

## Purpose
Review Spring Boot configuration for correctness, safety, and operational impact.

## When to use
When changing application YAML, properties, timeouts, pools, flags, or environment config.

## Inputs required
- config snippet
- objective of the change

## Prompt
Review this Spring configuration change. Explain what it changes functionally and operationally, identify risks, and suggest safer defaults or validations.

## Expected output
- config behavior summary
- risks
- recommendations

## Limitations
Cannot validate runtime behavior without deployment context.
