---
id: java-code-review-bug-risk
title: Java Code Review for Bug and Risk Detection
owner: macs-platform
status: active
tags: [java, code-review, bugs, spring]
---

## Purpose
Review Java code changes for correctness, regression risk, null handling, exception handling, and maintainability.

## When to use
When reviewing diffs, patches, or new implementations.

## Inputs required
- code or diff
- expected behavior

## Optional inputs
- old code
- environment assumptions

## Prompt
Review this Java code as a senior backend engineer. Identify correctness bugs, hidden regressions, null safety issues, exception handling issues, concurrency concerns, and test gaps. Be explicit about why each issue matters.

## Expected output
- findings ranked by severity
- impacted scenarios
- suggested fixes
- missing tests

## Limitations
Code review without runtime context may miss integration issues.
