---
id: openapi-breaking-change-review
title: OpenAPI Breaking Change Review
owner: macs-platform
status: active
tags: [openapi, api, compatibility]
---

## Purpose
Review an API contract change for compatibility and migration risk.

## When to use
When Swagger/OpenAPI specs or models change.

## Inputs required
- old contract or summary
- new contract or summary

## Prompt
Analyze this API contract change. Identify breaking changes, behavior changes, migration concerns, test scenarios, and rollout risks.

## Expected output
- breaking vs non-breaking changes
- consumer impact
- rollout notes

## Limitations
Best results require both old and new contract views.
