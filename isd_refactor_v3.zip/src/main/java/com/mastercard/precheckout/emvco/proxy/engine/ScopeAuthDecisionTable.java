package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.AuthenticationMethod;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

/**
 * Decision table for Rule 1: OTP channel present in scope data.
 */
public enum ScopeAuthDecisionTable {

    EMAIL_OTP(AuthenticationMethod.EMAIL_OTP, false,
            Optional.of(AuthenticationChannel.EMAIL),
            Set.of(AuthenticationChannel.SMS)),

    SMS_OTP(AuthenticationMethod.SMS_OTP, false,
            Optional.of(AuthenticationChannel.SMS),
            Set.of(AuthenticationChannel.EMAIL));

    private final AuthenticationMethod method;
    private final boolean requiresSmsNotRestricted;
    private final Optional<AuthenticationChannel> preferred;
    private final Set<AuthenticationChannel> restricted;

    ScopeAuthDecisionTable(
            AuthenticationMethod method,
            boolean requiresSmsNotRestricted,
            Optional<AuthenticationChannel> preferred,
            Set<AuthenticationChannel> restricted
    ) {
        this.method = method;
        this.requiresSmsNotRestricted = requiresSmsNotRestricted;
        this.preferred = preferred;
        this.restricted = restricted;
    }

    public static ScopeAuthFacts evaluate(String authMethodFromScope, boolean smsRestricted) {
        if (authMethodFromScope == null) {
            return new ScopeAuthFacts(false, null, smsRestricted, Optional.empty(), Collections.emptySet());
        }

        // EMAIL_OTP always applies
        if (AuthenticationMethod.EMAIL_OTP.getValue().equalsIgnoreCase(authMethodFromScope)) {
            return new ScopeAuthFacts(true, authMethodFromScope, smsRestricted,
                    EMAIL_OTP.preferred, EMAIL_OTP.restricted);
        }

        // SMS_OTP applies only when SMS is NOT restricted
        if (AuthenticationMethod.SMS_OTP.getValue().equalsIgnoreCase(authMethodFromScope) && !smsRestricted) {
            return new ScopeAuthFacts(true, authMethodFromScope, smsRestricted,
                    SMS_OTP.preferred, SMS_OTP.restricted);
        }

        // Applicable (scope contains auth method) but cannot honor it => preferred empty, no restrictions
        return new ScopeAuthFacts(true, authMethodFromScope, smsRestricted, Optional.empty(), Collections.emptySet());
    }
}
