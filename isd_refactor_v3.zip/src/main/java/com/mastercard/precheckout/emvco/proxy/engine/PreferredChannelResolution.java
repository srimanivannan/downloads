package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;

/**
 * Output of the refactored preferred-channel engine.
 */
public record PreferredChannelResolution(
        ISDVerificationChannels channels,
        String channelRule,
        String methodNameForLogging
) {
}
