package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Builds {@link RequestAuthFacts} by mirroring the legacy multi-PII logic.
 */
public final class RequestAuthFactsBuilder {

    private final IdentityLookupService identityLookup;

    public RequestAuthFactsBuilder(IdentityLookupService identityLookup) {
        this.identityLookup = identityLookup;
    }

    public RequestAuthFacts build(
            String requestAuthChannel,
            boolean multiPiiEnabled,
            String identityTypeFromScopeData,
            String identityValueFromScopeData,
            String requestedIdentityValueFromScopeData,
            List<Consumer> consumers,
            Consumer consumer
    ) {
        if (StringUtils.isBlank(requestAuthChannel)) {
            return new RequestAuthFacts(false, multiPiiEnabled, requestAuthChannel,
                    null, Collections.emptySet(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty());
        }

        AuthenticationChannel req = safeAuthChannel(requestAuthChannel);
        if (!multiPiiEnabled) {
            // Legacy: simply return requestAuthChannel
            AuthenticationChannel preferred = req; // can be null if unknown
            return new RequestAuthFacts(true, false, requestAuthChannel,
                    preferred, Collections.emptySet(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty());
        }

        boolean isEmailAuth = AuthenticationChannel.EMAIL == req;
        boolean isSmsAuth = AuthenticationChannel.SMS == req;
        boolean isEmailIdentity = Objects.equals(identityTypeFromScopeData, com.mastercard.precheckout.generated.emvco.model.IdentityType.EMAIL.name());
        boolean isSmsIdentity = Objects.equals(identityTypeFromScopeData, com.mastercard.precheckout.generated.emvco.model.IdentityType.SMS.name());

        Optional<String> preferredEmailHash = identityLookup.getPreferredEmailHash(consumer);
        Optional<String> preferredMobileHash = identityLookup.getPreferredMobileHash(consumer);

        Optional<String> validated = computeValidated(isEmailAuth, isSmsAuth, isSmsIdentity, consumers, preferredEmailHash, preferredMobileHash);

        if (validated.isPresent()) {
            return buildValidatedPresentFacts(
                    requestAuthChannel,
                    req,
                    isEmailAuth,
                    isEmailIdentity,
                    requestedIdentityValueFromScopeData,
                    consumer,
                    preferredEmailHash,
                    preferredMobileHash
            );
        }

        return buildValidatedAbsentFacts(
                requestAuthChannel,
                req,
                isSmsAuth,
                isEmailIdentity,
                identityTypeFromScopeData,
                requestedIdentityValueFromScopeData,
                consumer
        );
    }

    private Optional<String> computeValidated(
            boolean isEmailAuth,
            boolean isSmsAuth,
            boolean isSmsIdentity,
            List<Consumer> consumers,
            Optional<String> preferredEmailHash,
            Optional<String> preferredMobileHash
    ) {
        if (!isEmailAuth && !isSmsAuth) {
            return Optional.empty();
        }
        // Preserve legacy mapping:
        // If identityTypeFromScopeData is SMS => validate email hash across consumers
        // else validate mobile hash across consumers
        return isSmsIdentity
                ? identityLookup.getValidatedEmailHash(consumers, preferredEmailHash)
                : identityLookup.getValidatedMobileHash(consumers, preferredMobileHash);
    }

    private RequestAuthFacts buildValidatedPresentFacts(
            String requestAuthChannel,
            AuthenticationChannel req,
            boolean isEmailAuth,
            boolean isEmailIdentity,
            String requestedIdentityValueFromScopeData,
            Consumer consumer,
            Optional<String> preferredEmailHash,
            Optional<String> preferredMobileHash
    ) {
        Optional<String> maskedValue;
        Optional<String> hashedValidation;
        Optional<String> nonPreferredMasked = Optional.empty();

        if (isEmailAuth) {
            if (isEmailIdentity) {
                String emailHash = identityLookup.findEmailHash(consumer, requestedIdentityValueFromScopeData).orElse(null);
                hashedValidation = Optional.ofNullable(emailHash);
                maskedValue = identityLookup.getEmailAndMaskedEmail(consumer, Optional.ofNullable(emailHash)).getRight();
            } else {
                String mobileHash = identityLookup.findMobileHash(consumer, requestedIdentityValueFromScopeData).orElse(null);
                nonPreferredMasked = nonPreferredMaskedMobileIfAny(consumer, mobileHash);
                hashedValidation = preferredEmailHash;
                maskedValue = identityLookup.getEmailAndMaskedEmail(consumer, preferredEmailHash).getRight();
            }
        } else {
            if (isEmailIdentity) {
                String emailHash = identityLookup.findEmailHash(consumer, requestedIdentityValueFromScopeData).orElse(null);
                hashedValidation = preferredMobileHash;
                maskedValue = identityLookup.getMobileAndMaskedPhoneNumber(consumer, preferredMobileHash).getRight();
                nonPreferredMasked = nonPreferredMaskedEmailIfAny(consumer, emailHash);
            } else {
                String mobileHash = identityLookup.findMobileHash(consumer, requestedIdentityValueFromScopeData).orElse(null);
                hashedValidation = Optional.ofNullable(mobileHash);
                maskedValue = identityLookup.getMobileAndMaskedPhoneNumber(consumer, Optional.ofNullable(mobileHash)).getRight();
            }
        }

        return new RequestAuthFacts(
                true,
                true,
                requestAuthChannel,
                req,
                Collections.emptySet(),
                hashedValidation,
                Optional.empty(),
                maskedValue,
                nonPreferredMasked,
                Optional.empty()
        );
    }

    private RequestAuthFacts buildValidatedAbsentFacts(
            String requestAuthChannel,
            AuthenticationChannel req,
            boolean isSmsAuth,
            boolean isEmailIdentity,
            String identityTypeFromScopeData,
            String requestedIdentityValueFromScopeData,
            Consumer consumer
    ) {
        String hashedIdentityValue = isEmailIdentity
                ? identityLookup.findEmailHash(consumer, requestedIdentityValueFromScopeData).orElse(null)
                : identityLookup.findMobileHash(consumer, requestedIdentityValueFromScopeData).orElse(null);

        Optional<String> maskedValue = isEmailIdentity
                ? identityLookup.getEmailAndMaskedEmail(consumer, Optional.ofNullable(hashedIdentityValue)).getRight()
                : identityLookup.getMobileAndMaskedPhoneNumber(consumer, Optional.ofNullable(hashedIdentityValue)).getRight();

        // Special case preserved: email identity + SMS auth => force EMAIL and restrict SMS
        if (isEmailIdentity && isSmsAuth) {
            return new RequestAuthFacts(
                    true,
                    true,
                    requestAuthChannel,
                    AuthenticationChannel.EMAIL,
                    Set.of(AuthenticationChannel.SMS),
                    Optional.ofNullable(hashedIdentityValue),
                    Optional.empty(),
                    maskedValue,
                    Optional.empty(),
                    Optional.empty()
            );
        }

        // Default preserved: preferredChannel = identityTypeFromScopeData
        AuthenticationChannel preferred = safeAuthChannel(identityTypeFromScopeData);
        Set<AuthenticationChannel> restricted = Set.of(isEmailIdentity ? AuthenticationChannel.SMS : AuthenticationChannel.EMAIL);

        return new RequestAuthFacts(
                true,
                true,
                requestAuthChannel,
                preferred,
                restricted,
                Optional.ofNullable(hashedIdentityValue),
                Optional.empty(),
                maskedValue,
                Optional.empty(),
                Optional.empty()
        );
    }

    private Optional<String> nonPreferredMaskedMobileIfAny(Consumer consumer, String mobileHash) {
        if (mobileHash == null || consumer.getIdentities() == null) {
            return Optional.empty();
        }
        return consumer.getIdentities().stream()
                .filter(i -> "MOBILE_PHONE_NUMBER".equals(i.getType()))
                .filter(i -> Objects.equals(i.getMobile().getHashedCountryCodeWithPhoneNumber(), mobileHash))
                .filter(i -> !i.isPreferred())
                .findFirst()
                .map(i -> i.getMobile().getMaskedPhoneNumber());
    }

    private Optional<String> nonPreferredMaskedEmailIfAny(Consumer consumer, String emailHash) {
        if (emailHash == null || consumer.getIdentities() == null) {
            return Optional.empty();
        }
        return consumer.getIdentities().stream()
                .filter(i -> "EMAIL".equals(i.getType()))
                .filter(i -> Objects.equals(i.getHashedEmail(), emailHash))
                .filter(i -> !i.isPreferred())
                .findFirst()
                .map(Identity::getMaskedEmail);
    }

    private AuthenticationChannel safeAuthChannel(String value) {
        if (value == null) {
            return null;
        }
        try {
            return AuthenticationChannel.valueOf(value);
        } catch (Exception ignored) {
            return null;
        }
    }
}
