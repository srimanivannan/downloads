package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;

import java.util.Optional;
import java.util.Set;

public record ScopeAuthFacts(
        boolean applicable,
        String authMethodFromScopeData,
        boolean smsRestricted,
        Optional<AuthenticationChannel> preferredChannel,
        Set<AuthenticationChannel> restrictedChannels
) {
}
