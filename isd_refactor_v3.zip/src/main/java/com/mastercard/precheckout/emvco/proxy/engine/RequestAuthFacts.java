package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;

import java.util.Optional;
import java.util.Set;

/**
 * Facts and decision output for Rule 3: request contains an auth channel.
 *
 * <p>When multi-PII is disabled, only {@link #preferredChannel()} is used.
 */
public record RequestAuthFacts(
        boolean applicable,
        boolean multiPiiEnabled,
        String requestAuthChannel,
        AuthenticationChannel preferredChannel,
        Set<AuthenticationChannel> restrictedChannels,
        Optional<String> hashedValidationChannelValue,
        Optional<String> hashedSwitchingChannelValue,
        Optional<String> maskedValidationChannelValue,
        Optional<String> nonPreferredMaskedValidationChannelValue,
        Optional<MobileOrEmail> nonPreferredDetails
) {

    /**
     * Lightweight carrier for non-preferred value details.
     */
    public record MobileOrEmail(Optional<String> email, Optional<String> mobileMasked) {}
}
