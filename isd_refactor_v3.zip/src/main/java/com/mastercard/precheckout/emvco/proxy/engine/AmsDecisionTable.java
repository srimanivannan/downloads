package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.config.OtpAuthConfig;
import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.Consumer;

/**
 * Decision table for suppressed (AMS) clients.
 */
public enum AmsDecisionTable {

    NEW_USER("AMS_NewUser") {
        @Override
        public String channel(OtpAuthConfig otpAuthConfig, Consumer consumer) {
            return otpAuthConfig.getDefaultChannel();
        }
    },
    RETURNING_USER("AMS_ReturningUser") {
        @Override
        public String channel(OtpAuthConfig otpAuthConfig, Consumer consumer) {
            return otpAuthConfig.getSuppressedClientChannel();
        }
    };

    private final String rule;

    AmsDecisionTable(String rule) {
        this.rule = rule;
    }

    public String rule() {
        return rule;
    }

    public abstract String channel(OtpAuthConfig otpAuthConfig, Consumer consumer);

    public static AmsDecisionTable resolve(Consumer consumer) {
        return ConsumerStatus.PENDING_VERIFICATION.getValue().equals(consumer.getStatus())
                ? NEW_USER
                : RETURNING_USER;
    }
}
