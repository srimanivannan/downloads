package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;

import java.util.Optional;
import java.util.Set;

/**
 * Decision table for Rule 2: SMS restricted countries.
 */
public final class SmsRestrictedDecisionTable {

    private SmsRestrictedDecisionTable() {}

    public static SmsRestrictedFacts evaluate(boolean smsRestricted, boolean multiPiiEnabled, String identityTypeFromScopeData) {
        if (!smsRestricted) {
            return new SmsRestrictedFacts(false, multiPiiEnabled, identityTypeFromScopeData,
                    AuthenticationChannel.EMAIL, Set.of(AuthenticationChannel.SMS), Optional.empty());
        }

        // Preserve original odd behavior: for multi-PII set hashedValidationChannelValue=identityTypeFromScopeData
        Optional<String> hashed = multiPiiEnabled ? Optional.ofNullable(identityTypeFromScopeData) : Optional.empty();

        return new SmsRestrictedFacts(true, multiPiiEnabled, identityTypeFromScopeData,
                AuthenticationChannel.EMAIL,
                Set.of(AuthenticationChannel.SMS),
                hashed);
    }
}
