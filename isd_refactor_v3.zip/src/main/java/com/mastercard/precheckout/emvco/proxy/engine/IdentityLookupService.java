package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.Mobile;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Identity extraction/matching helper used by the refactored decision engines.
 *
 * <p>This intentionally mirrors the legacy logic in {@code ISDVerificationChannelRule}
 * so the new engine can preserve behavior without requiring that class to
 * implement a bulky interface.
 */
public class IdentityLookupService {

    private static final String EMAIL_TYPE = "EMAIL";
    private static final String MOBILE_PHONE_NUMBER_TYPE = "MOBILE_PHONE_NUMBER";

    public Optional<String> getPreferredMobileHash(Consumer consumer) {
        return Optional.ofNullable(consumer.getIdentities())
                .orElse(Collections.emptyList())
                .stream()
                .filter(identity -> MOBILE_PHONE_NUMBER_TYPE.equals(identity.getType()) && identity.isPreferred())
                .map(id -> id.getMobile().getHashedCountryCodeWithPhoneNumber())
                .findFirst()
                .or(() -> Optional.ofNullable(consumer.getHashedCountryCodeWithMobile()));
    }

    public Optional<String> getPreferredEmailHash(Consumer consumer) {
        return Optional.ofNullable(consumer.getIdentities())
                .orElse(Collections.emptyList())
                .stream()
                .filter(identity -> EMAIL_TYPE.equals(identity.getType()) && identity.isPreferred())
                .map(Identity::getHashedEmail)
                .findFirst()
                .or(() -> Optional.ofNullable(consumer.getHashedEmail()));
    }

    public Optional<String> getValidatedMobileHash(List<Consumer> consumers, Optional<String> preferredMobileHash) {
        return preferredMobileHash.filter(hash -> consumers.stream()
                .allMatch(c -> Stream.concat(
                        Optional.ofNullable(c.getIdentities())
                                .orElse(Collections.emptyList())
                                .stream()
                                .filter(id -> MOBILE_PHONE_NUMBER_TYPE.equals(id.getType()))
                                .map(id -> id.getMobile().getHashedCountryCodeWithPhoneNumber()),
                        Stream.ofNullable(c.getHashedCountryCodeWithMobile())
                ).filter(Objects::nonNull).anyMatch(hash::equals)));
    }

    public Optional<String> getValidatedEmailHash(List<Consumer> consumers, Optional<String> preferredEmailHash) {
        return preferredEmailHash.filter(hash -> consumers.stream()
                .allMatch(c -> Stream.concat(
                        Optional.ofNullable(c.getIdentities())
                                .orElse(Collections.emptyList())
                                .stream()
                                .filter(id -> EMAIL_TYPE.equals(id.getType()))
                                .map(Identity::getHashedEmail),
                        Stream.ofNullable(c.getHashedEmail())
                ).filter(Objects::nonNull).anyMatch(hash::equals)));
    }

    public Optional<String> findMobileHash(Consumer consumer, String requestedIdentityValueFromScopeData) {
        if (requestedIdentityValueFromScopeData == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(i -> MOBILE_PHONE_NUMBER_TYPE.equals(i.getType()))
                .filter(i -> requestedIdentityValueFromScopeData.equals("+" + i.getMobile().getCountryCode() + i.getMobile().getPhoneNumber())
                        || requestedIdentityValueFromScopeData.equals(i.getMobile().getPhoneNumber())
                        || requestedIdentityValueFromScopeData.equals(i.getMobile().getCountryCode() + i.getMobile().getPhoneNumber()))
                .map(i -> i.getMobile().getHashedCountryCodeWithPhoneNumber())
                .findFirst();
    }

    public Optional<String> findEmailHash(Consumer consumer, String requestedEmail) {
        if (requestedEmail == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(i -> EMAIL_TYPE.equals(i.getType()))
                .filter(i -> requestedEmail.equalsIgnoreCase(i.getEmail()))
                .map(Identity::getHashedEmail)
                .findFirst();
    }

    public Pair<Optional<Mobile>, Optional<String>> getMobileAndMaskedPhoneNumber(Consumer consumer, Optional<String> matchedPreferredValue) {
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(id -> MOBILE_PHONE_NUMBER_TYPE.equals(id.getType()))
                .filter(id -> matchedPreferredValue.isPresent() && matchedPreferredValue.get().equals(id.getMobile().getHashedCountryCodeWithPhoneNumber()))
                .findFirst()
                .map(id -> Pair.of(Optional.of(id.getMobile()),
                        Optional.of("+" + id.getMobile().getCountryCode() + id.getMobile().getMaskedPhoneNumber())))
                .orElse(Pair.of(Optional.empty(), Optional.empty()));
    }

    public Pair<Optional<String>, Optional<String>> getEmailAndMaskedEmail(Consumer consumer, Optional<String> matchedPreferredValue) {
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(id -> EMAIL_TYPE.equals(id.getType()))
                .filter(id -> matchedPreferredValue.isPresent() && matchedPreferredValue.get().equals(id.getHashedEmail()))
                .findFirst()
                .map(id -> Pair.of(Optional.ofNullable(id.getEmail()), Optional.ofNullable(id.getMaskedEmail())))
                .orElse(Pair.of(Optional.empty(), Optional.empty()));
    }

    public Optional<String> lookupPhoneOtpValue(Consumer consumer, String requestedIdentityValueFromScopeData, String identityValueFromScopeData) {
        return Optional.of(
                consumer.getIdentities().stream()
                        .filter(identity -> MOBILE_PHONE_NUMBER_TYPE.equals(identity.getType()))
                        .filter(identity -> {
                            String scopedPhone = requestedIdentityValueFromScopeData;
                            String countryCode = identity.getMobile().getCountryCode();
                            String identityPhone = identity.getMobile().getPhoneNumber();

                            String localScopePhone = scopedPhone != null && scopedPhone.startsWith(countryCode)
                                    ? scopedPhone.substring(countryCode.length())
                                    : scopedPhone;

                            return Objects.equals(localScopePhone, identityPhone);
                        })
                        .map(identity -> identity.getMobile().getHashedCountryCodeWithPhoneNumber())
                        .findFirst()
                        .orElse(identityValueFromScopeData)
        );
    }

    public Optional<String> lookupEmailOtpValue(Consumer consumer, String requestedEmail, String fallbackHash) {
        return Optional.of(
                consumer.getIdentities().stream()
                        .filter(identity -> EMAIL_TYPE.equals(identity.getType()))
                        .filter(identity -> requestedEmail != null && requestedEmail.equalsIgnoreCase(identity.getEmail()))
                        .map(Identity::getHashedEmail)
                        .findFirst()
                        .orElse(fallbackHash)
        );
    }
}
