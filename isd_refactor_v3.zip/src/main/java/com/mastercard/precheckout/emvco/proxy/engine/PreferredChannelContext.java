package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.config.FeatureConfig;
import com.mastercard.precheckout.emvco.config.OtpAuthConfig;
import com.mastercard.precheckout.emvco.domain.Consumer;

import java.util.List;

/**
 * Request-scoped context for preferred channel evaluation.
 *
 * <p>This context is used only by the refactored (feature-flagged) engine.
 * It deliberately carries raw inputs (strings) so we can preserve legacy
 * behavior for unknown/invalid values.
 */
public record PreferredChannelContext<T>(
        T identityVerificationRequest,
        String authChannelFromScopeData,
        String identityTypeFromScopeData,
        String identityValueFromScopeData,
        String requestedIdentityValueFromScopeData,
        String clientId,
        List<Consumer> consumers,
        Consumer consumer,
        OtpAuthConfig otpAuthConfig,
        boolean smsChannelRestricted,
        FeatureConfig featureConfig
) {
}
