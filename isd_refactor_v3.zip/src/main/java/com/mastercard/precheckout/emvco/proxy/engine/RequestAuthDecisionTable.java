package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;

/**
 * Applies {@link RequestAuthFacts} ...
 */
public final class RequestAuthDecisionTable {

    private RequestAuthDecisionTable() {}

    public static void apply(RequestAuthFacts facts, ISDVerificationChannels out) {
        if (!facts.applicable()) {
            return;
        }
        out.setPreferredChannel(facts.preferredChannel() == null ? null : facts.preferredChannel().name());
        if (facts.restrictedChannels() != null && !facts.restrictedChannels().isEmpty()) {
            out.setRestrictedChannelList(facts.restrictedChannels());
        }
        facts.hashedValidationChannelValue().ifPresent(out::setHashedValidationChannelValue);
        facts.hashedSwitchingChannelValue().ifPresent(out::setHashedSwitchingChannelValue);
        facts.maskedValidationChannelValue().ifPresent(out::setMaskedValidationChannelValue);
        facts.nonPreferredMaskedValidationChannelValue().ifPresent(out::setNonPreferredMaskedValidationChannelValue);
    }
}
