package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;

import java.util.Optional;
import java.util.Set;

public record SmsRestrictedFacts(
        boolean applicable,
        boolean multiPiiEnabled,
        String identityTypeFromScopeData,
        AuthenticationChannel preferredChannel,
        Set<AuthenticationChannel> restrictedChannels,
        Optional<String> hashedValidationChannelValue
) {
}
