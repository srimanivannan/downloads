package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import org.apache.commons.lang3.StringUtils;

import java.util.Optional;

/**
 * Refactored, decision-table driven engine for preferred channel selection.
 *
 * <p>Evaluation order matches legacy behavior:
 * <ol>
 *   <li>Scope auth channel (Rule 1)</li>
 *   <li>SMS restricted defaulting (Rule 2)</li>
 *   <li>Request auth channel (Rule 3)</li>
 *   <li>C2P (not suppressed) or AMS (suppressed)</li>
 * </ol>
 */
public final class PreferredChannelEngine {

    private final IdentityLookupService identityLookup;
    private final RequestAuthFactsBuilder requestAuthFactsBuilder;
    private final C2PChannelEngine c2pChannelEngine;

    public PreferredChannelEngine(IdentityLookupService identityLookup, C2PChannelEngine c2pChannelEngine) {
        this.identityLookup = identityLookup;
        this.requestAuthFactsBuilder = new RequestAuthFactsBuilder(identityLookup);
        this.c2pChannelEngine = c2pChannelEngine;
    }

    public <T> PreferredChannelResolution resolve(PreferredChannelContext<T> ctx, String requestAuthChannel) {
        ISDVerificationChannels out = new ISDVerificationChannels();

        // Rule 1: scope auth channel
        if (StringUtils.isNotBlank(ctx.authChannelFromScopeData())
                && !ctx.otpAuthConfig().isOtpSuppressedClientId(ctx.clientId())) {
            ScopeAuthFacts facts = ScopeAuthDecisionTable.evaluate(ctx.authChannelFromScopeData(), ctx.smsChannelRestricted());
            if (facts.applicable()) {
                facts.preferredChannel().ifPresent(ch -> out.setPreferredChannel(ch.name()));
                if (!facts.restrictedChannels().isEmpty()) {
                    out.setRestrictedChannelList(facts.restrictedChannels());
                }
                return new PreferredChannelResolution(out, "MBL_OTPChannelInScopeData", "scopeAuthDecisionTable");
            }
        }

        // Rule 2: SMS restricted
        SmsRestrictedFacts restrictedFacts = SmsRestrictedDecisionTable.evaluate(
                ctx.smsChannelRestricted(),
                ctx.featureConfig().isEnableC2PMultiPii(),
                ctx.identityTypeFromScopeData()
        );
        if (restrictedFacts.applicable()) {
            out.setPreferredChannel(restrictedFacts.preferredChannel().name());
            out.setRestrictedChannelList(restrictedFacts.restrictedChannels());
            restrictedFacts.hashedValidationChannelValue().ifPresent(out::setHashedValidationChannelValue);
            return new PreferredChannelResolution(out, "DefaultEmailChannel_SMSRestrictedCountries", "smsRestrictedDecisionTable");
        }

        // Rule 3: request auth channel
        if (StringUtils.isNotBlank(requestAuthChannel)) {
            RequestAuthFacts facts = requestAuthFactsBuilder.build(
                    requestAuthChannel,
                    ctx.featureConfig().isEnableC2PMultiPii(),
                    ctx.identityTypeFromScopeData(),
                    ctx.identityValueFromScopeData(),
                    ctx.requestedIdentityValueFromScopeData(),
                    ctx.consumers(),
                    ctx.consumer()
            );
            if (facts.applicable()) {
                RequestAuthDecisionTable.apply(facts, out);
                // legacy logs null channelRule for this path
                return new PreferredChannelResolution(out, null, "requestAuthDecisionTable");
            }
        }

        // Rule 4+: C2P vs AMS
        if (!ctx.otpAuthConfig().isOtpSuppressedClientId(ctx.clientId())) {
            return resolveC2P(ctx, out);
        }

        // AMS
        AmsDecisionTable ams = AmsDecisionTable.resolve(ctx.consumer());
        String channel = ams.channel(ctx.otpAuthConfig(), ctx.consumer());
        out.setPreferredChannel(channel);
        return new PreferredChannelResolution(out, ams.rule(), "amsDecisionTable");
    }

    private <T> PreferredChannelResolution resolveC2P(PreferredChannelContext<T> ctx, ISDVerificationChannels out) {
        // Determine mode from feature flag
        C2PMode mode = ctx.featureConfig().isEnableC2PMultiPii() ? C2PMode.MULTI_PII : C2PMode.SINGLE_IDENTITY;

        com.mastercard.precheckout.generated.emvco.model.IdentityType identityType = null;
        try {
            if (StringUtils.isNotBlank(ctx.identityTypeFromScopeData())) {
                identityType = com.mastercard.precheckout.generated.emvco.model.IdentityType.valueOf(ctx.identityTypeFromScopeData());
            }
        } catch (IllegalArgumentException ignored) {
            // preserve legacy behavior: treat as unknown
        }

        ChannelContext c2pCtx = new ChannelContext(
                ctx.consumer(),
                ctx.consumers(),
                identityType,
                ctx.identityValueFromScopeData(),
                ctx.requestedIdentityValueFromScopeData()
        );

        C2PResolution resolution = c2pChannelEngine.resolve(mode, c2pCtx, out);
        out.setPreferredChannel(resolution.preferredChannel());

        String method = (mode == C2PMode.MULTI_PII) ? "c2pMultiPiiDecisionTable" : "c2pSingleIdentityDecisionTable";
        return new PreferredChannelResolution(out, resolution.channelRule(), method);
    }
}
