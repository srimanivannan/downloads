package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.config.FeatureConfig;
import com.mastercard.precheckout.emvco.config.OtpAuthConfig;
import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.emvco.domain.Mobile;
import com.mastercard.precheckout.generated.emvco.model.IdentityVerificationRequest;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class PreferredChannelEngineTest {

    private Consumer buildMultiPiiConsumerPending() {
        Consumer c = new Consumer();
        c.setConsumerId("c1");
        c.setMobileCountryCode("91");
        c.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());
        c.setHashedEmail("hashedEmail");
        c.setHashedCountryCodeWithMobile("hashedMobile");

        Identity email = new Identity();
        email.setType("EMAIL");
        email.setEmail("test@mc.com");
        email.setHashedEmail("hashedEmail");
        email.setMaskedEmail("t***@mc.com");
        email.setPreferred(true);

        Mobile m = new Mobile();
        m.setCountryCode("91");
        m.setPhoneNumber("1234567890");
        m.setHashedCountryCodeWithPhoneNumber("hashedMobile");
        m.setMaskedPhoneNumber("****7890");

        Identity mobile = new Identity();
        mobile.setType("MOBILE_PHONE_NUMBER");
        mobile.setMobile(m);
        mobile.setPreferred(true);

        c.setIdentities(Arrays.asList(email, mobile));
        return c;
    }

    private PreferredChannelEngine engine() {
        return new PreferredChannelEngine(
                new IdentityLookupService(),
                new C2PChannelEngine(java.util.List.of(new MultiPiiC2PResolver(), new SingleIdentityC2PResolver()))
        );
    }

    @Test
    public void scopeAuth_emailOtp_wins() {
        FeatureConfig feature = mock(FeatureConfig.class);
        when(feature.isEnableC2PMultiPii()).thenReturn(true);

        OtpAuthConfig otp = mock(OtpAuthConfig.class);
        when(otp.isOtpSuppressedClientId(anyString())).thenReturn(false);

        Consumer c = buildMultiPiiConsumerPending();

        PreferredChannelContext<IdentityVerificationRequest> ctx = new PreferredChannelContext<>(
                new IdentityVerificationRequest(),
                "EMAIL_OTP",
                "EMAIL",
                "hashedEmail",
                "test@mc.com",
                "client",
                Collections.singletonList(c),
                c,
                otp,
                false,
                feature
        );

        PreferredChannelResolution res = engine().resolve(ctx, null);
        assertEquals(AuthenticationChannel.EMAIL.name(), res.channels().getPreferredChannel());
        assertTrue(res.channels().getRestrictedChannelList().contains(AuthenticationChannel.SMS));
        assertEquals("MBL_OTPChannelInScopeData", res.channelRule());
    }

    @Test
    public void smsRestricted_defaultsToEmail() {
        FeatureConfig feature = mock(FeatureConfig.class);
        when(feature.isEnableC2PMultiPii()).thenReturn(false);

        OtpAuthConfig otp = mock(OtpAuthConfig.class);
        when(otp.isOtpSuppressedClientId(anyString())).thenReturn(false);

        Consumer c = buildMultiPiiConsumerPending();

        PreferredChannelContext<IdentityVerificationRequest> ctx = new PreferredChannelContext<>(
                new IdentityVerificationRequest(),
                null,
                "EMAIL",
                "hashedEmail",
                "test@mc.com",
                "client",
                Collections.singletonList(c),
                c,
                otp,
                true,
                feature
        );

        PreferredChannelResolution res = engine().resolve(ctx, null);
        assertEquals(AuthenticationChannel.EMAIL.name(), res.channels().getPreferredChannel());
        assertTrue(res.channels().getRestrictedChannelList().contains(AuthenticationChannel.SMS));
        assertEquals("DefaultEmailChannel_SMSRestrictedCountries", res.channelRule());
    }

    @Test
    public void requestAuth_multiPiiOff_simplePreferredChannel() {
        FeatureConfig feature = mock(FeatureConfig.class);
        when(feature.isEnableC2PMultiPii()).thenReturn(false);

        OtpAuthConfig otp = mock(OtpAuthConfig.class);
        when(otp.isOtpSuppressedClientId(anyString())).thenReturn(false);

        Consumer c = buildMultiPiiConsumerPending();

        PreferredChannelContext<IdentityVerificationRequest> ctx = new PreferredChannelContext<>(
                new IdentityVerificationRequest(),
                null,
                "EMAIL",
                "hashedEmail",
                "test@mc.com",
                "client",
                Collections.singletonList(c),
                c,
                otp,
                false,
                feature
        );

        PreferredChannelResolution res = engine().resolve(ctx, AuthenticationChannel.SMS.name());
        assertEquals(AuthenticationChannel.SMS.name(), res.channels().getPreferredChannel());
        assertNull(res.channelRule());
    }

    @Test
    public void ams_suppressedClient_newUser_usesDefaultChannel() {
        FeatureConfig feature = mock(FeatureConfig.class);
        when(feature.isEnableC2PMultiPii()).thenReturn(false);

        OtpAuthConfig otp = mock(OtpAuthConfig.class);
        when(otp.isOtpSuppressedClientId(anyString())).thenReturn(true);
        when(otp.getDefaultChannel()).thenReturn(AuthenticationChannel.SMS.name());

        Consumer c = buildMultiPiiConsumerPending();

        PreferredChannelContext<IdentityVerificationRequest> ctx = new PreferredChannelContext<>(
                new IdentityVerificationRequest(),
                null,
                "EMAIL",
                "hashedEmail",
                "test@mc.com",
                "client",
                Collections.singletonList(c),
                c,
                otp,
                false,
                feature
        );

        PreferredChannelResolution res = engine().resolve(ctx, null);
        assertEquals(AuthenticationChannel.SMS.name(), res.channels().getPreferredChannel());
        assertEquals("AMS_NewUser", res.channelRule());
    }

    @Test
    public void c2p_notSuppressed_newUser_sms() {
        FeatureConfig feature = mock(FeatureConfig.class);
        when(feature.isEnableC2PMultiPii()).thenReturn(true);

        OtpAuthConfig otp = mock(OtpAuthConfig.class);
        when(otp.isOtpSuppressedClientId(anyString())).thenReturn(false);

        Consumer c = buildMultiPiiConsumerPending();

        PreferredChannelContext<IdentityVerificationRequest> ctx = new PreferredChannelContext<>(
                new IdentityVerificationRequest(),
                null,
                "EMAIL",
                "hashedEmail",
                "test@mc.com",
                "client",
                Collections.singletonList(c),
                c,
                otp,
                false,
                feature
        );

        PreferredChannelResolution res = engine().resolve(ctx, null);
        assertEquals(AuthenticationChannel.SMS.name(), res.channels().getPreferredChannel());
        assertEquals("C2P_NewUser", res.channelRule());
    }
}
