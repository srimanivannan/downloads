package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.Mobile;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;

public class RequestAuthFactsBuilderTest {

    @Test
    public void validatedAbsent_emailIdentity_smsAuth_forcesEmailAndRestrictsSms() {
        Consumer c = new Consumer();
        c.setConsumerId("c1");
        c.setHashedEmail("preferredEmailHash");
        c.setHashedCountryCodeWithMobile("preferredMobileHash");

        Identity email = new Identity();
        email.setType("EMAIL");
        email.setEmail("test@mc.com");
        email.setHashedEmail("emailHash");
        email.setMaskedEmail("t***@mc.com");
        email.setPreferred(false);

        Mobile m = new Mobile();
        m.setCountryCode("1");
        m.setPhoneNumber("5550000");
        m.setHashedCountryCodeWithPhoneNumber("mobileHash");
        m.setMaskedPhoneNumber("***0000");

        Identity mobile = new Identity();
        mobile.setType("MOBILE_PHONE_NUMBER");
        mobile.setMobile(m);
        mobile.setPreferred(true);

        c.setIdentities(Arrays.asList(email, mobile));

        // Make validation fail by passing consumers list that won't match preferred email hash (validatedEmailHash empty)
        Consumer other = new Consumer();
        other.setHashedEmail("different");
        other.setHashedCountryCodeWithMobile("different");
        other.setIdentities(Collections.singletonList(email));

        RequestAuthFactsBuilder builder = new RequestAuthFactsBuilder(new IdentityLookupService());
        RequestAuthFacts facts = builder.build(
                AuthenticationChannel.SMS.name(),
                true,
                com.mastercard.precheckout.generated.emvco.model.IdentityType.EMAIL.name(),
                "fallbackHash",
                "test@mc.com",
                Arrays.asList(c, other),
                c
        );

        assertTrue(facts.applicable());
        assertEquals(AuthenticationChannel.EMAIL, facts.preferredChannel());
        assertTrue(facts.restrictedChannels().contains(AuthenticationChannel.SMS));
        assertEquals("emailHash", facts.hashedValidationChannelValue().orElse(null));
        assertNotNull(facts.maskedValidationChannelValue().orElse(null));
    }
}
