package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.Mobile;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class C2PFactsBuilderTest {

    private final C2PFactsBuilder builder = new C2PFactsBuilder();

    @Test
    public void buildMultiPiiFacts_sms_identity_validatedEmail_present_setsAllEmailMatched_true() {
        Consumer c1 = consumerWithIdentities(
                "c1",
                "hashedEmail",
                "hashedMobile",
                emailIdentity("pref@mc.com", "hashedEmail", "p***@mc.com", true),
                mobileIdentity("91", "1234567890", "hashedMobile", "****7890", true)
        );

        Consumer c2 = consumerWithIdentities(
                "c2",
                "hashedEmail",
                "otherMobile",
                emailIdentity("pref@mc.com", "hashedEmail", "p***@mc.com", true),
                mobileIdentity("91", "0000000000", "otherMobile", "****0000", true)
        );

        ChannelContext ctx = new ChannelContext(
                c1,
                List.of(c1, c2),
                IdentityType.SMS,
                "fallbackHash",
                "911234567890"
        );

        C2PFacts facts = builder.buildMultiPiiFacts(ctx);

        assertTrue(facts.allEmailMatched());
        assertTrue(facts.allMobileMatched());
        assertEquals("hashedMobile", facts.matchedPreferredHash().orElse(null));
        assertEquals("+91****7890", facts.maskedValue().orElse(null));
        assertTrue(facts.mobile().isPresent());
    }

    @Test
    public void buildMultiPiiFacts_email_identity_validatedMobile_missing_setsAllMobileMatched_false() {
        Consumer c1 = consumerWithIdentities(
                "c1",
                "hashedEmail",
                "hashedMobile",
                emailIdentity("pref@mc.com", "hashedEmail", "p***@mc.com", true),
                mobileIdentity("91", "1234567890", "hashedMobile", "****7890", true)
        );

        // second consumer does NOT have matching mobile hash -> validation fails
        Consumer c2 = consumerWithIdentities(
                "c2",
                "hashedEmail",
                "differentMobile",
                emailIdentity("pref@mc.com", "hashedEmail", "p***@mc.com", true),
                mobileIdentity("91", "9999999999", "differentMobile", "****9999", true)
        );

        ChannelContext ctx = new ChannelContext(
                c1,
                List.of(c1, c2),
                IdentityType.EMAIL,
                "fallbackHash",
                "pref@mc.com"
        );

        C2PFacts facts = builder.buildMultiPiiFacts(ctx);

        assertTrue(facts.allEmailMatched());
        assertFalse(facts.allMobileMatched());
        // when mobile not validated, matchedPreferred == switchingHash (lookupEmailOtp)
        assertEquals("hashedEmail", facts.matchedPreferredHash().orElse(null));
        assertEquals("p***@mc.com", facts.maskedValue().orElse(null));
        assertTrue(facts.email().isPresent());
    }

    @Test
    public void buildSingleIdentityFacts_email_setsAllMobileMatched_basedOnRootHashComparison() {
        Consumer c1 = new Consumer();
        c1.setHashedCountryCodeWithMobile("m1");
        Consumer c2 = new Consumer();
        c2.setHashedCountryCodeWithMobile("m1");

        ChannelContext ctx = new ChannelContext(
                c1,
                List.of(c1, c2),
                IdentityType.EMAIL,
                "ignored",
                "ignored"
        );

        C2PFacts facts = builder.buildSingleIdentityFacts(ctx);

        assertTrue(facts.allEmailMatched());
        assertTrue(facts.allMobileMatched());
    }

    private static Consumer consumerWithIdentities(
            String id,
            String rootEmailHash,
            String rootMobileHash,
            Identity... identities
    ) {
        Consumer c = new Consumer();
        c.setConsumerId(id);
        c.setHashedEmail(rootEmailHash);
        c.setHashedCountryCodeWithMobile(rootMobileHash);
        c.setIdentities(Arrays.asList(identities));
        return c;
    }

    private static Identity emailIdentity(String email, String hash, String masked, boolean preferred) {
        Identity i = new Identity();
        i.setType("EMAIL");
        i.setEmail(email);
        i.setHashedEmail(hash);
        i.setMaskedEmail(masked);
        i.setPreferred(preferred);
        return i;
    }

    private static Identity mobileIdentity(String cc, String phone, String hash, String masked, boolean preferred) {
        Mobile m = new Mobile();
        m.setCountryCode(cc);
        m.setPhoneNumber(phone);
        m.setHashedCountryCodeWithPhoneNumber(hash);
        m.setMaskedPhoneNumber(masked);

        Identity i = new Identity();
        i.setType("MOBILE_PHONE_NUMBER");
        i.setMobile(m);
        i.setPreferred(preferred);
        return i;
    }
}
