package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;
import com.mastercard.precheckout.generated.emvco.model.IdentityType;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class C2PChannelEngineTest {

    @Test
    public void engine_routes_to_multiPii_resolver() {
        C2PChannelEngine engine = new C2PChannelEngine(List.of(
                new MultiPiiC2PResolver(),
                new SingleIdentityC2PResolver()
        ));

        Consumer consumer = new Consumer();
        consumer.setStatus("ACTIVE");

        ChannelContext ctx = new ChannelContext(
                consumer,
                List.of(consumer),
                IdentityType.EMAIL,
                "fallback",
                "requested"
        );

        ISDVerificationChannels out = new ISDVerificationChannels();
        C2PResolution resolution = engine.resolve(C2PMode.MULTI_PII, ctx, out);

        // With no identities, facts builder yields no match -> null preferred
        assertEquals(null, resolution.preferredChannel());
    }

    @Test
    public void engine_singleIdentity_newUser_always_sms() {
        C2PChannelEngine engine = new C2PChannelEngine(List.of(
                new MultiPiiC2PResolver(),
                new SingleIdentityC2PResolver()
        ));

        Consumer consumer = new Consumer();
        consumer.setStatus(ConsumerStatus.PENDING_VERIFICATION.getValue());

        ChannelContext ctx = new ChannelContext(
                consumer,
                List.of(consumer),
                IdentityType.EMAIL,
                "ignored",
                "ignored"
        );

        ISDVerificationChannels out = new ISDVerificationChannels();
        C2PResolution resolution = engine.resolve(C2PMode.SINGLE_IDENTITY, ctx, out);

        assertEquals(AuthenticationChannel.SMS.name(), resolution.preferredChannel());
        assertEquals("C2P_NewUser", resolution.channelRule());
    }
}
