package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Entry point for the refactored C2P channel engine.
 */
public final class C2PChannelEngine {

    private final Map<C2PMode, C2PModeResolver> resolvers;
    private final C2PFactsBuilder factsBuilder;

    public C2PChannelEngine(List<C2PModeResolver> resolvers) {
        this(resolvers, new C2PFactsBuilder());
    }

    public C2PChannelEngine(List<C2PModeResolver> resolvers, C2PFactsBuilder factsBuilder) {
        this.resolvers = resolvers.stream()
                .collect(Collectors.toUnmodifiableMap(C2PModeResolver::supports, Function.identity()));
        this.factsBuilder = factsBuilder;
    }

    public C2PResolution resolve(C2PMode mode, ChannelContext ctx, ISDVerificationChannels out) {
        C2PModeResolver resolver = resolvers.get(mode);
        if (resolver == null) {
            return new C2PResolution(null, null);
        }
        return resolver.resolve(ctx, factsBuilder, out);
    }
}
