package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;

import java.util.Collections;

/**
 * Single-identity C2P resolver equivalent to legacy getPreferredChannelForC2p.
 * No hash/mask population beyond restrictedChannelList.
 */
public final class SingleIdentityC2PResolver implements C2PModeResolver {

    @Override
    public C2PMode supports() {
        return C2PMode.SINGLE_IDENTITY;
    }

    @Override
    public C2PResolution resolve(ChannelContext ctx, C2PFactsBuilder factsBuilder, ISDVerificationChannels out) {

        if (ctx != null && ctx.consumer() != null
                && ConsumerStatus.PENDING_VERIFICATION.getValue().equals(ctx.consumer().getStatus())) {
            return new C2PResolution(AuthenticationChannel.SMS.name(), "C2P_NewUser");
        }

        C2PFacts facts = factsBuilder.buildSingleIdentityFacts(ctx);
        C2PDecisionTable decision = C2PDecisionTable.resolve(facts.allEmailMatched(), facts.allMobileMatched());
        if (decision == null) {
            return new C2PResolution(null, null);
        }

        switch (decision) {
            case EMAIL_MATCHED -> out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
            case MOBILE_MATCHED -> out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
            default -> {
                // no restrictions
            }
        }

        return new C2PResolution(decision.preferredChannel().name(), decision.channelRule());
    }
}
