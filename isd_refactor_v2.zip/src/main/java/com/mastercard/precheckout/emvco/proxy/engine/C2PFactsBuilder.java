package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Consumer;
import com.mastercard.precheckout.emvco.domain.Identity;
import com.mastercard.precheckout.emvco.domain.Mobile;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Builds C2PFacts from the raw Consumer + scope data.
 *
 * This is the only place that should know how to navigate Consumer.identities and
 * compute validated/preferred hashes.
 */
public final class C2PFactsBuilder {

    public C2PFacts buildMultiPiiFacts(ChannelContext ctx) {
        if (ctx == null || ctx.consumer() == null) {
            return C2PFacts.empty();
        }

        Consumer consumer = ctx.consumer();
        var idType = ctx.identityTypeFromScopeData();

        if (idType == null) {
            return C2PFacts.empty();
        }

        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;
        Optional<String> matchedPreferred = Optional.empty();
        Optional<String> switchingHash = Optional.empty();

        if (idType.name().equals("SMS")) {
            Optional<String> preferredEmailHash = getPreferredEmailHash(consumer);
            Optional<String> validatedEmailHash = getValidatedEmailHash(ctx.consumers(), preferredEmailHash);
            isAllEmailMatched = validatedEmailHash.isPresent();
            isAllMobileMatched = true;
            matchedPreferred = lookupPhoneOtpValue(consumer, ctx.requestedIdentityValueFromScopeData(), ctx.identityValueFromScopeData());
            switchingHash = matchedPreferred;
        } else if (idType.name().equals("EMAIL")) {
            Optional<String> preferredMobileHash = getPreferredMobileHash(consumer);
            Optional<String> validatedMobileHash = getValidatedMobileHash(ctx.consumers(), preferredMobileHash);
            isAllEmailMatched = true;
            isAllMobileMatched = validatedMobileHash.isPresent();
            switchingHash = lookupEmailOtpValue(consumer, ctx.requestedIdentityValueFromScopeData(), ctx.identityValueFromScopeData());
            if (!isAllMobileMatched) {
                matchedPreferred = switchingHash;
            } else {
                matchedPreferred = validatedMobileHash.or(() -> Optional.ofNullable(consumer.getHashedCountryCodeWithMobile()));
            }
        }

        var mobileAndMasked = getMobileAndMaskedPhoneNumber(consumer, matchedPreferred);
        var emailAndMasked = getEmailAndMaskedEmail(consumer, matchedPreferred);

        Optional<Mobile> mobile = mobileAndMasked.getLeft();
        Optional<String> maskedFromMobile = mobileAndMasked.getRight();
        Optional<String> email = emailAndMasked.getLeft();
        Optional<String> maskedFromEmail = emailAndMasked.getRight();

        Optional<String> masked = maskedFromMobile.isPresent() ? maskedFromMobile : maskedFromEmail;

        return new C2PFacts(
                isAllEmailMatched,
                isAllMobileMatched,
                matchedPreferred,
                switchingHash,
                masked,
                mobile,
                email
        );
    }

    /**
     * Single-identity PII (future): match across consumers using only root hashes.
     * This mirrors legacy getPreferredChannelForC2p behavior for match booleans.
     */
    public C2PFacts buildSingleIdentityFacts(ChannelContext ctx) {
        if (ctx == null || ctx.consumer() == null) {
            return C2PFacts.empty();
        }
        Consumer consumer = ctx.consumer();
        var idType = ctx.identityTypeFromScopeData();
        if (idType == null) {
            return C2PFacts.empty();
        }

        boolean isAllEmailMatched = false;
        boolean isAllMobileMatched = false;

        if (idType.name().equals("EMAIL")) {
            isAllMobileMatched = ctx.consumers().stream().allMatch(c -> Objects.equals(
                    consumer.getHashedCountryCodeWithMobile(),
                    c.getHashedCountryCodeWithMobile()
            ));
            isAllEmailMatched = true;
        } else if (idType.name().equals("SMS")) {
            isAllEmailMatched = ctx.consumers().stream().allMatch(c -> Objects.equals(
                    consumer.getHashedEmail(),
                    c.getHashedEmail()
            ));
            isAllMobileMatched = true;
        }

        return new C2PFacts(
                isAllEmailMatched,
                isAllMobileMatched,
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty(),
                Optional.empty()
        );
    }

    // -------------------------
    // Helper methods copied from legacy rule (to remove IdentityOps dependency)
    // -------------------------

    private Optional<String> getPreferredMobileHash(Consumer consumer) {
        return Optional.ofNullable(consumer.getIdentities())
                .orElse(Collections.emptyList())
                .stream()
                .filter(identity -> "MOBILE_PHONE_NUMBER".equals(identity.getType()) && identity.isPreferred())
                .map(id -> id.getMobile().getHashedCountryCodeWithPhoneNumber())
                .findFirst()
                .or(() -> Optional.ofNullable(consumer.getHashedCountryCodeWithMobile()));
    }

    private Optional<String> getPreferredEmailHash(Consumer consumer) {
        return Optional.ofNullable(consumer.getIdentities())
                .orElse(Collections.emptyList())
                .stream()
                .filter(identity -> "EMAIL".equals(identity.getType()) && identity.isPreferred())
                .map(Identity::getHashedEmail)
                .findFirst()
                .or(() -> Optional.ofNullable(consumer.getHashedEmail()));
    }

    private Optional<String> getValidatedMobileHash(List<Consumer> consumers, Optional<String> preferredMobileHash) {
        return preferredMobileHash.filter(hash -> consumers.stream()
                .allMatch(c -> Stream.concat(
                        Optional.ofNullable(c.getIdentities())
                                .orElse(Collections.emptyList())
                                .stream()
                                .filter(id -> "MOBILE_PHONE_NUMBER".equals(id.getType()))
                                .map(id -> id.getMobile().getHashedCountryCodeWithPhoneNumber()),
                        Stream.ofNullable(c.getHashedCountryCodeWithMobile())
                ).filter(Objects::nonNull).anyMatch(hash::equals)));
    }

    private Optional<String> getValidatedEmailHash(List<Consumer> consumers, Optional<String> preferredEmailHash) {
        return preferredEmailHash.filter(hash -> consumers.stream()
                .allMatch(c -> Stream.concat(
                        Optional.ofNullable(c.getIdentities())
                                .orElse(Collections.emptyList())
                                .stream()
                                .filter(id -> "EMAIL".equals(id.getType()))
                                .map(Identity::getHashedEmail),
                        Stream.ofNullable(c.getHashedEmail())
                ).filter(Objects::nonNull).anyMatch(hash::equals)));
    }

    private Pair<Optional<Mobile>, Optional<String>> getMobileAndMaskedPhoneNumber(Consumer consumer, Optional<String> matchedPreferredValue) {
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(id -> "MOBILE_PHONE_NUMBER".equals(id.getType()))
                .filter(id -> matchedPreferredValue.isPresent() && matchedPreferredValue.get().equals(id.getMobile().getHashedCountryCodeWithPhoneNumber()))
                .findFirst()
                .map(id -> Pair.of(Optional.of(id.getMobile()),
                        Optional.of("+" + id.getMobile().getCountryCode() + id.getMobile().getMaskedPhoneNumber())))
                .orElse(Pair.of(Optional.empty(), Optional.empty()));
    }

    private Pair<Optional<String>, Optional<String>> getEmailAndMaskedEmail(Consumer consumer, Optional<String> matchedPreferredValue) {
        return Optional.ofNullable(consumer.getIdentities()).orElse(Collections.emptyList()).stream()
                .filter(id -> "EMAIL".equals(id.getType()))
                .filter(id -> matchedPreferredValue.isPresent() && matchedPreferredValue.get().equals(id.getHashedEmail()))
                .findFirst()
                .map(id -> Pair.of(Optional.of(id.getEmail()), Optional.of(id.getMaskedEmail())))
                .orElse(Pair.of(Optional.empty(), Optional.empty()));
    }

    private Optional<String> lookupPhoneOtpValue(Consumer consumer, String requestedIdentityValueFromScopeData, String identityValueFromScopeData) {
        if (consumer.getIdentities() == null) {
            return Optional.ofNullable(identityValueFromScopeData);
        }
        return Optional.of(
                consumer.getIdentities().stream()
                        .filter(identity -> "MOBILE_PHONE_NUMBER".equals(identity.getType()))
                        .filter(identity -> {
                            if (requestedIdentityValueFromScopeData == null || identity.getMobile() == null) {
                                return false;
                            }
                            String scopedPhone = requestedIdentityValueFromScopeData;
                            String countryCode = identity.getMobile().getCountryCode();
                            String identityPhone = identity.getMobile().getPhoneNumber();

                            String localScopePhone = (countryCode != null && scopedPhone.startsWith(countryCode))
                                    ? scopedPhone.substring(countryCode.length())
                                    : scopedPhone;

                            return Objects.equals(localScopePhone, identityPhone);
                        })
                        .map(identity -> identity.getMobile().getHashedCountryCodeWithPhoneNumber())
                        .findFirst()
                        .orElse(identityValueFromScopeData)
        );
    }

    private Optional<String> lookupEmailOtpValue(Consumer consumer, String requestedEmail, String fallbackHash) {
        if (consumer.getIdentities() == null) {
            return Optional.ofNullable(fallbackHash);
        }
        return Optional.of(
                consumer.getIdentities().stream()
                        .filter(identity -> "EMAIL".equals(identity.getType()))
                        .filter(identity -> requestedEmail != null && identity.getEmail() != null && requestedEmail.equalsIgnoreCase(identity.getEmail()))
                        .map(Identity::getHashedEmail)
                        .findFirst()
                        .orElse(fallbackHash)
        );
    }
}
