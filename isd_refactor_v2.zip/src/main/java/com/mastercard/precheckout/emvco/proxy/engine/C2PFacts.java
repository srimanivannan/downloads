package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.Mobile;

import java.util.Optional;

/**
 * Computed facts for C2P channel selection.
 *
 * Keep this record stable as rules evolve; prefer changing the builder
 * rather than downstream decision/application logic.
 */
public record C2PFacts(
        boolean allEmailMatched,
        boolean allMobileMatched,
        Optional<String> matchedPreferredHash,
        Optional<String> switchingHash,
        Optional<String> maskedValue,
        Optional<Mobile> mobile,
        Optional<String> email
) {

    public static C2PFacts empty() {
        return new C2PFacts(false, false, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty());
    }
}
