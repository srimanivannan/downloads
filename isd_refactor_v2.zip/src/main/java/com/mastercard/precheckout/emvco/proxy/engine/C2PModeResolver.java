package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;

/**
 * Pluggable resolver for different C2P identity modes.
 */
public interface C2PModeResolver {

    C2PMode supports();

    C2PResolution resolve(ChannelContext ctx, C2PFactsBuilder factsBuilder, ISDVerificationChannels out);
}
