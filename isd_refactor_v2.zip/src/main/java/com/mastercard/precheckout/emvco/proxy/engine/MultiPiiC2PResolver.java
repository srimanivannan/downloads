package com.mastercard.precheckout.emvco.proxy.engine;

import com.mastercard.precheckout.emvco.constants.ConsumerStatus;
import com.mastercard.precheckout.emvco.domain.AuthenticationChannel;
import com.mastercard.precheckout.emvco.domain.ISDVerificationChannels;

import java.util.Collections;

/**
 * Multi-PII C2P resolver replacing getPreferredPriorityChannelForC2P.
 *
 * Uses facts + decision table (no nested branching).
 */
public final class MultiPiiC2PResolver implements C2PModeResolver {

    @Override
    public C2PMode supports() {
        return C2PMode.MULTI_PII;
    }

    @Override
    public C2PResolution resolve(ChannelContext ctx, C2PFactsBuilder factsBuilder, ISDVerificationChannels out) {

        // New user -> always SMS
        if (ctx != null && ctx.consumer() != null
                && ConsumerStatus.PENDING_VERIFICATION.getValue().equals(ctx.consumer().getStatus())) {
            return new C2PResolution(AuthenticationChannel.SMS.name(), "C2P_NewUser");
        }

        C2PFacts facts = factsBuilder.buildMultiPiiFacts(ctx);
        C2PDecisionTable decision = C2PDecisionTable.resolve(facts.allEmailMatched(), facts.allMobileMatched());

        if (decision == null) {
            return new C2PResolution(null, null);
        }

        switch (decision) {
            case ALL_MATCHED -> {
                out.setHashedValidationChannelValue(facts.matchedPreferredHash().orElse(null));
                out.setMaskedValidationChannelValue(facts.maskedValue().orElse(null));
                out.setMobile(facts.mobile().orElse(null));
            }
            case EMAIL_MATCHED -> {
                out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.SMS));
                out.setHashedValidationChannelValue(facts.matchedPreferredHash().orElse(null));
                out.setMaskedValidationChannelValue(facts.maskedValue().orElse(null));
                out.setEmail(facts.email().orElse(null));
            }
            case MOBILE_MATCHED -> {
                out.setRestrictedChannelList(Collections.singleton(AuthenticationChannel.EMAIL));
                out.setHashedValidationChannelValue(facts.matchedPreferredHash().orElse(null));
                out.setMaskedValidationChannelValue(facts.maskedValue().orElse(null));
                out.setMobile(facts.mobile().orElse(null));
            }
        }

        return new C2PResolution(decision.preferredChannel().name(), decision.channelRule());
    }
}
